# 貢献ガイド · Contributing

公開できる再現手順、変更理由、対象となる仕様、確認できた結果を添えてください。第三者のライセンス表記を保持します。別途適合する条件を明示して合意した場合を除き、意図して提供する貢献にはこのプロジェクトの Apache-2.0 条件を適用します。

For a change, include the problem, affected behavior and reproducible evidence. Keep third-party copyright and license notices. Contributions intentionally submitted for inclusion use the project’s Apache-2.0 terms unless separately identified and accepted with compatible provenance. Use shareable synthetic inputs and public code in reports.

仕様を変える場合は、対応する要件、変更の権限、既存データや挙動の移行方法を記録します。候補実装を通す目的で、定理・公理の制限・検査条件・期待結果を緩めることはできません。

For a contract change, record which requirements change, who has authority to change them and how existing behavior or data migrates. Keep theorems, axiom limits, acceptance conditions and expected results fixed when checking an implementation proposal.

引き継いだ `packages/lean-verified-sdlc/` は不変です。新しいランタイムやアダプターは別パッケージに置きます。失敗時の動作と権限境界をテストし、元のデモを再現できる状態で保ちます。

Preserve the immutable historical package and its reproduction. Put new runtimes and adapters in separate packages. Include tests of failure cases and trust boundaries. Changes to a proof checker or policy require the corresponding authority. A standing automated policy may accept routine changes within its authorized scope. [設計 / Architecture](autonomy/architecture.md)
