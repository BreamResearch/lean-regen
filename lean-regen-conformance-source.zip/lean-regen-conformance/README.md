# Inventory trace checker · 在庫ログ照合器

With Python 3.9 or later, run these commands in the directory containing this file.
Python 3.9以上でこのファイルのあるディレクトリから実行できます。

```sh
python3 packages/conformance/check_trace.py
python3 packages/conformance/check_trace.py packages/conformance/fixtures/wrong.jsonl
```

The first run matches all 16 recorded operations. The second reports the failed exact-fill
reservation at operation 4 and exits 1. 自分のアプリの操作記録を検査するには、JSONLファイルを
同じコマンドに渡します。[Log format and native mode / 記録形式とネイティブモード](packages/conformance/README.md)

## Rebuild · 配布物を再生成する

```sh
python3 -B -m unittest discover -s packages/conformance -p 'test_*.py'
python3 packages/conformance/build_zipapp.py --release-dir ../new-checker-release
```

Use a new output directory. The command creates the checker, this source ZIP, the
counterexample and the checksums. The bundled SOURCE-MANIFEST.json identifies each distributed
source file by path and SHA-256. 新しいディレクトリを指定すると、配布した4ファイルを再生成できます。

For native checks, use Python 3.11+, Lean/Lake 4.19.0 and a working native linker.
On Apple Silicon with macOS 27, set the following before building. macOS 27のApple Siliconでは、
ネイティブビルドの前にXcodeのリンカーを選びます。

```sh
export CCC_OVERRIDE_OPTIONS='+--ld-path=/usr/bin/ld'
export MACOSX_DEPLOYMENT_TARGET=27.0
```

[License](LICENSE) · [Attribution](NOTICE) · [Third-party notices](THIRD_PARTY_NOTICES.md)
