# Lean Regen — GitHub 配布・更新・公開の実行引き継ぎ

2026年11月24日、BreamResearchの公開リポジトリとGitHub Pagesでソースアルファの配布を開始した。[公開リポジトリ](https://github.com/BreamResearch/lean-regen) · [日英の案内](https://breamresearch.github.io/lean-regen/)

公開リポジトリの `main` は配布物を収録する。固定したソースの注釈付きタグ `v0.2.0-alpha.2` は公開Gitバンドル内の `80a86efab6e6d678d7ae839811a2fb95352ddbbd` を指す。GitHubの配布タグ `v0.2.0-alpha.2-dist.1` は、バンドルと5資産を検査した配布コミット `4fdc4f1a08639611e883e06b30ba0a4d4ae8ddb7` を指す。今後の配布も両方の識別子とダウンロード照合結果を記録する。ソース用bootstrapスクリプトの前提で既存の配布履歴を上書きしない。[改変不能リリース](https://github.com/BreamResearch/lean-regen/releases/tag/v0.2.0-alpha.2-dist.1) · [Linux CI](https://github.com/BreamResearch/lean-regen/actions/runs/45375656292)

## 1. 公開するものと、保証するもの

公開 OSS の alpha は、実装済み機能、実際に実行した検証、未実装事項を明示すれば公開できる。ホスト型サービスの完成を alpha 公開の前提にしない。一方、配布物に「検証済み」と表示するには、対象と証拠を個別に結び付ける。

| 配布区分 | 公開条件 | 公開文面 |
|---|---|---|
| Source alpha | 配布権利、秘密情報検査、パッケージ整合性、再現手順、実行済み／未実行の明示が揃う | 「Lean による検証開発の実験用スターター。保証範囲は各リリースの evidence manifest を参照」 |
| 検証済みコアの配布 | 対象コミットの凍結仕様・定理・ソース・Lean バージョン・許可公理・検証出力の一致を確認 | 「このコミットのこの定理を、この前提と環境で検査した」 |
| 自動受入れ可能な成果物 | 保護された仕様・ポリシー、独立自動検証、成果物との対応、環境前提、必要な統合・移行証拠がすべて合格 | 対応する仕様 ID、成果物ハッシュ、検証器 ID、対象範囲を表示 |
| ホスト型サービス | 認証、分離、課金上限、運用、障害時の扱い、データ取扱いが実装される | 実際に提供可能な機能と契約範囲だけを表示 |

これらは配布区分であり、既存 evidence schema の検証状態を上書きしない。スターターの一部コアが検証済みでも、Web、DB、運用、顧客業務全体を「無欠陥」と表示しない。GitHub の緑のチェック、署名、attestation は Lean 定理の成立と同義ではない。

## 2. Codex が最初に解決する実環境値

以下を既存の認証状態とユーザー提供設定から確定する。値が分かるまで、設定ファイルや公開文面に架空の所有者・URL・メールアドレスを埋めない。実装側の設定 schema と対応を合わせる。

| 必要な値 | 確定方法 | 未解決時にできること |
|---|---|---|
| GitHub の所有者・公開リポジトリ | 認証済みアカウント、所属組織、書込権限、既存 repo を読取確認 | ローカル実装・検証・公開用 archive の作成 |
| GitHub plan と使用可能な rulesets / Actions 機能 | 対象アカウントで確認 | GitHub Free 向け SHA 固定版を準備 |
| 公開著作権者と既存成果物の権利 | 元ファイルのライセンス・出典と権利者情報 | ライセンス方針と不足項目を準備 |
| Pages の実 URL / custom domain | 作成後の GitHub 応答、所有ドメイン設定 | 相対リンクで docs を生成 |
| managed service の provider / region / project / domain | 既存接続と提供設定 | provider 非依存の設計・契約・ローカル実装 |
| 予算、通貨、利用上限 | 明示済み上限、既存運用設定 | 無償・ローカル部分を完成。無制限の課金を有効化しない |
| 署名・受入れポリシーの管理者 ID | 認証された authority と trust policy | ローカル検査と署名前の証拠生成 |
| Sponsors の実アカウント | 利用可能な有効 profile を確認 | プロフィール・tier の原稿作成 |

この引き継ぎは後続の実装・一般公開を意図している。実対象が確定し、必要な権限と公開条件が揃えば、Codex は通常の実装、PR、設定、公開を継続する。各工程で形式的な再承認を求めない。アカウント選択が一意でない場合、課金上限がない場合、本人確認・税務・契約締結を要求される場合は、該当する不足値または本人作業だけを明示する。外部への営業メッセージ送信はこの手順の自動実行に含めない。

## 3. リポジトリの初期設定

1. 既存ファイルと Git 履歴を確認し、ユーザーの既存変更を保護する。認証済み CLI/API で対象 owner、repo、可視性を確認する。
2. Apache-2.0 の完全な本文を `LICENSE` に入れ、元から存在するライセンス・NOTICE・帰属を保持する。詳細は [ライセンス方針](LICENSE_AND_REUSE_JA.md) を参照。
3. README に一文の価値、すぐ動く実例、再検証手順、対応環境、保証範囲、未実装事項、課金不要の入手方法を記載する。実際に成功したコマンドだけを Quickstart とする。
4. `CONTRIBUTING`、`SECURITY`、変更履歴、issue template、証拠 schema、破壊的変更／移行の方針を追加する。存在しない問い合わせメールやセキュリティ受付先を作らない。
5. 生のトークン、顧客要件、個人情報、本番ログ、private repo URL を公開 archive と Git 履歴から除外できたことを確認する。公開例は合成データとする。
6. default branch への直接書込、tag の移動、受入れ条件の変更を trust policy で制限する。定義済みの自動受入れ条件を満たす実装更新は毎回人間のコードレビューを必須にしない。
7. 生成者に、受入れ仕様、checker、CI 合否判定、署名鍵、公開権限をまとめて与えない。特に同じ PR から verifier の定義を変更して自分を合格させる経路を排除する。

GitHub で公開しただけでは、再利用を許す OSS ライセンスは付かない。[G01]

## 4. CI の権限分離

以下は設計要件。単に job 名を分けただけでは隔離にならない。永続 runner、共有 Docker socket、書込可能な共有 directory、汚染可能な cache を通じて境界が崩れないようにする。

| 段階 | 実行するもの | 権限と出力 |
|---|---|---|
| PR / candidate build | 未信頼のソース、依存、Lean build、テスト | 使い捨て環境。公開 repo 読取のみ。秘密情報、署名権限、公開権限なし |
| trusted verification | 固定済み verifier と保護された仕様に対する candidate の検査 | candidate 内の CI スクリプトを合否の権威にしない。最小権限。証拠とハッシュを生成 |
| receipt / acceptance | 固定済みポリシーが証拠・対象・実行主体・鮮度を検査 | 認可済み受入れ主体だけが署名可能。candidate の JSON の `passed` をそのまま信用しない |
| release / deploy | 受入れ済み digest の配布・登録 | 検証済み artifact をデータとして扱う。ここで candidate の build/install hook を再実行しない |

実装方針:

- 通常の PR 検証は `pull_request` を使い、`permissions: contents: read` を基準にする。書込は必要な独立 job だけに付与する。[G02]
- `pull_request_target` で PR head を checkout して実行しない。`workflow_run` 由来 artifact も未信頼データとして検査する。現在の public repo 向け `pull_request_target` ポリシーは移行中なので、公開時に最新仕様を再確認する。[G03]
- 無償で広く使える標準 profile は、Actions と reusable workflow を公式 repo で確認した完全な commit SHA に固定する。架空の SHA、可変 `main`、根拠のない `latest` を使わない。配布時に未解決 pin があれば、対応する workflow を実行可能として配布しない。[G02]
- GitHub Enterprise Cloud を利用する profile は、公式の `gh actions-lock` で `.github/workflows/actions.lock` を生成できる。手編集しない。reusable workflow 自体は別途 SHA 固定する。lockfile は runner image や外部 build input まで固定しない。[G04][G05]
- OIDC 対応の provider では短期 credential を用い、信頼条件を実際の repository identity、許可 ref / environment、期待 event、必要なら固定 reusable workflow に制限する。`id-token: write` を付けるだけでは認可ポリシーにならない。[G06][G07]
- attestation 作成 job の `id-token: write` と `attestations: write`、release job の `contents: write` を build job に広げない。現在の公式手順に示す attestation action は `actions/attest` だが、採用版と SHA は実行時に公式 repo で確定する。[G08]

## 5. 更新を検知した後の動作

ネイティブに対応する依存は Dependabot を使う。2026-11-24 の対応一覧に Lean / Lake はないため、`lean-toolchain`、Lake の git revision、runtime checksum、独立 checker を追う watcher を追加する。[G09]

watcher は「更新候補を発見する」役割を持つ。新バージョンを見つけただけで trusted baseline を書き換えない。候補ごとに依存の由来と digest、変更理由、影響する証明・境界・移行を記録し、設計見直し、クリーン生成、証明、必要な統合検証を通す。新旧の振舞いが異なる場合は、許可された仕様変更ルールで説明する。旧仕様を都合よく弱めて証明成功にしない。

失敗時は、直前の受入れ済み版を維持し、候補を隔離する。安全性やサポート期限のため現行版の継続が認められない場合は、事前に定めた停止・縮退ルールに従う。自動で gates を緩めない。

### Lean kernel / toolchain 更新は信頼基盤の変更として扱う

固定した旧 Lean で成功しているという事実と、新しい Lean でも成立することは別の証拠である。更新候補では新 version と runtime digest を明記し、クリーン環境、全対象定理、許可公理、checker 対応、必要な成果物との対応を再検査する。新 kernel が要求する source 修正、標準 library の意味変更、独立 checker の未対応を個別に記録する。

新環境で失敗したときに、黙って古い Lean を選び直す、独立 checker を省略する、`sorry` や未許可 axiom を導入する、証明 scope を縮める、許可 resource 上限を変えて「更新成功」と表示することを禁止する。過去の受入れ版をそのまま維持することと、新版を受け入れることは明確に区別する。旧版を維持した場合は更新が保留であることを表示し、理由と期限・代替策を残す。

GitHub の `schedule` は厳密な起動保証ではない。混雑による遅延・取りこぼし、公開 repo の無活動による停止がある。SLA を売る段階では外部 heartbeat、監視、再試行・重複防止と別の起動経路を実装する。[G10]

## 6. リリースの実行順

1. 対象 commit、仕様 version / hash、依存 lock、検証器 version、ターゲット OS / arch、保証範囲を固定する。
2. 対象の配布区分に必要な gates を実行する。Source alpha に足りる証拠を、より強い検証済み成果物と表示しない。
3. archive、manifest、実際の証明結果、変更履歴、依存一覧、ライセンス notices、チェックサム、必要なら SBOM を生成する。未実行は未実行と記録する。
4. 保護された publish job が対象 digest と結果を検査する。署名対象には archive と証拠 manifest の結合を含める。provenance と数学的証拠を別欄で示す。
5. immutable releases を有効にする。適用は以後のリリースなので、既存 release も固定済みとは推定しない。[G11]
6. draft release を作り、すべての asset を添付してから公開する。公開後は asset の追加・差替え・削除ができない。修正は新しい version とし、古い成果物の証拠を保持する。[G12]
7. 公開 URL から archive を再取得し、ハッシュ、配布ファイル、再検証手順、リンク、表示範囲を確認する。実行結果、公開 URL、残課題を引き継ぎログに記録する。
8. docs / showcase を実 URL に更新する。managed service の endpoint がない間は、機能する登録・購入ボタンを装わない。

GitHub artifact attestations は public repo なら現行プランで利用できるが、private / internal repo には Enterprise Cloud が必要という制約がある。private 利用者にも無料のローカル再検証経路を残し、有償サービスを必須にしない。[G08]

### 初回ソースアルファの公開コマンド

運用端末でタグ `v0.2.0-alpha.2` と配布用の5ファイルを用意します。GitHub CLIで対象の個人所有者として認証し、`origin` をそのHTTPS Git URLに設定した環境で実行します。

```sh
python3 scripts/build_source_alpha.py --commit v0.2.0-alpha.2 --out dist/v0.2.0-alpha.2
python3 scripts/publish_source_alpha.py --repo BreamResearch/lean-regen --assets dist/v0.2.0-alpha.2
```

公開コマンドはタグの全ソースとZIPをバイト照合し、非公開報告窓口とリリースの不変化を有効にします。GitHubで該当コミットのソース検査が成功すると、ドラフトに添付した全ファイルを照合して公開し、匿名で再取得してSHA-256を確認します。途中から再実行できます。既存履歴の衝突や同名添付の不一致では処理が停止します。

## 7. 合格を偽装しやすい実装ミス

| 誤り | 必須の対処 |
|---|---|
| `lean … | tee …` の後ろだけ成功している | shell の失敗伝播を設定し、checker の終了 code を直接検査 |
| `continue-on-error`、空の test 集合、skip が成功扱い | 必須 job が明示的に成功し、必要な証拠が存在することを集約 gate で確認 |
| 前回の `.olean`、cache、receipt を流用 | クリーン環境で検証。対象 hash、toolchain、仕様 hash に結び付かない証拠を拒否 |
| 署名済みだが別 commit / 別 artifact | 受入れ manifest、配布 archive、provenance の subject digest を一致させる |
| 動作仕様も一緒に書き換えて証明成功 | 仕様の変更権限、意味差分、事前定義された許可範囲を別の authority で判定 |
| candidate が checker・workflow を差し替える | 信頼済み verifier 定義と許可した version を候補とは別に固定 |
| privileged job が artifact 内の script を起動 | データの schema / digest 検査だけを行い、candidate の実行を分離 |
| CI cache / reusable workflow の可変参照 | cache を権威にせず、依存と workflow の由来・digest を固定 |
| draft 前に immutable release を公開 | 全 asset 添付後に公開。公開済みは新 version で修正 |
| retry が重複課金・重複 deployment を起こす | candidate ID と artifact digest を用いる冪等な処理、retry 上限、予算上限 |

これらを検出する negative test を実際の公開 gate に追加する。純粋な README 変更のたびに無関係な広範囲テストを増やす必要はない。

## 8. 完了条件

Source alpha の完了は、公開 repo / release の実 URL、完全なライセンス、再現手順、実際の検証結果、既知の欠落、機能する docs 導線が揃うこと。ホスト型サービスや独立検証の未実装は、対応する backlog と公開表示に残す。verified artifact の完了は、それに加えて定義済みの厳格な受入れ条件を満たすこと。未実装の署名サービスや signup を「完了」と記録しない。

## 一次資料

- [G01 — Licensing a repository](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository)
- [G02 — Secure use reference](https://docs.github.com/en/actions/reference/security/secure-use)
- [G03 — Securely using pull_request_target](https://docs.github.com/en/actions/reference/security/securely-using-pull_request_target)
- [G04 — Workflow dependency lockfiles](https://docs.github.com/en/actions/concepts/security/workflow-dependency-lockfiles)
- [G05 — Locking action dependencies](https://docs.github.com/en/actions/how-tos/secure-your-work/lock-workflow-dependencies)
- [G06 — OpenID Connect](https://docs.github.com/en/actions/concepts/security/openid-connect)
- [G07 — OIDC with reusable workflows](https://docs.github.com/en/actions/how-tos/secure-your-work/security-harden-deployments/oidc-with-reusable-workflows)
- [G08 — Artifact attestations](https://docs.github.com/en/actions/how-tos/secure-your-work/use-artifact-attestations/use-artifact-attestations)
- [G09 — Dependabot supported ecosystems](https://docs.github.com/en/code-security/reference/supply-chain-security/supported-ecosystems-and-repositories)
- [G10 — Events that trigger workflows](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows)
- [G11 — Preventing changes to releases](https://docs.github.com/en/code-security/how-tos/secure-your-supply-chain/establish-provenance-and-integrity/prevent-release-changes)
- [G12 — Managing releases](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository)

確認日時と機械可読の出典一覧: [github_primary_sources.json](../research/github_primary_sources.json)。公開時には変化しうる GitHub 仕様を再確認する。
