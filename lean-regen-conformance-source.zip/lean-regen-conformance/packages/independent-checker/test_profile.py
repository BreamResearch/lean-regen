"""Local verifier preflight tests. These do not run any Lean kernel."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import verify

BASELINE = verify.ROOT.parent / "lean-verified-sdlc/assets/lean-starter"
PROFILE = "c4e48164e09abcd420d1d641703ac08b0249f61a7d71c1b0d34cafa6d99d7761"


class VerifierPreflight(unittest.TestCase):
    def test_inventory_preserves_reference_types_and_axiom_policy(self):
        _, files = verify.load_profile(verify.ROOT, PROFILE)
        config = json.loads(files["comparator.json"])
        historical = json.loads((BASELINE / "assurance.json").read_bytes())
        self.assertEqual(config["theorem_names"], [t["name"] for t in historical["theorems"]])
        policy = json.loads((verify.ROOT.parent.parent / "autonomy/policy.example.json").read_bytes())
        self.assertEqual(config["permitted_axioms"], policy["verification"]["allowed_axioms"])
        self.assertLessEqual(set(config["permitted_axioms"]), set(historical["allowed_axioms"]))
        contract = (BASELINE / "Contract.lean").read_text().split("open VerifiedInventory\n", 1)[1]
        # Each trusted challenge is the historical expected type with the same theorem name.
        declarations = []
        for example in contract.strip().split("\n\n"):
            declaration, application = example.rsplit(" :=\n  ", 1)
            name = application.split()[0]
            expected = declaration.replace("example ", "theorem " + name + " ", 1) + " := by\n  sorry"
            declarations.append(expected)
        body = "import VerifiedInventory.Implementation\n\nnamespace VerifiedInventory\n\n"
        body += "\n\n".join(declarations) + "\n\nend VerifiedInventory\n"
        self.assertEqual(body, files["Challenge.lean"].decode())
        for name in ("VerifiedInventory/Specification.lean", "VerifiedInventory/Implementation.lean"):
            self.assertEqual(files[name], (BASELINE / name).read_bytes())

    def test_modified_import_or_challenge_or_checker_config_is_rejected(self):
        for name in ("Challenge.lean", "VerifiedInventory/Specification.lean", "comparator.json"):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                shutil.copytree(verify.ROOT / "profile", root / "profile")
                shutil.copyfile(verify.ROOT / "profile.lock.json", root / "profile.lock.json")
                (root / "profile" / name).write_bytes(b"different bytes")
                with self.assertRaisesRegex(ValueError, "Trusted file digest differs"):
                    verify.load_profile(root, PROFILE)

    def test_changed_lock_is_rejected_even_if_locally_consistent(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "profile.lock.json").write_text("{}")
            with self.assertRaisesRegex(ValueError, "Profile digest differs"):
                verify.load_profile(root, PROFILE)

    def test_package_file_types_and_limits(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "solution"
            path.symlink_to(BASELINE / "VerifiedInventory/Proofs.lean")
            with self.assertRaises(OSError):
                verify.file_bytes(path, verify.SOLUTION_LIMIT)
            path.unlink()
            os.mkfifo(path)
            with self.assertRaisesRegex(ValueError, "regular file"):
                verify.file_bytes(path, verify.SOLUTION_LIMIT)
            path.unlink()
            path.write_bytes(b"ab")
            with self.assertRaisesRegex(ValueError, "size limit"):
                verify.file_bytes(path, 1)

    def test_omitted_proof_and_disallowed_declaration_block_before_lean(self):
        for token in (b"sorry", b"admit", b"axiom", b"native_decide", b"implemented_by"):
            with self.subTest(token=token), self.assertRaisesRegex(ValueError, "Restricted"):
                verify.validate_solution(token)
        verify.validate_solution((BASELINE / "VerifiedInventory/Proofs.lean").read_bytes())

    def test_invalid_toolchain_bytes_are_never_extracted(self):
        with tempfile.TemporaryDirectory() as td:
            work = Path(td)
            archive = work / "bad"
            archive.write_bytes(b"xyz")
            with self.assertRaisesRegex(ValueError, "differs from the release pin"):
                verify.extract_toolchain(archive, {"sha256": hashlib.sha256(b"abc").hexdigest(),
                                                 "size_bytes": 3}, work)
            self.assertFalse((work / "toolchain").exists())

    def test_candidate_output_cannot_override_an_export_digest(self):
        genuine = b"SHA256 (/tmp/actual) = " + b"f" * 64 + b"\n"
        duplicate = b"SHA256 (/tmp/other) = " + b"0" * 64 + b"\n"
        self.assertEqual(verify.export_digest(b"prefix" + genuine), "f" * 64)
        self.assertIsNone(verify.export_digest(duplicate + b"prefix" + genuine))
        self.assertIsNone(verify.export_digest(b""))

    def test_zero_exit_with_missing_kernel_evidence_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            scratch = Path(td)
            project = scratch / "project"
            project.mkdir()
            toolchain = scratch / "fake-toolchain"
            (toolchain / "bin").mkdir(parents=True)
            lake = toolchain / "bin/lake"
            lines = [name + " kernel accepts the solution" for name in verify.KERNELS if name != "nanoda"]
            lines += ["SHA256 (/tmp/export) = " + "f" * 64, "export digest kernel accepts the solution"]
            lake.write_text("#!/bin/sh\n" + "\n".join("echo '" + line + "'" for line in lines) +
                            "\necho 'Your solution is okay!'\n")
            lake.chmod(0o700)
            rc, seen, accepted = verify.compare(project, toolchain, scratch / "comparison.log")
            self.assertEqual(rc, 0)
            self.assertNotIn("nanoda", seen)
            self.assertFalse(accepted)

    def test_no_linux_never_launches_candidate(self):
        args = argparse.Namespace(profile_sha256=PROFILE, solution=BASELINE / "VerifiedInventory/Proofs.lean")
        with patch("platform.system", return_value="Darwin"), patch.object(verify, "compare") as checker:
            with self.assertRaisesRegex(ValueError, "Linux"):
                verify.verify(args, {})
            checker.assert_not_called()


if __name__ == "__main__":
    unittest.main()
