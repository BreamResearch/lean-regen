# 固定した在庫仕様の独立検査 · Fixed inventory proof profile

この開発パッケージは、固定した在庫実装に対する14項目の証明を検査します。Lean 4.36.0 と Linux の使い捨て環境を使い、元の証明を6カーネルで再検査できます。ソリューションの証明ソース、信頼する検査プロファイルのハッシュ、CPU に合った公式ツールチェーンを用意します。コマンドは下記にあります。

This development package checks submitted proofs about the **frozen inventory implementation**. Its challenge contains the 14 historical acceptance statements, with the theorem names applied by the original contract. The two imported project modules are byte-identical to the seed. Both exports use the same fixed standard library. The narrower autonomous-policy ceiling admits `propext` and `Quot.sound`. The challenge author's `sorry` declarations mark the questions. The solution must prove them.

The caller supplies just one regular UTF-8 Lean source file. The seed’s restricted proof tokens remain reserved, including in comments. The verifier snapshots the file as `Solution.lean` in a fresh package alongside its own frozen imports, config and empty dependency manifest. It verifies and unpacks the pinned Lean 4.36.0 release archive. Lake builds the challenge and the solution with its bubblewrap sandbox and compares statements, transitive definitions and axiom use. A supplementary GNU sha256sum command reads the same solution export as the kernels and records its SHA-256. The verifier rejects ambiguous digest output. Lake runs Lean default, Lean paranoid, lean4lean, nanoda, con-leche and con-ron over the exported solution. A local positive result requires successful comparator exit and all six kernel acceptance lines. It covers the fixed source and permits proof changes. Implementation regeneration requires another explicitly authorized profile.

## 実行結果 · Executed on 24 November 2026

オフラインの ARM64 Linux 環境で元の証明を2回比較し、各回とも14項目を6カーネルが受理しました。命題の変更、許可外の公理、定理の欠落をそれぞれ検出しました。ログとハッシュを以下から確認できます。

Two clean comparisons accepted the original proof source for all 14 obligations on the fixed Lean 4.36.0 ARM64 toolchain. Both used the six required kernels. The three changed candidates received the expected rejection for a changed statement, a forbidden use of `Classical.choice` and a missing final theorem. The local VM ran with no network device or host directory mount. The kernel build was LinuxKit 5.10.25 with Ubuntu 24.04.5 userspace. This run produced unsigned local evidence. [Comparison result](validation/20261124-linux-aarch64/seed/result.json) · [Comparator output](validation/20261124-linux-aarch64/seed/comparator.log) · [Regression results](validation/20261124-linux-aarch64/regressions/cases.json) · [Environment](validation/20261124-linux-aarch64/environment.json)

## ローカルで再現する · Run on a disposable Linux worker

Git、zstd、tar、Python 3.9 以上と bubblewrap のユーザー名前空間が使える Linux VM を用意し、一般ユーザーでリポジトリのルートから実行します。出力先は新規ディレクトリです。例は x86_64 用です。ARM64 では下記のアーカイブ名を使ってください。検査自体はオフラインかつ登録不要で、得られるのは署名を伴わないローカル結果です。

Use a clean Linux x86_64 or aarch64 VM with an unprivileged worker account, working bubblewrap user namespaces, git, zstd, tar and Python 3.9+. The VM should have no host mounts, production credentials or signing keys. The execution identity must omit the ability to change the verifier package, independently provisioned profile digest and system tools. Apply external disk, memory and CPU limits in the VM provisioner. This CLI enforces input size, comparator wall time and log size. An independently provisioned signer and release controller remain outstanding.

Obtain the official release archive for your architecture using the URL in `profile.lock.json`. Keep the archive locally or transfer it to the worker. The command itself needs no account and the pinned package has no network dependencies. Invoke from the repository root with a fresh output directory. Example for a trusted development worker, using the shipped inventory proof file and the independently obtained profile fingerprint:

```sh
python3 packages/independent-checker/verify.py \
  --profile-sha256 c4e48164e09abcd420d1d641703ac08b0249f61a7d71c1b0d34cafa6d99d7761 \
  --solution packages/lean-verified-sdlc/assets/lean-starter/VerifiedInventory/Proofs.lean \
  --toolchain-archive /var/tmp/lean-4.36.0-linux.tar.zst \
  --output /var/tmp/inventory-check-001
```

For arm64 supply `lean-4.36.0-linux_aarch64.tar.zst`. In automation, supply the profile fingerprint from the verifier's policy. The caller's choice of policy and trust in the worker determine what the result means. Local output is an unsigned diagnostic. It carries no deployment rights. A nonzero exit halts the check. A checker outage, wall-time limit, output limit or disagreement leaves promotion blocked.

Run the profile preflight checks on any supported Python host:

```sh
python3 -B -m unittest discover -s packages/independent-checker -p 'test_*.py'
```

The [Lean 4.36.0 release](https://github.com/leanprover/lean4/releases/tag/v4.36.0) supplies the pinned archive. Lake documents its supported Linux sandbox, comparator options and exit codes in the [versioned Lake help](https://github.com/leanprover/lean4/blob/v4.36.0/src/lake/Lake/CLI/Help.lean). The [official proof validation guide](https://lean-lang.org/doc/reference/latest/ValidatingProofs/) describes the trusted challenge and kernel assumptions.

## Source CI

The `Compare the fixed inventory proofs` job runs the built-in seed on public repositories, on the main branch. It uses a standard GitHub-hosted Ubuntu 22.04 VM, read-only checkout and a separate Linux user. It tests that bubblewrap can create the required namespaces before loading the fixed toolchain. The job records the unsigned comparator output and the results for changed notation, a missing theorem and a proof that uses an unpermitted axiom in its workflow log. The first successful remote run still needs to be observed. Normal GitHub CI can test a profile change, while release trust requires an independently protected verifier outside candidate control. [GitHub-hosted runner specifications](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)

To repeat the semantic regression suite on the same kind of Linux VM, invoke `test_kernel_cases.py` with the same four arguments as `verify.py` and a new output directory. It requires the shipped seed source by digest and starts with a successful reference comparison. For each changed candidate it requires the expected rejection diagnostic. The suite writes per-case comparator logs and their hashes to the output directory.
