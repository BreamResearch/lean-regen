"""Synthetic type and axiom regressions for the real Linux comparator.

Imported by unit discovery, but execution of the Linux suite is explicit. A reference
success is required before any rejection counts as evidence.
"""
import argparse
import json
import os
from pathlib import Path
import platform
import tempfile

import verify


def examples(solution):
    """Use the pinned seed's last proof, which has no downstream dependants."""
    marker = b"theorem all_runs_preserve "
    prefix, tail = solution.rsplit(marker, 1)
    statement, proof = tail.split(b" := by\n", 1)
    term, ending = proof.split(b"\n\nend VerifiedInventory", 1)
    if not term.startswith(b"  exact "):
        raise ValueError("Unexpected reference proof")
    choice = b"  exact Classical.choice (show Nonempty _ from \xe2\x9f\xa8" + term[8:] + b"\xe2\x9f\xa9)"
    notation = (b'local notation "ProbeInvariant" => True\n\n' + marker +
                b"(capacity : Nat) (cs : List Command) : ProbeInvariant := True.intro")
    suffix = b"\n\nend VerifiedInventory" + ending
    yield "reference", solution, None
    yield "changed-statement", prefix + notation + suffix, "theorem statement do not match"
    yield "extra-axiom", prefix + marker + statement + b" := by\n" + choice + suffix, (
        "Illegal axiom detected: 'Classical.choice'")
    yield "missing-final-theorem", prefix + suffix, "VerifiedInventory.all_runs_preserve"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--toolchain-archive", type=Path, required=True)
    parser.add_argument("--profile-sha256", required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if platform.system() != "Linux" or os.geteuid() == 0:
        parser.error("An unprivileged Linux worker is required")
    seed = verify.file_bytes(args.solution, verify.SOLUTION_LIMIT)
    if verify.sha(seed) != "af1f205e45d792f5e299f4a44f69f71f9d3b4e6737b595f5bcadd17a39188fb5":
        parser.error("The synthetic regression suite requires the exact shipped seed proof")
    args.output.mkdir(mode=0o700, exist_ok=False)
    policy, frozen = verify.load_profile(verify.ROOT, args.profile_sha256)
    pin = policy["toolchains"][platform.machine()]
    results = {}
    with tempfile.TemporaryDirectory(prefix="leanregen-cases-", dir="/var/tmp") as tmp:
        root = Path(tmp)
        toolchain = verify.extract_toolchain(args.toolchain_archive, pin, root)
        for label, candidate, diagnostic in examples(seed):
            work = root / label
            work.mkdir()
            project = work / "project"
            verify.validate_solution(candidate)
            verify.stage(project, frozen, candidate)
            log = args.output / (label + ".log")
            rc, kernels, accepted = verify.compare(project, toolchain, log)
            content = log.read_text(errors="replace")
            if diagnostic is None:
                matched = accepted
            elif label == "missing-final-theorem":
                matched = (rc == 1 and not accepted and
                           any(diagnostic in ln and any(x in ln.lower() for x in
                               ("not found", "unknown", "missing", "does not exist"))
                               for ln in content.splitlines()))
            else:
                matched = rc == 1 and not accepted and diagnostic in content
            results[label] = {"expected_outcome_observed": matched, "candidate_sha256": verify.sha(candidate),
                              "exit_code": rc, "accepted": accepted, "kernels": kernels,
                              "log_sha256": verify.sha(log.read_bytes())}
            (args.output / "cases.json").write_text(json.dumps(
                {"profile_sha256": args.profile_sha256, "toolchain_sha256": pin["sha256"],
                 "cases": results, "signed": False}, indent=2) + "\n")
            print(label, "matched" if matched else "did not match", flush=True)
            if not matched:
                return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
