#!/usr/bin/env python3
"""Judge a single proof module inside a disposable, credential-free Linux worker."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
import platform
import re
from pathlib import Path
import selectors
import signal
import stat
import subprocess
import sys
import tempfile
import time
import uuid

ROOT = Path(__file__).resolve().parent
SYSTEM_PATH = "/usr/bin:/bin"
KERNELS = ("Lean default", "Lean paranoid", "lean4lean", "nanoda", "con-leche", "con-ron")
LOG_LIMIT = 4 * 1024 * 1024
SOLUTION_LIMIT = 1024 * 1024


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_bytes(path, limit):
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
    with os.fdopen(os.open(path, flags), "rb") as src:
        if not stat.S_ISREG(os.fstat(src.fileno()).st_mode):
            raise ValueError("Input must be a regular file")
        data = src.read(limit + 1)
        if len(data) > limit:
            raise ValueError("Input exceeds size limit")
        return data


def load_profile(root, expected_sha):
    lock = file_bytes(root / "profile.lock.json", 64 * 1024)
    if sha(lock) != expected_sha:
        raise ValueError("Profile digest differs from verifier policy")
    policy = json.loads(lock)
    files = {}
    for name, digest in policy["files"].items():
        data = file_bytes(root / "profile" / name, SOLUTION_LIMIT)
        if sha(data) != digest:
            raise ValueError("Trusted file digest differs: " + name)
        files[name] = data
    return policy, files


def extract_toolchain(archive, pin, work):
    # Copy to the verifier's scratch disk while hashing. Only these exact bytes are extracted.
    local = work / "toolchain.tar.zst"
    h = hashlib.sha256()
    total = 0
    with os.fdopen(os.open(archive, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), "rb") as src:
        if not stat.S_ISREG(os.fstat(src.fileno()).st_mode):
            raise ValueError("Toolchain archive must be a regular file")
        with local.open("xb") as dst:
            while chunk := src.read(1024 * 1024):
                total += len(chunk)
                if total > pin["size_bytes"]:
                    raise ValueError("Toolchain archive exceeds pin")
                h.update(chunk)
                dst.write(chunk)
    if h.hexdigest() != pin["sha256"] or total != pin["size_bytes"]:
        raise ValueError("Toolchain archive differs from the release pin")
    toolchain = work / "toolchain"
    toolchain.mkdir()
    subprocess.run(["/usr/bin/tar", "--zstd", "-xf", str(local), "--strip-components=1",
                    "--no-same-owner", "-C", str(toolchain)], env={"PATH": SYSTEM_PATH},
                   stdin=subprocess.DEVNULL, check=True, timeout=300)
    local.unlink()
    return toolchain


def validate_solution(source):
    # Keep the seed's restricted token set. This narrow profile reserves them in comments too.
    text = source.decode("utf-8")
    restricted = (r"\b(sorry|admit|axiom|unsafe|partial|native_decide|extern|implemented_by|"
                  r"run_tac|elab|macro)\b|debug\.skipKernelTC|decide\s*\+native")
    if re.search(restricted, text):
        raise ValueError("Restricted proof source token")


def stage(project, frozen, solution):
    project.mkdir()
    for name, data in frozen.items():
        target = project / name
        target.parent.mkdir(exist_ok=True, parents=True)
        target.write_bytes(data)
    (project / "Solution.lean").write_bytes(solution)


def export_digest(log):
    # GNU sha256sum --tag is passed the same read-only solution export as the kernels.
    # Any additional matching output (including text from the solution) invalidates the record.
    matches = re.findall(rb"SHA256 \([^()\n]*\) = ([0-9a-f]{64})", log)
    return matches[0].decode("ascii") if len(matches) == 1 else None


def compare(project, toolchain, out):
    command = [str(toolchain / "bin/lake"), "comparator", "--paranoid", "--config", "comparator.json"]
    clean_home = project.parent / "home"
    clean_home.mkdir()
    env = {"PATH": str(toolchain / "bin") + ":" + SYSTEM_PATH,
           "HOME": str(clean_home), "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8"}
    # A nonzero exit, an incomplete kernel list or an infrastructural failure never passes.
    with subprocess.Popen(command, cwd=project, env=env, stdin=subprocess.DEVNULL,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True) as proc:
        try:
            log = bytearray()
            deadline = time.monotonic() + 600
            with selectors.DefaultSelector() as selector, out.open("xb") as stream:
                selector.register(proc.stdout, selectors.EVENT_READ)
                while True:
                    left = deadline - time.monotonic()
                    if left <= 0 or not selector.select(left):
                        raise TimeoutError("Comparator exceeded ten minutes")
                    data = os.read(proc.stdout.fileno(), 65536)
                    if not data:
                        break
                    if len(log) + len(data) > LOG_LIMIT:
                        raise ValueError("Comparator log exceeded its limit")
                    stream.write(data)
                    log.extend(data)
            rc = proc.wait(timeout=max(0.1, deadline - time.monotonic()))
        finally:
            # Kill leftover children even if the original process has already exited.
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            proc.stdout.close()
    lines = set(bytes(log).decode("utf-8", "replace").splitlines())
    seen = [name for name in KERNELS if name + " kernel accepts the solution" in lines]
    ok = (rc == 0 and len(seen) == len(KERNELS) and "Your solution is okay!" in lines
          and "export digest kernel accepts the solution" in lines and export_digest(log) is not None)
    return rc, seen, ok


def verify(args, report):
    policy, frozen = load_profile(ROOT, args.profile_sha256)
    solution = file_bytes(args.solution, SOLUTION_LIMIT)
    validate_solution(solution)
    config = json.loads(frozen["comparator.json"])
    report.update(profile_sha256=args.profile_sha256, solution_sha256=sha(solution),
                  obligations=config["theorem_names"], permitted_axioms=config["permitted_axioms"],
                  command=["lake", "comparator", "--paranoid", "--config", "comparator.json"])
    if platform.system() != "Linux" or platform.machine() not in policy["toolchains"]:
        raise ValueError("Linux x86_64 or aarch64 with bubblewrap is required")
    if os.geteuid() == 0:
        raise ValueError("Use an unprivileged worker account")
    if not Path("/usr/bin/bwrap").is_file():
        raise ValueError("bubblewrap is required")
    pin = policy["toolchains"][platform.machine()]
    report["required_toolchain_sha256"] = pin["sha256"]
    with tempfile.TemporaryDirectory(prefix="leanregen-", dir="/var/tmp") as scratch:
        work = Path(scratch)
        toolchain = extract_toolchain(args.toolchain_archive, pin, work)
        report["toolchain_archive_checked"] = True
        project = work / "project"
        stage(project, frozen, solution)
        log = args.output / "comparator.log"
        rc, kernels, ok = compare(project, toolchain, log)
        report.update(exit_code=rc, kernel_acceptance_lines=kernels, log_sha256=sha(log.read_bytes()))
        if ok:
            report["proof_export_sha256"] = export_digest(log.read_bytes())
            report["status"] = "LOCAL_PARANOID_COMPARISON_PASSED"
            return 0
        report["status"] = "COMPARISON_DID_NOT_PASS"
        return 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile-sha256", required=True, help="from the verifier's own trusted policy")
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--toolchain-archive", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True, help="new directory for this run")
    args = parser.parse_args()
    report = {"format": "lean-regen-local-comparison-v1", "status": "BLOCKED",
              "run_id": str(uuid.uuid4()), "started_at": datetime.now(timezone.utc).isoformat(),
              "platform": {"system": platform.system(), "machine": platform.machine(),
                           "kernel_release": platform.release()},
              "verifier_sha256": sha(Path(__file__).read_bytes()),
              "signed": False, "release_authorized": False, "toolchain_archive_checked": False}
    try:
        args.output = args.output.absolute()
        args.output.mkdir(mode=0o700, exist_ok=False)
    except OSError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    try:
        rc = verify(args, report)
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as exc:
        report["reason"] = str(exc)
        rc = 2
    report["finished_at"] = datetime.now(timezone.utc).isoformat()
    (args.output / "result.json").write_text(json.dumps(report, indent=2) + "\n")
    print(report["status"])
    return rc


if __name__ == "__main__":
    sys.exit(main())
