import VerifiedInventory.Implementation

namespace VerifiedInventory

theorem initial_exact (capacity : Nat) :
    initial capacity = { available := capacity, reserved := 0 } := by
  sorry

theorem initial_wellFormed (capacity : Nat) : WellFormed capacity (initial capacity) := by
  sorry

theorem reserve_refines (s : State) (q : Nat) : ReserveSpec s q (reserve s q) := by
  sorry

theorem release_refines (s : State) (q : Nat) : ReleaseSpec s q (release s q) := by
  sorry

theorem reserve_succeeds (s : State) (q : Nat) (h : ReserveAllowed s q) :
    reserve s q = .accepted
      { available := s.available - q, reserved := s.reserved + q } := by
  sorry

theorem release_succeeds (s : State) (q : Nat) (h : ReleaseAllowed s q) :
    release s q = .accepted
      { available := s.available + q, reserved := s.reserved - q } := by
  sorry

theorem reserve_rejects_unchanged (s : State) (q : Nat) (h : ¬ ReserveAllowed s q) :
    reserve s q = .rejected s := by
  sorry

theorem release_rejects_unchanged (s : State) (q : Nat) (h : ¬ ReleaseAllowed s q) :
    release s q = .rejected s := by
  sorry

theorem reserve_preserves (capacity : Nat) (s : State) (q : Nat)
    (hs : WellFormed capacity s) :
    WellFormed capacity (reserve s q).state := by
  sorry

theorem release_preserves (capacity : Nat) (s : State) (q : Nat)
    (hs : WellFormed capacity s) :
    WellFormed capacity (release s q).state := by
  sorry

theorem step_refines (s : State) (c : Command) : StepSpec s c (step s c) := by
  sorry

theorem step_preserves (capacity : Nat) (s : State) (c : Command)
    (hs : WellFormed capacity s) :
    WellFormed capacity (step s c).state := by
  sorry

theorem run_preserves (capacity : Nat) (cs : List Command) (s : State)
    (hs : WellFormed capacity s) :
    WellFormed capacity (run s cs) := by
  sorry

theorem all_runs_preserve (capacity : Nat) (cs : List Command) :
    WellFormed capacity (run (initial capacity) cs) := by
  sorry

end VerifiedInventory
