"""Focused checks of journal boundaries and the installed trace CLI."""
from io import BytesIO
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import check_trace as check


START = {"type": "start", "format": check.TRACE_FORMAT, "capacity": 10, "available": 8, "reserved": 2}
STEP = {"type": "step", "seq": 1, "operation": "reserve", "quantity": 8, "outcome": "accepted",
        "available": 0, "reserved": 10}
END = {"type": "end", "count": 1}


def journal(*rows):
    return b"\n".join(json.dumps(row).encode("utf-8") for row in rows) + b"\n"


def run(*args, data=None):
    result = subprocess.run([sys.executable, "-B", str(check.HERE / "check_trace.py"), *map(str, args)],
                            input=data, capture_output=True, check=False)
    return result.returncode, json.loads(result.stdout)


class TraceChecks(unittest.TestCase):
    def test_real_captured_transactions_and_boundary_counterexample(self):
        rc, good = run()
        self.assertEqual((rc, good["status"]), (0, "TRACE_MATCH"))
        self.assertGreater(good["matched_steps"], 1)
        self.assertEqual(good["matched_steps"], good["total_steps"])
        rc, bad = run(check.FIXTURES / "wrong.jsonl")
        self.assertEqual((rc, bad["status"], bad["seq"], bad["line"]), (1, "COUNTEREXAMPLE", 4, 5))
        self.assertEqual(bad["before"]["available"], bad["command"]["quantity"])
        self.assertEqual((bad["expected"]["outcome"], bad["observed"]["outcome"]), ("accepted", "rejected"))

    def test_snapshot_input_and_full_observation_checked(self):
        rc, good = run("-", data=journal(START, STEP, END))
        self.assertEqual(rc, 0, good)
        rc, bad = run("-", data=journal(START, dict(STEP, available=-1), END))
        self.assertEqual(rc, 1, bad)
        self.assertEqual(bad["expected"]["available"], 0)
        self.assertEqual(bad["observed"]["available"], -1)

    def test_incomplete_empty_extra_and_out_of_order_journals(self):
        bad_inputs = [b"", journal(START), journal(START, END), journal(START, STEP),
                      journal(START, STEP, dict(END, count=2)), journal(START, STEP, END, END),
                      journal(START, STEP, STEP, dict(END, count=2)),
                      journal(START, dict(STEP, seq=2), END)]
        for data in bad_inputs:
            with self.subTest(data=data), self.assertRaises(check.JournalError):
                check.read_journal(data)

    def test_reject_ambiguous_fields_and_invalid_numeric_types(self):
        for row in (dict(STEP, quantity=True), dict(STEP, quantity=0.0), dict(STEP, quantity=-1),
                    dict(STEP, quantity=2**63), dict(STEP, info="x"), dict(STEP, operation=["reserve"]),
                    dict(STEP, outcome=None), {k:v for k,v in STEP.items() if k!="available"}):
            with self.subTest(row=row), self.assertRaises(check.JournalError):
                check.read_journal(journal(START, row, END))
        for data in (journal(START, STEP, END).replace(b'"seq": 1', b'"seq": 2, "seq": 1'),
                     journal(dict(START, reserved=1), STEP, END), b"\xff",
                     journal(START, STEP, END).replace(b"\n", b"\n\n", 1)):
            with self.subTest(data=data), self.assertRaises(check.JournalError):
                check.read_journal(data)

    def test_missing_vector_cannot_count_as_match(self):
        start = dict(START, capacity=100_003, available=100_001)
        rc, result = run("-", data=journal(start, STEP, END))
        self.assertEqual((rc, result["status"], result["matched_steps"]), (3, "OUTSIDE_COVERAGE", 0))

    def test_truncated_trace_does_not_emit_counterexample(self):
        rc, result = run("-", data=journal(START, dict(STEP, outcome="rejected")))
        self.assertEqual((rc, result["status"]), (2, "INVALID_TRACE"))

    def test_oversized_stream_and_record(self):
        with self.assertRaises(check.JournalError):
            check.read_input(BytesIO(b"x" * (check.MAX_BYTES + 1)))
        with self.assertRaises(check.JournalError):
            check.read_journal(b" " * (check.MAX_LINE + 1))

    def test_unavailable_native_reference_is_a_failure(self):
        with tempfile.TemporaryDirectory() as td:
            rc, result = run("--tool-bin", Path(td) / "missing", "-", data=journal(START, STEP, END))
            self.assertEqual((rc, result["status"]), (2, "UNAVAILABLE"))

    def test_report_creation_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "report.json"
            rc, result = run("--report", path)
            self.assertEqual(rc, 0)
            self.assertEqual(json.loads(path.read_bytes()), result)
            original = path.read_bytes()
            rc, failed = run("--report", path, check.FIXTURES / "wrong.jsonl")
            self.assertEqual((rc, failed["status"], failed["check_status"]),
                             (2, "REPORT_WRITE_FAILED", "COUNTEREXAMPLE"))
            self.assertEqual(path.read_bytes(), original)

    def test_partial_and_ambiguous_oracle_cannot_pass(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "oracle.jsonl"
            row = {"before_available": 8, "before_reserved": 2, **{k:v for k,v in STEP.items()
                                                                  if k not in ("type", "seq")}}
            path.write_bytes(journal(row, row))
            with self.assertRaisesRegex(ValueError, "digest mismatch"):
                check.bundled_oracle(path)
            with patch.object(check, "ORACLE_SHA256", check.sha(path.read_bytes())):
                with self.assertRaisesRegex(ValueError, "Ambiguous bundled"):
                    check.bundled_oracle(path)


if __name__ == "__main__":
    unittest.main()
