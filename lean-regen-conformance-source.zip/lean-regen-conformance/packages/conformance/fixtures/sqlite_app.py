"""Small conventional SQLite inventory implementation used as a synthetic customer app."""
from contextlib import closing
import sqlite3


def initialize(path, capacity):
    if path.exists():
        raise FileExistsError("Use a fresh fixture database")
    with closing(sqlite3.connect(path)) as db, db:
        db.execute("""CREATE TABLE stock (
            singleton INTEGER PRIMARY KEY CHECK(singleton=1), capacity INTEGER NOT NULL,
            available INTEGER NOT NULL CHECK(available>=0), reserved INTEGER NOT NULL CHECK(reserved>=0),
            CHECK(available+reserved=capacity))""")
        db.execute("INSERT INTO stock VALUES(1,?,?,0)", (capacity, capacity))


def apply(path, operation, quantity, exact_fill_bug=False):
    if operation == "reserve":
        query = """UPDATE stock SET available = available - :q, reserved = reserved + :q
                   WHERE singleton=1 AND :q > 0 AND :q <= available"""
        if exact_fill_bug:
            query = query.replace(":q <= available", ":q < available")
    elif operation == "release":
        query = """UPDATE stock SET available = available + :q, reserved = reserved - :q
                   WHERE singleton=1 AND :q > 0 AND :q <= reserved"""
    else:
        raise ValueError("Unknown stock operation")
    with closing(sqlite3.connect(path)) as db, db:
        updated = db.execute(query, {"q":quantity}).rowcount
    return "accepted" if updated == 1 else "rejected"


def committed_state(path):
    with closing(sqlite3.connect(path)) as db:
        return db.execute("SELECT available,reserved FROM stock WHERE singleton=1").fetchone()
