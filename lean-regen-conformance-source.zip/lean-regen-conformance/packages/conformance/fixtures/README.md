# SQLiteの実測ログとLeanの参照値

予約・解放の応答と、操作完了後に保存された在庫数を照合するためのデータです。すべて合成の操作を実際のSQLiteファイルに対して実行しました。顧客データは使用していません。

| ファイル | 取得方法 | 確認できること |
|---|---|---|
| `sqlite.jsonl` | SQLの条件付きUPDATEを16回実行。コミットごとに新たな接続から残高を読み出した | 容量10。予約・解放の成功、数量0、超過、全数の予約・解放 |
| `wrong.jsonl` | 予約の上限条件を `<=` から `<` に変更した実装に、同じ16操作を入力 | 非負・数量保存の制約は全16件で成立。4件目の「利用可能8を全数予約」で、本来の成功を拒否 |
| `project-sqlite.jsonl` | このリポジトリの `examples/sqlite_inventory` に同じ16操作を入力し、各コミット後に `inspect` で残高を取得 | ネイティブLeanを内部で呼ぶ既存アダプターを通した結果が、通常のSQL実装の記録とバイト単位で一致 |
| `sqlite-64bit.jsonl` | 容量 `2^63−1` のSQLiteに9操作を入力 | SQLiteの最大整数、`2^53+1`、ゼロ、超過を含む |
| `sqlite-1000.jsonl` | 容量1000のSQLiteに6操作を入力 | 同梱参照値の範囲外。ネイティブモードで同じログの全6件を照合できる |
| `oracle.jsonl` | Lean 4.19.0からビルドした実行ファイルに1,153通りの入力を個別に渡し、標準出力を記録 | 445件の成功と708件の拒否。結果の決定には凍結済みの `VerifiedInventory.step` を使用 |

容量0〜10では、各容量について、合計が容量に等しいすべての初期残高、2つの操作、数量0〜容量+1の組み合わせ1,144件を収録しました。残り9件は64ビット境界の経路上の入力です。連続する操作の検査は同じデータベースに対して直列に行います。ここで得た結果の適用範囲は、記録した操作・応答・コミット済み残高です。並行実行や実サービスでの工数削減は測定していません。

## 手元で再取得する

リポジトリのルートで次を実行します。出力先には新しいディレクトリを指定してください。SQLのみの実装はPython標準ライブラリで動きます。

```sh
python3 packages/conformance/fixtures/capture.py sqlite --out ../new-observations
python3 packages/conformance/check_trace.py ../new-observations/sqlite.jsonl
python3 packages/conformance/check_trace.py ../new-observations/wrong.jsonl
```

最後のコマンドは終了コード1を返します。報告の `seq` は4、JSONLの行番号は5です。処理前は利用可能8・予約済み2で、参照値は「成功、利用可能0、予約済み10」、アプリで観測した値は「拒否、利用可能8、予約済み2」です。既存アプリへの適用では、アプリの応答とコミット後の数量をこの形式で書き出して同じコマンドに渡します。

参照値とプロジェクト付属アダプターのログを再生成するには、Python 3.11以上と信頼できるLean/Lake 4.19.0が必要です。ビルド環境は[付属アダプターの説明](../../../examples/sqlite_inventory/README.md)を参照してください。

```sh
python3 packages/conformance/fixtures/capture.py all --tool-bin /path/to/lean-4.19.0/bin --out ../fresh-reference
cmp packages/conformance/fixtures/oracle.jsonl ../fresh-reference/oracle.jsonl
python3 packages/conformance/check_trace.py ../new-observations/sqlite-1000.jsonl --tool-bin /path/to/lean-4.19.0/bin
```

`capture.json` には実測日時、Python・SQLite・Lean・Lakeの版、実行ファイルとソースのハッシュ、各ログの件数とハッシュを記録しています。独立した2回の再生成の比較結果は `reproduction.json` にあります。
