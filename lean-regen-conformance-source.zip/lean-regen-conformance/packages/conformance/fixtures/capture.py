#!/usr/bin/env python3
"""Capture real synthetic SQLite observations and optionally rebuild the native Lean vectors."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import re
import sqlite3
import subprocess
import sys
import tempfile
import time

import sqlite_app

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
EXAMPLE = ROOT / "examples/sqlite_inventory"
SEED = ROOT / "packages/lean-verified-sdlc/assets/lean-starter"
MAX_INT = 2**63-1
SMALL_OPERATIONS = [
    ("reserve",3), ("release",0), ("release",1), ("reserve",8),
    ("reserve",1), ("release",11), ("release",10), ("release",1),
    ("reserve",11), ("reserve",0), ("reserve",10), ("release",3),
    ("reserve",2), ("release",9), ("reserve",1), ("release",1),
]
OUTSIDE_OPERATIONS = [
    ("reserve",250), ("release",50), ("reserve",801), ("reserve",800),
    ("release",0), ("release",1000),
]
LARGE_OPERATIONS = [
    ("reserve",MAX_INT), ("release",1), ("reserve",2), ("release",MAX_INT),
    ("release",MAX_INT-1), ("reserve",2**53+1), ("release",2**53+1),
    ("reserve",0), ("release",0),
]


def file_sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_rows(path, rows):
    with path.open("x",encoding="utf-8",newline="\n") as output:
        for row in rows:
            output.write(json.dumps(row,separators=(",", ":"),ensure_ascii=False)+"\n")


def observe(out, name, capacity, operations, apply, state):
    available, reserved = state()
    rows = [{"type":"start","format":"lean-regen-inventory-trace-v1","capacity":capacity,
             "available":available,"reserved":reserved}]
    for seq, (operation, quantity) in enumerate(operations,1):
        outcome = apply(seq,operation,quantity)
        available, reserved = state()
        rows.append({"type":"step","seq":seq,"operation":operation,"quantity":quantity,
                     "outcome":outcome,"available":available,"reserved":reserved})
    steps = rows[1:]
    rows.append({"type":"end","count":len(steps)})
    write_rows(out/name,rows)
    return {"steps":len(steps),"accepted":sum(s["outcome"]=="accepted" for s in steps),
            "rejected":sum(s["outcome"]=="rejected" for s in steps),
            "nonnegative_and_conserving":sum(s["available"]>=0 and s["reserved"]>=0 and
                                             s["available"]+s["reserved"]==capacity for s in steps),
            "sha256":file_sha(out/name)}


def capture_sql(out,scratch):
    logs = {}
    for name,capacity,operations,bug in (
        ("sqlite.jsonl",10,SMALL_OPERATIONS,False),
        ("wrong.jsonl",10,SMALL_OPERATIONS,True),
        ("sqlite-64bit.jsonl",MAX_INT,LARGE_OPERATIONS,False),
        ("sqlite-1000.jsonl",1000,OUTSIDE_OPERATIONS,False),
    ):
        db = scratch/(name+".sqlite")
        sqlite_app.initialize(db,capacity)
        def submit(seq,operation,quantity):
            return sqlite_app.apply(db,operation,quantity,exact_fill_bug=bug)
        logs[name] = observe(out,name,capacity,operations,submit,lambda:sqlite_app.committed_state(db))
    return logs


def native_row(engine, available, reserved, operation, quantity):
    proc = subprocess.run([str(engine),str(available),str(reserved),operation,str(quantity)],
                          check=True,capture_output=True,timeout=10)
    match = re.fullmatch(rb"(accepted|rejected) ([0-9]+) ([0-9]+)\n",proc.stdout)
    if not match:
        raise ValueError("Unexpected native Lean response")
    return {"before_available":available,"before_reserved":reserved,"operation":operation,"quantity":quantity,
            "outcome":match[1].decode(),"available":int(match[2]),"reserved":int(match[3])}


def capture_oracle(engine,out):
    rows = []
    for capacity in range(11):
        for available in range(capacity+1):
            for operation in ("reserve","release"):
                for quantity in range(capacity+2):
                    rows.append(native_row(engine,available,capacity-available,operation,quantity))
    small = len(rows)
    available, reserved = MAX_INT,0
    for operation,quantity in LARGE_OPERATIONS:
        row = native_row(engine,available,reserved,operation,quantity)
        rows.append(row)
        available,reserved = row["available"],row["reserved"]
    keys = {(r["before_available"],r["before_reserved"],r["operation"],r["quantity"]) for r in rows}
    if len(keys) != len(rows):
        raise ValueError("Duplicate oracle input")
    write_rows(out/"oracle.jsonl",rows)
    return {"rows":len(rows),"small_rows":small,"large_rows":len(rows)-small,
            "accepted":sum(r["outcome"]=="accepted" for r in rows),
            "rejected":sum(r["outcome"]=="rejected" for r in rows),"sha256":file_sha(out/"oracle.jsonl")}


def capture_all(out,scratch,tool_bin,metadata):
    sys.path.insert(0,str(EXAMPLE))
    import build_engine
    import inventory
    from leanregen import check_upstream, doctor
    start = time.monotonic()
    build = scratch/"build"
    build_engine.build(tool_bin,build)
    engine = build/".lake/build/bin/inventory_step"
    metadata["native_build_seconds"] = round(time.monotonic()-start,3)
    runtime = doctor(tool_bin)
    metadata["toolchain"] = {k:v for k,v in runtime.items() if k in ("lean","lake","lean_sha256","lake_sha256")}
    metadata["native_engine_sha256"] = file_sha(engine)
    metadata["upstream_files_checked"] = check_upstream()["file_count"]
    inputs = [SEED/"VerifiedInventory/Specification.lean", SEED/"VerifiedInventory/Implementation.lean",
              SEED/"VerifiedInventory/Proofs.lean", SEED/"Contract.lean", EXAMPLE/"Bridge.lean",
              EXAMPLE/"inventory.py", EXAMPLE/"build_engine.py", HERE/"capture.py", HERE/"sqlite_app.py"]
    metadata["source_sha256"] = {p.relative_to(ROOT).as_posix(): file_sha(p) for p in inputs}
    db = scratch/"bundled-adapter.sqlite"
    inventory.initialize(db,10)
    def submit(seq,operation,quantity):
        return inventory.apply_request(db,engine,f"synthetic-{seq}",operation,quantity)["outcome"]
    def state():
        observed = inventory.inspect(db)
        return observed["available"],observed["reserved"]
    metadata["observations"]["project-sqlite.jsonl"] = observe(
        out,"project-sqlite.jsonl",10,SMALL_OPERATIONS,submit,state)
    start = time.monotonic()
    metadata["oracle"] = capture_oracle(engine,out)
    metadata["native_oracle_seconds"] = round(time.monotonic()-start,3)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode",choices=("sqlite","all"))
    parser.add_argument("--out",type=Path,required=True,help="New output directory")
    parser.add_argument("--tool-bin",type=Path,help="Trusted Lean 4.19.0 bin directory (all mode)")
    args = parser.parse_args()
    if (args.mode=="all") != (args.tool_bin is not None):
        parser.error("Use --tool-bin in all mode only")
    if args.out.exists() or args.out.is_symlink():
        parser.error("Output directory must be new")
    args.out.parent.mkdir(parents=True,exist_ok=True)
    try:
        with tempfile.TemporaryDirectory() as scratch, tempfile.TemporaryDirectory(dir=args.out.parent) as staging:
            out = Path(staging)/"complete"
            out.mkdir()
            metadata={"format":"lean-regen-fixture-capture-v1","recorded_utc":datetime.now(timezone.utc).isoformat(),
                      "platform":platform.system()+" "+platform.machine(),"python":platform.python_version(),
                      "sqlite":sqlite3.sqlite_version,"data":"synthetic"}
            metadata["observations"] = capture_sql(out,Path(scratch))
            if args.mode=="all":
                capture_all(out,Path(scratch),args.tool_bin,metadata)
            (out/"capture.json").write_text(json.dumps(metadata,indent=2)+"\n",encoding="utf-8")
            out.rename(args.out)
        print("Wrote traces in",args.out)
    except (ValueError, OSError, sqlite3.Error, subprocess.SubprocessError) as exc:
        parser.exit(2,f"Capture failed: {exc}\n")


if __name__ == "__main__":
    main()
