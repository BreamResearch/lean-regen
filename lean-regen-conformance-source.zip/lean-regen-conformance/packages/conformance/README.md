# Inventory trace conformance

既存アプリが「残り8枠のとき8枠を予約できる」という契約を守るか、実際の応答・コミット後の残高をLeanの参照結果と照合します。Python 3.9以上の標準ライブラリだけで、登録せずオフラインで試せます。

Compare your app's recorded decisions **and committed balances** with results produced by the original Lean inventory function. The offline checker needs Python 3.9+, takes data only and requires no account.

## Try it / 試す

リポジトリのルートで実行してください。The first command checks 16 transactions captured from an independent SQLite application. The second exposes a boundary error that keeps the totals in balance.

```sh
python3 packages/conformance/check_trace.py
python3 packages/conformance/check_trace.py packages/conformance/fixtures/wrong.jsonl
python3 packages/conformance/check_trace.py my-trace.jsonl --report new-report.json
```

反例は5行目の4操作目です。利用可能8、予約済み2の状態で8枠を要求しました。期待値は受理・利用可能0・予約済み10、実測値は拒否・利用可能8・予約済み2です。レポートは最初の不一致、その直前の状態、入力、参照結果、実測値を示します。

| Exit | JSON `status` | Meaning / 意味 |
|---|---|---|
| 0 | `TRACE_MATCH` | All recorded steps matched / 記録された全操作が一致 |
| 1 | `COUNTEREXAMPLE` | First semantic mismatch / 最初の不一致 |
| 2 | `INVALID_TRACE`, `UNAVAILABLE`, `REPORT_WRITE_FAILED` | Invalid or incomplete journal, unavailable reference, or output error / ログ不備・参照失敗・保存エラー |
| 3 | `OUTSIDE_COVERAGE` | No offline vector for the exact input / 固定ベクトルの対象外 |

## Export a journal / 自分のログを接続する

Export one UTF-8 JSON object per line. Capture one resource, one committed transaction at a time, in commit order. Record the app's observed decision and read its persisted post-state. Export each distinct operation once, omitting transport retries. The tool can read a file or standard input (`-`).

```jsonl
{"type":"start","format":"lean-regen-inventory-trace-v1","capacity":10,"available":8,"reserved":2}
{"type":"step","seq":1,"operation":"reserve","quantity":8,"outcome":"accepted","available":0,"reserved":10}
{"type":"end","count":1}
```

- 開始行は既知のスナップショットです。`available + reserved = capacity` を満たす非負の整数を指定します。
- `seq` starts at 1 and increases by 1. Use `reserve` or `release`, and `accepted` or `rejected`. A zero-quantity request is valid input and the Lean reference rejects it.
- 最終行に1件以上の操作件数を記録します。検査前に全行を読み、欠番、重複フィールド、型違い、未知のフィールド、欠落した最終行を拒否します。
- Inputs fit a nonnegative signed 64-bit integer. Observed balances may also be negative so an erroneous debit can appear as a counterexample. Limits are 8 MiB per journal, 4,096 bytes per record and 50,000 steps.
- 本人確認、所有権、並行実行の順序、ログ取得の完全性は別途確認が必要です。一致が示す範囲は、与えた初期状態から記録された操作列までです。

## Exact reference / 参照結果の範囲

The 1,153 bundled vectors come from the compiled Lean 4.19.0 `VerifiedInventory.step`. They cover all well-formed states for capacities 0 through 10, both operations and quantities 0 through capacity + 1, plus nine selected transitions at signed 64-bit maximum capacity. The checker validates the corpus SHA-256 before lookup. [Capture provenance](fixtures/capture.json) · [Lean bridge](../../examples/sqlite_inventory/Bridge.lean)

対象外の入力は、Python 3.11以上と信頼済みの公式Lean/Lake 4.19.0を使って検査できます。毎回、新しい一時ディレクトリで同梱の参照ソースをビルドします。次の例は容量1,000の実SQLiteログを照合します。Your application stays offline from the checker. The native mode invokes the shipped reference for each distinct input in the trace.

```sh
python3 packages/conformance/check_trace.py packages/conformance/fixtures/sqlite-1000.jsonl \
  --tool-bin /absolute/path/to/lean-4.19.0/bin
```

To reproduce the observations and vectors independently on a supported native build host, generate a new directory and compare the resulting corpus with the shipped file. [Build prerequisites](../../examples/sqlite_inventory/README.md)

```sh
python3 packages/conformance/fixtures/capture.py all --tool-bin /absolute/path/to/lean-4.19.0/bin --out ../rebuilt-capture
cmp ../rebuilt-capture/oracle.jsonl packages/conformance/fixtures/oracle.jsonl
```

検証記録 / Verification records · [CLI runs and tests](validation.json) · [Byte-for-byte fixture reproduction](fixtures/reproduction.json)
