#!/usr/bin/env python3
"""Build a deterministic, source-only Python zipapp for the inventory trace checker."""
import argparse
import hashlib
from io import BytesIO
import json
from pathlib import Path
import sys
from zipfile import ZIP_STORED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from leanregen import check_upstream

# The other 68 names are explicitly enumerated in the digest-pinned provenance index.
# The native builder verifies every upstream file, including documentation and evidence.
LOCAL_FILES = (
    "LICENSE", "NOTICE", "THIRD_PARTY_NOTICES.md", "UPSTREAM_PROVENANCE.json",
    "scripts/leanregen.py",
    "examples/sqlite_inventory/Bridge.lean", "examples/sqlite_inventory/Migration.lean",
    "examples/sqlite_inventory/build_engine.py", "examples/sqlite_inventory/inventory.py",
    "packages/conformance/check_trace.py",
    "packages/conformance/fixtures/README.md", "packages/conformance/fixtures/capture.py",
    "packages/conformance/fixtures/sqlite_app.py", "packages/conformance/fixtures/capture.json",
    "packages/conformance/fixtures/reproduction.json", "packages/conformance/fixtures/oracle.jsonl",
    "packages/conformance/fixtures/sqlite.jsonl", "packages/conformance/fixtures/wrong.jsonl",
    "packages/conformance/fixtures/sqlite-1000.jsonl", "packages/conformance/fixtures/sqlite-64bit.jsonl",
    "packages/conformance/fixtures/project-sqlite.jsonl",
)
CHECKER = "packages/conformance/check_trace.py"

# The entry point opens its own zipimport archive. Only builder-selected files
# are materialized. The trace may come from stdin and all CLI paths keep their
# original meaning because the process never changes the caller's directory.
ENTRY = '''"""Start the bundled checker with a private copy of its source tree."""
import hashlib
from pathlib import Path
import runpy
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

FILES = @FILES@


def main():
    if sys.version_info < (3, 9):
        print("Lean Regen requires Python 3.9 or later.", file=sys.stderr)
        return 2
    with TemporaryDirectory(prefix="lean-regen-kit-") as directory:
        root = Path(directory)
        with ZipFile(__loader__.archive) as archive:
            for name, (size, digest) in FILES.items():
                info = archive.getinfo(name)
                if info.file_size != size:
                    raise ValueError("Unexpected bundled file size: " + name)
                data = archive.read(info)
                if hashlib.sha256(data).hexdigest() != digest:
                    raise ValueError("Unexpected bundled file digest: " + name)
                destination = root / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
        checker = runpy.run_path(str(root / @CHECKER@))
        return checker["main"]()


if __name__ == "__main__":
    sys.exit(main())
'''


def make_archive():
    check_upstream()
    manifest = json.loads((ROOT / "UPSTREAM_PROVENANCE.json").read_bytes())
    historical = {"packages/lean-verified-sdlc/" + name: digest
                  for name, digest in manifest["files"].items()}
    contents = {}
    for name in sorted((*LOCAL_FILES, *historical)):
        path = ROOT / name
        if path.resolve() != path or not path.is_file():
            raise ValueError(f"Expected a regular project file: {name}")
        data = path.read_bytes()
        if name in historical and hashlib.sha256(data).hexdigest() != historical[name]:
            raise ValueError(f"Historical source digest changed: {name}")
        contents[name] = data

    files = {name: [len(data), hashlib.sha256(data).hexdigest()]
             for name, data in contents.items()}
    entry = ENTRY.replace("@FILES@", json.dumps(files, indent=2)).replace("@CHECKER@", repr(CHECKER))
    contents["__main__.py"] = entry.encode("utf-8")

    # Stored records avoid compressor-version differences. The ZIP needs no native launcher.
    stream = BytesIO()
    with ZipFile(stream, "w", compression=ZIP_STORED) as archive:
        for name, data in sorted(contents.items()):
            info = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    return stream.getvalue()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True, help="New output .pyz path")
    args = parser.parse_args()
    try:
        data = make_archive()
        with args.out.open("xb") as out:
            out.write(data)
        print(hashlib.sha256(data).hexdigest(), args.out)
    except (OSError, ValueError) as exc:
        parser.exit(2, f"Build failed: {exc}\n")


if __name__ == "__main__":
    main()
