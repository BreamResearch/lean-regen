#!/usr/bin/env python3
"""Build a deterministic, source-only Python zipapp for the inventory trace checker."""
import argparse
import hashlib
from io import BytesIO
import json
from pathlib import Path
import sys
import tempfile
from zipfile import ZIP_STORED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from lean_runtime import PROVENANCE_SHA256, check_upstream

# The other 68 names are explicitly enumerated in the digest-pinned provenance index.
# The native builder verifies every upstream file, including documentation and evidence.
RUNTIME_FILES = (
    "LICENSE", "NOTICE", "THIRD_PARTY_NOTICES.md", "UPSTREAM_PROVENANCE.json",
    "scripts/lean_runtime.py",
    "examples/sqlite_inventory/Bridge.lean", "examples/sqlite_inventory/Migration.lean",
    "examples/sqlite_inventory/build_engine.py", "packages/conformance/check_trace.py",
    "packages/conformance/fixtures/oracle.jsonl", "packages/conformance/fixtures/sqlite.jsonl",
)
SOURCE_ONLY = (
    "packages/conformance/build_zipapp.py", "packages/conformance/test_trace.py",
    "packages/conformance/README.md", "packages/conformance/validation.json",
    "packages/conformance/fixtures/README.md", "packages/conformance/fixtures/capture.py",
    "packages/conformance/fixtures/sqlite_app.py", "packages/conformance/fixtures/capture.json",
    "packages/conformance/fixtures/reproduction.json", "packages/conformance/fixtures/wrong.jsonl",
    "packages/conformance/fixtures/sqlite-1000.jsonl", "packages/conformance/fixtures/sqlite-64bit.jsonl",
    "packages/conformance/fixtures/project-sqlite.jsonl",
    "examples/sqlite_inventory/inventory.py", "examples/sqlite_inventory/test_inventory.py",
    "examples/sqlite_inventory/README.md",
)
SOURCE_ROOT = "lean-regen-conformance/"
SOURCE_GUIDE = """# Inventory trace checker · 在庫ログ照合器

With Python 3.9 or later, run these commands in the directory containing this file.
Python 3.9以上でこのファイルのあるディレクトリから実行できます。

```sh
python3 packages/conformance/check_trace.py
python3 packages/conformance/check_trace.py packages/conformance/fixtures/wrong.jsonl
```

The first run matches all 16 recorded operations. The second reports the failed exact-fill
reservation at operation 4 and exits 1. 自分のアプリの操作記録を検査するには、JSONLファイルを
同じコマンドに渡します。[Log format and native mode / 記録形式とネイティブモード](packages/conformance/README.md)

## Rebuild · 配布物を再生成する

```sh
python3 -B -m unittest discover -s packages/conformance -p 'test_*.py'
python3 packages/conformance/build_zipapp.py --release-dir ../new-checker-release
```

Use a new output directory. The command creates the checker, this source ZIP, the
counterexample and the checksums. The bundled SOURCE-MANIFEST.json identifies each distributed
source file by path and SHA-256. 新しいディレクトリを指定すると、配布した4ファイルを再生成できます。

For native checks, use Python 3.11+, Lean/Lake 4.19.0 and a working native linker.
On Apple Silicon with macOS 27, set the following before building. macOS 27のApple Siliconでは、
ネイティブビルドの前にXcodeのリンカーを選びます。

```sh
export CCC_OVERRIDE_OPTIONS='+--ld-path=/usr/bin/ld'
export MACOSX_DEPLOYMENT_TARGET=27.0
```

[License](LICENSE) · [Attribution](NOTICE) · [Third-party notices](THIRD_PARTY_NOTICES.md)
"""
CHECKER = "packages/conformance/check_trace.py"

# The entry point opens its own zipimport archive. Only builder-selected files
# are materialized. The trace may come from stdin and all CLI paths keep their
# original meaning because the process never changes the caller's directory.
ENTRY = '''"""Start the bundled checker with a private copy of its source tree."""
import hashlib
from pathlib import Path
import runpy
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

FILES = @FILES@


def main():
    if sys.version_info < (3, 9):
        print("Lean Regen requires Python 3.9 or later.", file=sys.stderr)
        return 2
    with TemporaryDirectory(prefix="lean-regen-kit-") as directory:
        root = Path(directory)
        with ZipFile(__loader__.archive) as archive:
            for name, (size, digest) in FILES.items():
                info = archive.getinfo(name)
                if info.file_size != size:
                    raise ValueError("Unexpected bundled file size: " + name)
                data = archive.read(info)
                if hashlib.sha256(data).hexdigest() != digest:
                    raise ValueError("Unexpected bundled file digest: " + name)
                destination = root / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
        checker = runpy.run_path(str(root / @CHECKER@))
        return checker["main"]()


if __name__ == "__main__":
    sys.exit(main())
'''


def read_sources(include_tests):
    check_upstream()
    manifest = json.loads((ROOT / "UPSTREAM_PROVENANCE.json").read_bytes())
    historical = {"packages/lean-verified-sdlc/" + name: digest
                  for name, digest in manifest["files"].items()}
    names = [*RUNTIME_FILES, *historical]
    if include_tests:
        names.extend(SOURCE_ONLY)
    contents = {}
    for name in sorted(names):
        path = ROOT / name
        if path.resolve() != path or not path.is_file():
            raise ValueError(f"Expected a regular project file: {name}")
        data = path.read_bytes()
        if name in historical and hashlib.sha256(data).hexdigest() != historical[name]:
            raise ValueError(f"Historical source digest changed: {name}")
        contents[name] = data
    return contents


def stored_zip(contents, prefix=""):
    # Stored members avoid compressor-version differences.
    stream = BytesIO()
    with ZipFile(stream, "w", compression=ZIP_STORED) as archive:
        for name, data in sorted(contents.items()):
            info = ZipInfo(prefix + name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    return stream.getvalue()


def zipapp(contents):
    files = {name: [len(data), hashlib.sha256(data).hexdigest()]
             for name, data in contents.items()}
    entry = ENTRY.replace("@FILES@", json.dumps(files, indent=2)).replace("@CHECKER@", repr(CHECKER))
    return stored_zip({**contents, "__main__.py": entry.encode("utf-8")})


def make_archive():
    return zipapp(read_sources(include_tests=False))


def release_assets():
    sources = read_sources(include_tests=True)
    runtime = {name: data for name, data in sources.items() if name not in SOURCE_ONLY}
    sources["README.md"] = SOURCE_GUIDE.encode("utf-8")
    manifest = {
        "format": "lean-regen-checker-source-v1",
        "upstream_provenance_sha256": PROVENANCE_SHA256,
        "files": {name: hashlib.sha256(data).hexdigest() for name, data in sorted(sources.items())},
    }
    sources["SOURCE-MANIFEST.json"] = (json.dumps(manifest, indent=2) + "\n").encode("utf-8")
    assets = {
        "lean-regen-check.pyz": zipapp(runtime),
        "lean-regen-conformance-source.zip": stored_zip(sources, SOURCE_ROOT),
        "wrong.jsonl": sources["packages/conformance/fixtures/wrong.jsonl"],
    }
    sums = "".join(f"{hashlib.sha256(data).hexdigest()}  {name}\n" for name, data in sorted(assets.items()))
    assets["CONFORMANCE-SHA256SUMS"] = sums.encode("ascii")
    return assets


def write_release(destination):
    if destination.exists() or destination.is_symlink():
        raise ValueError("Choose a new release directory")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=destination.parent) as stage:
        complete = Path(stage) / "complete"
        complete.mkdir()
        for name, data in release_assets().items():
            (complete / name).write_bytes(data)
        complete.rename(destination)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    output = parser.add_mutually_exclusive_group(required=True)
    output.add_argument("--out", type=Path, help="New output .pyz path")
    output.add_argument("--release-dir", type=Path, help="New directory for the four release assets")
    args = parser.parse_args()
    try:
        if args.release_dir:
            write_release(args.release_dir)
        else:
            data = make_archive()
            with args.out.open("xb") as out:
                out.write(data)
            print(hashlib.sha256(data).hexdigest(), args.out)
    except (OSError, ValueError) as exc:
        parser.exit(2, f"Build failed: {exc}\n")


if __name__ == "__main__":
    main()
