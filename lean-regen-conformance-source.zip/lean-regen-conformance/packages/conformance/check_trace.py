#!/usr/bin/env python3
"""Compare a captured sequential inventory journal with the shipped Lean reference."""
import argparse
import hashlib
from io import BytesIO
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
FIXTURES = HERE / "fixtures"
ROOT = HERE.parent.parent
TRACE_FORMAT = "lean-regen-inventory-trace-v1"
REPORT_FORMAT = "lean-regen-inventory-conformance-v1"
MAX_INT = 2**63 - 1
MAX_BYTES = 8 * 1024**2
MAX_LINE = 4096
MAX_STEPS = 50_000
ORACLE_SHA256 = "c9cc59e8deda2aef67566239cc50f6c6d5e15b1ac67e665582924d1a4590bcfa"
BRIDGE_SHA256 = "d546ec88fbd339757d5ede4d8ef926d4832bd5f3ca806746bc9de7c08c1f8839"
SUCCESS = {"accepted", "rejected"}


class JournalError(ValueError):
    def __init__(self, message, line=None):
        super().__init__(message)
        self.line = line


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_input(stream):
    data = stream.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise JournalError("File exceeds the 8 MiB limit")
    return data


def records(data):
    def unique(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError("Duplicate object member")
            obj[key] = value
        return obj

    for number, raw in enumerate(BytesIO(data), 1):
        content = raw.removesuffix(b"\n").removesuffix(b"\r")
        if len(content) > MAX_LINE:
            raise JournalError("Record exceeds the 4096 byte limit", number)
        try:
            record = json.loads(content.decode("utf-8"), object_pairs_hook=unique)
        except (ValueError, RecursionError) as exc:
            raise JournalError("Invalid or ambiguous UTF-8 JSON record", number) from exc
        if type(record) is not dict:
            raise JournalError("Expected a JSON object", number)
        yield number, record


def fields(row, expected, line):
    if row.keys() != set(expected.split()):
        raise JournalError("Missing or unknown fields; expected " + expected, line)


def integer(row, key, line, *, observed=False):
    value = row[key]
    minimum = -2**63 if observed else 0
    if type(value) is not int or not minimum <= value <= MAX_INT:
        raise JournalError("Invalid integer for " + key, line)
    return value


def transition(row, line):
    if row["operation"] not in ("reserve", "release"):
        raise JournalError("Unknown operation", line)
    if type(row["outcome"]) is not str or row["outcome"] not in SUCCESS:
        raise JournalError("Unknown outcome", line)
    integer(row, "quantity", line)
    for key in ("available", "reserved"):
        integer(row, key, line, observed=True)


def read_journal(data):
    iterator = iter(records(data))
    first = next(iterator, None)
    if first is None:
        raise JournalError("Empty journal")
    line, start = first
    fields(start, "type format capacity available reserved", line)
    if start["type"] != "start" or start["format"] != TRACE_FORMAT:
        raise JournalError("Expected the v1 start record", line)
    capacity = integer(start, "capacity", line)
    if integer(start, "available", line) + integer(start, "reserved", line) != capacity:
        raise JournalError("Starting quantities must sum to capacity", line)
    steps = []
    ended = False
    for line, row in iterator:
        if ended:
            raise JournalError("Unexpected data after end", line)
        if row.get("type") == "end":
            fields(row, "type count", line)
            if not steps or integer(row, "count", line) != len(steps):
                raise JournalError("Expected a nonempty journal and an exact end count", line)
            ended = True
            continue
        fields(row, "type seq operation quantity outcome available reserved", line)
        if row["type"] != "step" or integer(row, "seq", line) != len(steps) + 1:
            raise JournalError("Expected contiguous steps numbered from 1", line)
        if len(steps) >= MAX_STEPS:
            raise JournalError("Journal exceeds 50000 steps", line)
        transition(row, line)
        steps.append(row)
    if not ended:
        raise JournalError("Missing end record")
    return start, steps


def outcome(row):
    return {key: row[key] for key in ("outcome", "available", "reserved")}


def bundled_oracle(path):
    data = path.read_bytes()
    if sha(data) != ORACLE_SHA256:
        raise ValueError("Bundled reference corpus digest mismatch")
    table = {}
    try:
        for line, row in records(data):
            fields(row, "before_available before_reserved operation quantity outcome available reserved", line)
            transition(row, line)
            key = (integer(row, "before_available", line), integer(row, "before_reserved", line),
                   row["operation"], row["quantity"])
            if key in table:
                raise ValueError("Ambiguous bundled reference transition")
            table[key] = outcome(row)
    except JournalError as exc:
        raise ValueError(f"Invalid reference corpus at line {exc.line}: {exc}") from exc
    if not table:
        raise ValueError("Empty reference corpus")
    return ({"mode": "lean-vectors", "lean_version": "4.19.0", "vectors": len(table),
             "sha256": ORACLE_SHA256}, table.get)


def native_oracle(tool_bin, scratch):
    if sys.version_info < (3, 11):
        raise ValueError("Native mode requires Python 3.11+ and a trusted Lean/Lake 4.19.0")
    adapter = ROOT / "examples" / "sqlite_inventory"
    if sha((adapter / "Bridge.lean").read_bytes()) != BRIDGE_SHA256:
        raise ValueError("Shipped native bridge digest mismatch")
    destination = Path(scratch) / "oracle"
    build = subprocess.run([sys.executable, "-IB", str(adapter / "build_engine.py"), "--tool-bin",
                            str(tool_bin.resolve()), "--dest", str(destination)], stdin=subprocess.DEVNULL,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=420)
    if build.returncode:
        details = build.stdout.decode("utf-8", "replace").strip().splitlines()[-3:]
        raise ValueError("Shipped native reference build failed. " + " ".join(details))
    exe = destination / ".lake" / "build" / "bin" / "inventory_step"
    cache = {}

    def query(key):
        if key not in cache:
            completed = subprocess.run([str(exe), *map(str, key)], stdin=subprocess.DEVNULL,
                                       capture_output=True, timeout=5, check=True)
            parsed = re.fullmatch(rb"(accepted|rejected) ([0-9]+) ([0-9]+)\n", completed.stdout)
            if not parsed:
                raise ValueError("Native Lean reference returned an invalid record")
            cache[key] = {"outcome": parsed[1].decode("ascii"), "available": int(parsed[2]),
                          "reserved": int(parsed[3])}
        return cache[key]

    return ({"mode": "native-lean", "lean_version": "4.19.0", "bridge_sha256": BRIDGE_SHA256,
             "executable_sha256": sha(exe.read_bytes())}, query)


def compare(start, steps, reference, report):
    identity, lookup = reference
    report.update(oracle=identity, capacity=start["capacity"], total_steps=len(steps), matched_steps=0)
    before = {"available": start["available"], "reserved": start["reserved"]}
    for row in steps:
        command = {"operation": row["operation"], "quantity": row["quantity"]}
        key = (before["available"], before["reserved"], row["operation"], row["quantity"])
        expected = lookup(key)
        if expected is None or expected != outcome(row):
            report.update(line=row["seq"] + 1, seq=row["seq"], before=before, command=command,
                          observed=outcome(row))
            if expected is None:
                report.update(status="OUTSIDE_COVERAGE", reason="No bundled Lean vector for this exact input")
                return 3
            report.update(status="COUNTEREXAMPLE", expected=expected)
            return 1
        before = {"available": expected["available"], "reserved": expected["reserved"]}
        report["matched_steps"] += 1
    report["status"] = "TRACE_MATCH"
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trace", nargs="?", default=str(FIXTURES / "sqlite.jsonl"),
                        help="Captured JSONL file, or - for stdin (default: shipped real SQLite example)")
    parser.add_argument("--tool-bin", type=Path, help="Build the shipped reference using trusted Lean/Lake 4.19.0")
    parser.add_argument("--report", type=Path, help="Also save JSON at a new path")
    args = parser.parse_args()
    report = {"format": REPORT_FORMAT, "scope": "captured sequential inventory transitions only",
              "release_authorized": False}
    rc = 2
    try:
        if args.trace == "-":
            data = read_input(sys.stdin.buffer)
        else:
            with Path(args.trace).open("rb") as stream:
                data = read_input(stream)
        report["trace_sha256"] = sha(data)
        start, steps = read_journal(data)
        if args.tool_bin:
            with tempfile.TemporaryDirectory(prefix="lean-regen-conformance-") as work:
                rc = compare(start, steps, native_oracle(args.tool_bin, work), report)
        else:
            rc = compare(start, steps, bundled_oracle(FIXTURES / "oracle.jsonl"), report)
    except JournalError as exc:
        report.update(status="INVALID_TRACE", reason=str(exc))
        if exc.line is not None:
            report["line"] = exc.line
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        rc = 2
        report.update(status="UNAVAILABLE", reason=str(exc))
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.report:
        try:
            with args.report.open("x", encoding="utf-8") as stream:
                stream.write(text)
        except OSError as exc:
            report.update(check_status=report["status"], status="REPORT_WRITE_FAILED", reason=str(exc))
            rc = 2
            text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    sys.stdout.write(text)
    return rc


if __name__ == "__main__":
    sys.exit(main())
