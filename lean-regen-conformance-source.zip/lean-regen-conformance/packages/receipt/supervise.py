#!/usr/bin/env python3
"""Root-only supervisor in a disposable guest. Never load a signing key here."""
import base64
import json
import os
import pwd
import shutil
import stat
import subprocess
import tempfile
from pathlib import Path

ROOT = Path("/opt/leanregen-receipt")
PIN = "c4e48164e09abcd420d1d641703ac08b0249f61a7d71c1b0d34cafa6d99d7761"
MAGIC = b"LEANREGEN-RUN-1\n"


def read_child_file(dir_fd, name, limit):
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
    with os.fdopen(os.open(name, flags, dir_fd=dir_fd), "rb") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ValueError("Expected regular evidence file")
        data = stream.read(limit + 1)
        if len(data) > limit:
            raise ValueError("Evidence exceeds limit")
        return data


def run(frame):
    if os.getuid() != 0 or Path("/sys/class/net/eth0").exists():
        raise ValueError("Expected offline guest root")
    for dev in ("vdb", "vdc"):
        if Path("/sys/block",dev,"ro").read_text().strip() != "1":
            raise ValueError("Expected read-only inputs")
    if Path("/sys/block/vdd/size").read_text().strip() != "16384":
        raise ValueError("Wrong result disk size")
    try:
        account = pwd.getpwnam("regen-check")
    except KeyError:
        subprocess.run(["/usr/sbin/useradd","--system","--user-group","--no-create-home",
                        "--shell","/usr/sbin/nologin","regen-check"], check=True)
        account = pwd.getpwnam("regen-check")
    if account.pw_uid == 0 or set(os.getgrouplist(account.pw_name, account.pw_gid)) != {account.pw_gid}:
        raise ValueError("Expected dedicated unprivileged account")
    with tempfile.TemporaryDirectory(dir="/var/tmp") as tmp:
        parent = Path(tmp)
        parent.chmod(0o755)
        archive = parent/"lean.tar.zst"
        with Path("/dev/vdb").open("rb") as src, archive.open("xb") as dst:
            left = 609060873
            while left:
                chunk = src.read(min(left, 1024*1024))
                if not chunk:
                    raise ValueError("Truncated toolchain")
                dst.write(chunk)
                left -= len(chunk)
        archive.chmod(0o444)
        worker = parent/"output"
        worker.mkdir(mode=0o700)
        os.chown(worker,account.pw_uid,account.pw_gid)
        result = worker/"run"
        cmd = ["/usr/sbin/runuser","-u","regen-check","--","/usr/bin/env","-i","PATH=/usr/bin:/bin",
               "/usr/bin/python3","-IB",str(ROOT/"verify.py"),"--profile-sha256",PIN,
               "--solution",str(ROOT/"Solution.lean"),"--toolchain-archive",str(archive),"--output",str(result)]
        child = subprocess.run(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, timeout=960)
        frame["supervised_exit"] = child.returncode
        frame["worker_uid"] = account.pw_uid
        fd = os.open(result, os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            frame["report"] = base64.b64encode(read_child_file(fd,"result.json",65536)).decode()
            try:
                frame["log"] = base64.b64encode(read_child_file(fd,"comparator.log",4*1024*1024)).decode()
            except FileNotFoundError:
                if child.returncode == 0:
                    raise
        finally:
            os.close(fd)


def main():
    nonce = (ROOT/"nonce").read_text()
    frame = {"nonce": nonce}
    os.chown("/dev/vdd",0,0)
    os.chmod("/dev/vdd",0o600)
    try:
        run(frame)
    except Exception as exc:
        frame["infrastructure_failure"] = type(exc).__name__ + ": " + str(exc)
    data = json.dumps(frame).encode()
    with open("/dev/vdd","r+b",buffering=0) as device:
        device.write(MAGIC+len(data).to_bytes(8,"big")+data)
        os.fsync(device.fileno())


if __name__ == "__main__":
    main()
