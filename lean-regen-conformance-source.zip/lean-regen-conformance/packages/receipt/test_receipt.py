import base64
import copy
import json
import tempfile
import unittest
from pathlib import Path

import issuer


class WitnessBoundaries(unittest.TestCase):
    def setUp(self):
        frozen, self.lock = issuer.trusted_files()
        self.config = json.loads(frozen["profile/comparator.json"])
        self.nonce = "a"*64
        self.subject = "b"*64
        self.export = "c"*64
        self.log = ("\n".join(k+" kernel accepts the solution" for k in issuer.KERNELS)
                    +"\nSHA256 (/export) = "+self.export
                    +"\nexport digest kernel accepts the solution\nYour solution is okay!\n").encode()
        self.report = {"status":"LOCAL_PARANOID_COMPARISON_PASSED","exit_code":0,"profile_sha256":issuer.PROFILE,
                       "solution_sha256":self.subject,"verifier_sha256":issuer.VERIFIER,"toolchain_archive_checked":True,
                       "required_toolchain_sha256":self.lock["toolchains"]["aarch64"]["sha256"],
                       "obligations":self.config["theorem_names"],"permitted_axioms":self.config["permitted_axioms"],
                       "command":["lake","comparator","--paranoid","--config","comparator.json"],
                       "kernel_acceptance_lines":issuer.KERNELS,"log_sha256":issuer.sha(self.log),"signed":False,
                       "release_authorized":False,"proof_export_sha256":self.export}

    def frame(self, **changes):
        frame = {"nonce":self.nonce,"supervised_exit":0,"worker_uid":1000,
                 "report":base64.b64encode(json.dumps(self.report).encode()).decode(),
                 "log":base64.b64encode(self.log).decode()}
        frame.update(changes)
        return frame

    def check(self, frame):
        return issuer.checked(frame,self.nonce,self.subject,self.lock,self.config)

    def test_self_report_replay_and_nonzero_exit_do_not_authorize(self):
        for frame in (self.report,self.frame(nonce="old"),self.frame(supervised_exit=1),
                      self.frame(supervised_exit=False),self.frame(worker_uid=0),
                      self.frame(infrastructure_failure="read error")):
            with self.assertRaisesRegex(ValueError,"supervisor"):
                self.check(frame)

    def test_subject_toolchain_and_every_kernel_are_required(self):
        for key,value in (("solution_sha256","wrong"),("required_toolchain_sha256","wrong"),
                          ("kernel_acceptance_lines",issuer.KERNELS[:-1]),("obligations",[]),
                          ("signed",True),("toolchain_archive_checked",1)):
            report = dict(self.report)
            report[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.check(self.frame(report=base64.b64encode(json.dumps(report).encode()).decode()))

    def test_export_and_log_substitutions_are_rejected(self):
        for log in (self.log+b"SHA256 (/duplicate) = "+self.export.encode()+b"\n",
                    self.log.replace(self.export.encode(),b"0"*64), self.log.replace(b"nanoda kernel",b"other kernel")):
            report = dict(self.report,log_sha256=issuer.sha(log))
            with self.assertRaises(ValueError):
                self.check(self.frame(report=base64.b64encode(json.dumps(report).encode()).decode(),
                                      log=base64.b64encode(log).decode()))

    def test_existing_files_are_not_guest_results(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/"result"
            for data in (b'{"passed":true}', issuer.MAGIC+(9*1024*1024).to_bytes(8,"big")):
                path.write_bytes(data)
                with self.assertRaises(ValueError):
                    issuer.read_frame(path)
