# Local fixed-profile witness

This development witness runs one frozen inventory proof profile in a fresh offline Linux VM on macOS arm64. It issues a namespace-scoped Ed25519 observation about the submitted Lean source and checked proof-export digest. Application binaries, real-world effects, production signing identity and automatic promotion have separate gates.

## Enrollment

A trusted operator provisions a clean Linux root disk with Python 3, git, tar, zstd, bubblewrap, `sha256sum`, and `runuser`. The root disk must be fully shut down. Obtain the fixed Lean 4.36.0 aarch64 archive specified in the checker profile. Enrollment uses the locally installed Docker.app QEMU and LinuxKit kernel, APFS snapshots, and the system OpenSSH signing utility. Keep enrollment and signing access outside the producer's authority.

```sh
python3 packages/receipt/issuer.py enroll --state /path/to/new-private-witness \
  --base /path/to/sealed-root.raw --toolchain /path/to/lean-4.36.0-linux_aarch64.tar.zst
```

Enrollment prints the policy fingerprint and public-key fingerprint. Pin both through an independent operator-controlled channel before evaluating candidates. The newly created private signing key stays on this host. This bootstrap relies on the local operator, host OS, hypervisor, installed dynamic libraries, enrolled image and kernel. The prototype retains its local signing key in the owner-only state directory. Use a separately administered authority for a production issuer.

## Run and check

```sh
python3 packages/receipt/issuer.py run --state /path/to/private-witness \
  --policy-sha256 "$ENROLLED_POLICY_SHA256" --solution /path/to/Proofs.lean --out /path/to/new-run

python3 packages/receipt/issuer.py verify --result /path/to/new-run \
  --trusted-public-key-sha256 "$ENROLLED_PUBLIC_KEY_SHA256" --solution /path/to/Proofs.lean
```

For an existing update observer candidate, also pass `--candidate-record /path/to/candidate.json`. The host checks the recorded source, target archive and profile, and binds the candidate digest and request identifier. The request identifier identifies a submitted update event and grants no promotion rights.

The host accepts one regular UTF-8 source, hashes the operator-enrolled VM inputs, constructs its own read-only input media and generates a fresh 256-bit nonce. The offline guest has a private overlay, no NIC or host mounts, two vCPUs and 3 GiB RAM. Its root supervisor launches the pinned verifier as a dedicated unprivileged UID, observes its exit and writes bounded evidence to a new root-only result device. The signing key stays outside the VM. Disk availability and hypervisor support are prerequisites.

The host checks the nonce, process exit, actual source and verifier digests, the complete challenge and allowed axioms, all six kernel acceptance lines, the checked toolchain and the unique hash of the read-only proof export recorded by the comparator. After QEMU exits, the host signs the subject, export, policy identity and evidence digests. The result includes the public key, SSH signature, canonical payload, bound log and report. Checking a receipt requires a separately pinned key and the actual source bytes. Historical output files are never signer inputs. Failed runs retain available diagnostics and produce no signature. The public key distributed with the report alone does not establish the identity of its operator.

For local rejection tests run `python3 -m unittest discover -s packages/receipt -v`. Replaying the export outside the original run additionally requires the underlying NDJSON bytes. The development witness records their digest.
