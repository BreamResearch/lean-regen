#!/usr/bin/env python3
"""Enroll a local witness and sign only the result of a fresh, fixed-profile offline VM run."""
import argparse
import base64
import hashlib
import io
import json
import os
import platform
import re
import secrets
import selectors
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CHECKER = ROOT.parent/"independent-checker"
QEMU = Path("/Applications/Docker.app/Contents/MacOS/qemu-system-aarch64")
KERNEL = Path("/Applications/Docker.app/Contents/Resources/linuxkit/kernel")
PROFILE = "c4e48164e09abcd420d1d641703ac08b0249f61a7d71c1b0d34cafa6d99d7761"
VERIFIER = "6d01cda25238b9056734d3f2d46bcb2c380188ecf629c9bb89da8e74adcb8b2b"
MAGIC = b"LEANREGEN-RUN-1\n"
KERNELS = ["Lean default", "Lean paranoid", "lean4lean", "nanoda", "con-leche", "con-ron"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def hashed(path):
    h = hashlib.sha256()
    with path.open("rb") as src:
        while data := src.read(4*1024*1024):
            h.update(data)
    return h.hexdigest()


def canonical(doc):
    return (json.dumps(doc, ensure_ascii=False, sort_keys=True, separators=(",", ":"))+"\n").encode()


def trusted_files():
    lock = (CHECKER/"profile.lock.json").read_bytes()
    verifier = (CHECKER/"verify.py").read_bytes()
    if sha(lock) != PROFILE or sha(verifier) != VERIFIER:
        raise ValueError("The independently pinned profile or verifier changed")
    policy = json.loads(lock)
    files = {"profile.lock.json":lock, "verify.py":verifier, "supervise.py":(ROOT/"supervise.py").read_bytes()}
    for name, expected in policy["files"].items():
        data = (CHECKER/"profile"/name).read_bytes()
        if sha(data) != expected:
            raise ValueError("Fixed profile mismatch: "+name)
        files["profile/"+name] = data
    return files, policy


SSH_KEYGEN = Path("/usr/bin/ssh-keygen")
NAMESPACE = "lean-regen-local-source-witness-v1"


def ssh_keygen(*args, **kwargs):
    return subprocess.run([SSH_KEYGEN,*map(str,args)],check=True,
                          env={"PATH":"/usr/bin:/bin","LC_ALL":"C"},**kwargs)


def verify_signature(public_key, payload, signature):
    # Pinning the public key independently of the delivered files is the caller's responsibility.
    with tempfile.TemporaryDirectory() as tmp:
        allowed = Path(tmp)/"allowed_signers"
        allowed.write_bytes(b"local-witness "+public_key)
        sig = Path(tmp)/"witness.sig"
        sig.write_bytes(signature)
        ssh_keygen("-Y","verify","-f",allowed,"-I","local-witness","-n",NAMESPACE,"-s",sig,
                   input=payload,stdout=subprocess.DEVNULL)


def enroll(state, image, toolchain):
    if platform.system() != "Darwin" or platform.machine() != "arm64":
        raise ValueError("The development VM profile requires macOS arm64")
    files, lock = trusted_files()
    if ROOT.parents[1] in state.resolve().parents:
        raise ValueError("Keep private witness state outside the source repository")
    state.mkdir(mode=0o700,parents=False,exist_ok=False)
    # APFS clones snapshot exact input bytes without 10 GiB of extra writable data.
    for src, dst in ((image,state/"root.raw"), (toolchain,state/"lean.tar.zst")):
        if src.is_symlink() or not src.is_file():
            raise ValueError("A regular, operator-provisioned input is required")
        subprocess.run(["/bin/cp","-c",src,dst],check=True)
        dst.chmod(0o400)
    names = {"root.raw":state/"root.raw","lean.tar.zst":state/"lean.tar.zst","qemu":QEMU,"kernel":KERNEL,"ssh-keygen":SSH_KEYGEN}
    pins = {k:hashed(v) for k,v in names.items()}
    if pins["lean.tar.zst"] != lock["toolchains"]["aarch64"]["sha256"]:
        raise ValueError("Official release archive pin mismatch")
    ssh_keygen("-q","-t","ed25519","-N","","-C","lean-regen-development-witness","-f",state/"issuer.key")
    (state/"issuer.key.pub").rename(state/"issuer.pub")
    policy = {"role":"local-development-observer","inputs":pins,"profile_sha256":PROFILE,
              "verifier_sha256":VERIFIER,"supervisor_sha256":sha(files["supervise.py"]),
              "issuer_program_sha256":hashed(Path(__file__)),"public_key_sha256":hashed(state/"issuer.pub")}
    (state/"policy.json").write_bytes(canonical(policy))
    return policy


def bounded_file(path, limit):
    with os.fdopen(os.open(path, os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK),"rb") as fp:
        info = os.fstat(fp.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise ValueError("Expected bounded regular file: "+path.name)
        data = fp.read(limit+1)
        if len(data) > limit:
            raise ValueError("Input exceeds limit: "+path.name)
        return data


def source_bytes(path):
    data = bounded_file(path,1024*1024)
    data.decode()
    return data


def write_input(path, files):
    with tarfile.open(path,"w",format=tarfile.USTAR_FORMAT) as tar:
        for name,data in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.mode, info.size = 0o444, len(data)
            tar.addfile(info,io.BytesIO(data))


def boot(state, work):
    args = [QEMU,"-nodefaults","-machine","virt,accel=hvf,highmem=off","-cpu","host","-smp","2","-m","3072",
            "-nographic","-serial","stdio","-monitor","none","-nic","none","-no-reboot"]
    for path,mode in ((state/"root.raw","snapshot=on"),(state/"lean.tar.zst","readonly=on"),
                      (work/"input.tar","readonly=on"),(work/"result.raw","readonly=off")):
        if "," in str(path):
            raise ValueError("Comma is unsupported in a QEMU input path")
        args += ["-drive",f"if=virtio,file={path},format=raw,{mode}"]
    args += ["-kernel", KERNEL,"-append","root=/dev/vda rootfstype=ext4 rootwait rw console=ttyAMA0 init=/bin/bash quiet"]
    setup = [
        "export PATH=/usr/sbin:/usr/bin:/sbin:/bin",
        "mountpoint -q /dev || mount -t devtmpfs devtmpfs /dev",
        "mountpoint -q /proc || mount -t proc proc /proc",
        "mountpoint -q /sys || mount -t sysfs sysfs /sys",
        "mkdir -p /dev/pts /dev/shm /run/user /tmp /var/tmp",
        "chmod 1777 /tmp /var/tmp",
        "mountpoint -q /dev/pts || mount -t devpts devpts /dev/pts",
        "mountpoint -q /dev/shm || mount -t tmpfs -o mode=1777 tmpfs /dev/shm",
        "mkdir -m 0755 /opt/leanregen-receipt",
        "tar --no-same-owner -xf /dev/vdc -C /opt/leanregen-receipt",
        "/usr/bin/python3 -IB /opt/leanregen-receipt/supervise.py",
    ]
    bootstrap = ("(set -e; "+"; ".join(setup)+"); sync; echo o > /proc/sysrq-trigger\n").encode()
    # No host secrets or inherited QEMU configuration in the guest or subprocess environment.
    proc = subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                            env={"PATH":"/usr/bin:/bin","LC_ALL":"C","TMPDIR":str(work)})
    try:
        with selectors.DefaultSelector() as monitor, (work/"console.log").open("wb") as log:
            monitor.register(proc.stdout,selectors.EVENT_READ)
            sent, tail, written, deadline = False, b"", 0, time.monotonic()+120
            while True:
                left = deadline-time.monotonic()
                if left <= 0 or not monitor.select(left):
                    raise ValueError("VM boot or run exceeded its deadline")
                buf = os.read(proc.stdout.fileno(),65536)
                if not buf:
                    break
                written += len(buf)
                if written > 2*1024*1024:
                    raise ValueError("Console exceeded its limit")
                log.write(buf)
                log.flush()
                tail = (tail+buf)[-4096:]
                if not sent and re.search(rb"(?:bash-[^\r\n]*|root@[^\r\n]*)#\s*$",tail):
                    proc.stdin.write(bootstrap)
                    proc.stdin.flush()
                    sent = True
                    deadline = time.monotonic()+1100
            if not sent or proc.wait(timeout=10) != 0:
                raise ValueError("VM did not exit successfully")
    finally:
        if proc.poll() is None:
            proc.kill()
        proc.wait()
        proc.stdout.close()
        proc.stdin.close()


def read_frame(path):
    with path.open("rb") as stream:
        if stream.read(len(MAGIC)) != MAGIC:
            raise ValueError("Guest supervisor did not produce a frame")
        size = int.from_bytes(stream.read(8),"big")
        if not 0 < size <= 6*1024*1024:
            raise ValueError("Invalid result frame size")
        return json.loads(stream.read(size))


def checked(frame, nonce, solution_sha, lock, config):
    if (frame.get("nonce") != nonce or frame.get("infrastructure_failure") or
            type(frame.get("supervised_exit")) is not int or frame["supervised_exit"] != 0 or
            type(frame.get("worker_uid")) is not int or frame["worker_uid"] <= 0):
        raise ValueError("Fresh supervisor acceptance missing")
    raw = base64.b64decode(frame["report"],validate=True)
    log = base64.b64decode(frame["log"],validate=True)
    r = json.loads(raw)
    expected = {"status":"LOCAL_PARANOID_COMPARISON_PASSED","exit_code":0,"profile_sha256":PROFILE,
                "solution_sha256":solution_sha,"verifier_sha256":VERIFIER,"toolchain_archive_checked":True,
                "required_toolchain_sha256":lock["toolchains"]["aarch64"]["sha256"],
                "obligations":config["theorem_names"],"permitted_axioms":config["permitted_axioms"],
                "command":["lake","comparator","--paranoid","--config","comparator.json"],
                "kernel_acceptance_lines":KERNELS,"log_sha256":sha(log),"signed":False,"release_authorized":False}
    lines = log.decode("utf-8","replace").splitlines()
    exports = re.findall(rb"SHA256 \([^()\n]*\) = ([0-9a-f]{64})",log)
    if len(exports) != 1 or r.get("proof_export_sha256") != exports[0].decode():
        raise ValueError("Missing or ambiguous proof export binding")
    if ("export digest kernel accepts the solution" not in lines or any(type(r.get(k)) != type(v) or r[k] != v for k,v in expected.items()) or
            any(k+" kernel accepts the solution" not in lines for k in KERNELS) or "Your solution is okay!" not in lines):
        raise ValueError("Observed outputs do not bind the complete requested comparison")
    return raw,log,exports[0].decode()


def bind_candidate(path, source_hash, target_hash):
    if path is None:
        return None, None
    raw = bounded_file(path,8192)
    record = json.loads(raw)
    expected = {"schema":1, "target":"v4.36.0", "base":"v4.19.0",
                "target_archive_sha256":target_hash,"profile_sha256":PROFILE,
                "solution_sha256":source_hash, "assurance":"UNVERIFIED_CANDIDATE",
                "generation":"reuse_seed_proof_against_frozen_implementation",
                "seed_contract_sha256":"8503486096e88e98016652d463edee3ced384037ac5fb358215126402058ad29"}
    if (any(type(record.get(k)) != type(v) or record[k] != v for k,v in expected.items())
            or not re.fullmatch(r"[0-9a-f]{64}",record.get("request_id",""))):
        raise ValueError("Candidate record differs from the fixed toolchain, contract or submitted source")
    return {"candidate_id":sha(raw),"request_id":record["request_id"]},raw


def witness(state, policy_pin, solution_path, output, candidate_record=None):
    state = state.resolve(strict=True)
    if state.stat().st_uid != os.geteuid() or state.stat().st_mode & 0o077:
        raise ValueError("Private operator-owned state directory required")
    files, lock = trusted_files()
    policy_bytes = (state/"policy.json").read_bytes()
    if sha(policy_bytes) != policy_pin:
        raise ValueError("Operator enrollment fingerprint changed")
    policy = json.loads(policy_bytes)
    for name,path in (("ssh-keygen",SSH_KEYGEN),("qemu",QEMU),("kernel",KERNEL),("root.raw",state/"root.raw"),("lean.tar.zst",state/"lean.tar.zst")):
        if hashed(path) != policy["inputs"][name]:
            raise ValueError("Enrolled VM input changed: "+name)
    if (sha(files["supervise.py"]) != policy["supervisor_sha256"] or hashed(Path(__file__)) != policy["issuer_program_sha256"]
            or hashed(state/"issuer.pub") != policy["public_key_sha256"]):
        raise ValueError("Enrolled host or supervisor changed")
    solution, nonce = source_bytes(solution_path), secrets.token_hex(32)
    config = json.loads(files["profile/comparator.json"])
    context, candidate_bytes = bind_candidate(candidate_record,sha(solution),policy["inputs"]["lean.tar.zst"])
    files.update({"Solution.lean":solution, "nonce":nonce.encode()})
    output.mkdir(mode=0o700,exist_ok=False)
    with tempfile.TemporaryDirectory(dir=state) as tmp:
        work = Path(tmp)
        write_input(work/"input.tar",files)
        with (work/"result.raw").open("xb") as media:
            media.truncate(8*1024*1024)
        started = datetime.now(timezone.utc).isoformat()
        try:
            boot(state,work)
            frame = read_frame(work/"result.raw")
            if "report" in frame and frame.get("nonce") == nonce:
                (output/"observed-report.json").write_bytes(base64.b64decode(frame["report"],validate=True))
            if "log" in frame and frame.get("nonce") == nonce:
                (output/"comparator.log").write_bytes(base64.b64decode(frame["log"],validate=True))
            if frame.get("infrastructure_failure"):
                raise ValueError("Guest infrastructure: "+frame["infrastructure_failure"])
            raw,log,export_sha = checked(frame,nonce,sha(solution),lock,config)
        finally:
            if (work/"console.log").is_file(): shutil.copyfile(work/"console.log",output/"console.log")
        document = {"format":"lean-regen-local-source-witness-v1","scope":"fixed-inventory-proof-source",
                    "release_authorized":False,"production_issuer":False,"nonce":nonce,"started":started,
                    "finished":datetime.now(timezone.utc).isoformat(),"subject_sha256":sha(solution),
                    "input_tar_sha256":hashed(work/"input.tar"),"contract_profile_sha256":PROFILE,
                    "verifier_sha256":VERIFIER,"operator_policy_sha256":sha(policy_bytes),
                    "public_key_sha256":policy["public_key_sha256"],"toolchain_sha256":policy["inputs"]["lean.tar.zst"],
                    "candidate":context,"report_sha256":sha(raw),"comparator_log_sha256":sha(log),"kernels":KERNELS,
                    "proof_export_sha256":export_sha,"native_artifact_sha256":None}
        if candidate_bytes is not None:
            (output/"candidate.json").write_bytes(candidate_bytes)
        (output/"receipt.json").write_bytes(canonical(document))
        (output/"comparator.log").write_bytes(log)
        (output/"policy.json").write_bytes(policy_bytes)
        shutil.copyfile(state/"issuer.pub",output/"issuer.pub")
        signed = ssh_keygen("-q","-Y","sign","-f",state/"issuer.key","-n",NAMESPACE,
                            input=canonical(document),stdout=subprocess.PIPE)
        verify_signature((state/"issuer.pub").read_bytes(),canonical(document),signed.stdout)
        (output/"witness.sig").write_bytes(signed.stdout)
        return document


def verify_public(result, trusted_key, solution):
    # Snapshot each bounded untrusted file once. Hash and verify these same bytes.
    payload = bounded_file(result/"receipt.json",64*1024)
    doc = json.loads(payload)
    if (doc.get("format") != "lean-regen-local-source-witness-v1" or doc.get("release_authorized") is not False
            or doc.get("production_issuer") is not False or doc.get("contract_profile_sha256") != PROFILE
            or doc.get("verifier_sha256") != VERIFIER or doc.get("kernels") != KERNELS):
        raise ValueError("Unexpected witness scope or verifier")
    public_key = bounded_file(result/"issuer.pub",4096)
    report_bytes = bounded_file(result/"observed-report.json",64*1024)
    evidence = {"public_key_sha256":public_key, "operator_policy_sha256":bounded_file(result/"policy.json",64*1024),
                "report_sha256":report_bytes, "comparator_log_sha256":bounded_file(result/"comparator.log",4*1024*1024)}
    if (doc.get("public_key_sha256") != trusted_key or doc.get("subject_sha256") != sha(source_bytes(solution))
            or any(doc.get(k) != sha(v) for k,v in evidence.items())):
        raise ValueError("Pinned issuer, source or evidence differs")
    if doc.get("candidate") is not None:
        context, _ = bind_candidate(result/"candidate.json",doc["subject_sha256"],doc["toolchain_sha256"])
        if context != doc["candidate"]:
            raise ValueError("Candidate manifest binding differs")
    report = json.loads(report_bytes)
    if not re.fullmatch(r"[0-9a-f]{64}", doc["proof_export_sha256"]) or report["proof_export_sha256"] != doc["proof_export_sha256"]:
        raise ValueError("Export digest mismatch")
    verify_signature(public_key,payload,bounded_file(result/"witness.sig",4096))
    return {"status":"LOCAL_WITNESS_SIGNATURE_AND_BINDINGS_MATCH","release_authorized":False}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="action",required=True)
    init = sub.add_parser("enroll")
    init.add_argument("--state",type=Path,required=True)
    init.add_argument("--base",type=Path,required=True)
    init.add_argument("--toolchain",type=Path,required=True)
    run = sub.add_parser("run")
    run.add_argument("--state",type=Path,required=True)
    run.add_argument("--policy-sha256",required=True)
    run.add_argument("--solution",type=Path,required=True)
    run.add_argument("--out",type=Path,required=True)
    run.add_argument("--candidate-record",type=Path,help="Matching update observer candidate.json")
    check = sub.add_parser("verify")
    check.add_argument("--trusted-public-key-sha256",required=True)
    check.add_argument("--solution",type=Path,required=True)
    check.add_argument("--result",type=Path,required=True)
    a=p.parse_args()
    os.umask(0o077)
    try:
        if a.action == "enroll":
            policy = enroll(a.state,a.base,a.toolchain)
            result = {"policy":policy,"policy_sha256":sha(canonical(policy))}
        elif a.action == "run":
            result = witness(a.state,a.policy_sha256,a.solution,a.out,a.candidate_record)
        else:
            result = verify_public(a.result,a.trusted_public_key_sha256,a.solution)
        print(json.dumps(result,indent=2))
    except (ValueError,KeyError,OSError,subprocess.SubprocessError) as e:
        print("BLOCKED: "+str(e),file=sys.stderr)
        return 2
    return 0


if __name__=="__main__":
    raise SystemExit(main())
