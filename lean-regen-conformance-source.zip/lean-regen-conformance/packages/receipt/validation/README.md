# Development witness runs from November 24, 2026

| Run | Observed result |
| --- | --- |
| [First seed invocation](20261124-seed/observed-report.json) | The initial guest setup returned comparator exit 1 with no kernel acceptance lines. The host issued no signature. This first supervisor retained the report only. |
| [ARM64 update candidate](20261124-arm-candidate/receipt.json) | The enrolled host ran a fresh offline VM against the observer's actual candidate, received all six kernel acceptances and the export digest, and issued an SSH-signature in the development namespace. The native-artifact field is null. |
| [Missing obligations](20261124-missing-obligations/result.json) | The same final host configuration ran a module that supplied none of the 14 obligations. The comparator rejected it. The host retained its diagnostics and produced no signature. |

The key-file fingerprint recorded before the successful run was `b07a0b2e1b20cd8bfc107e85cda67e4174d334dc878cd2a5d9d140ae4a72c4cd`. Offline checks of the positive run verified that key and rejected a changed signed payload, substituted log, different key, different solution and substituted candidate request. [Signature checks](20261124-arm-candidate/signature-checks.json)

The successful run used the real observer candidate `ceb64677c6d331aa5f34f31812727c5cc653dd0cebd9f5ae5974a17c7183f041`. Its source bytes match the shipped inventory proof file. From the repository root, readers who independently accept this development key can check the included observation:

```sh
python3 packages/receipt/issuer.py verify \
  --trusted-public-key-sha256 b07a0b2e1b20cd8bfc107e85cda67e4174d334dc878cd2a5d9d140ae4a72c4cd \
  --solution packages/lean-verified-sdlc/assets/lean-starter/VerifiedInventory/Proofs.lean \
  --result packages/receipt/validation/20261124-arm-candidate
```

The bound proof export SHA-256 is `738f15754239d5da4350f23a1a26c2610d0960d5d233449a6e8a7f447a69cc84`. Both the signature and its policy identify this as a local development observation. Production issuer administration, release authority and runtime coverage remain separate work.
