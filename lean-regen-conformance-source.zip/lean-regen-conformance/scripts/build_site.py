#!/usr/bin/env python3
"""Build a self-contained OSS showcase. Signup stays disabled until separately implemented."""
import argparse
import html
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--repository-url")
    parser.add_argument("--download-url", help="Verified release asset or commit-pinned raw ZIP from the same repository")
    parser.add_argument("--replace", action="store_true")
    args = parser.parse_args()
    status = json.loads((ROOT / "STATUS.json").read_text())
    repository_url = args.repository_url or status["publication"].get("github_repository")
    if repository_url and not re.fullmatch(r"https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/?", repository_url):
        parser.error("Use an actual https://github.com/owner/repository URL")
    if status["publication"]["signup_state"] != "disabled":
        parser.error("This alpha showcase has no signup backend; implement the real service flow before changing signup state")
    count = int(status["implementation"]["historical_inventory_theorems"])
    url = html.escape(repository_url or "", quote=True)
    source_link = f'<a class="secondary" href="{url}">GitHub · 日本語 / English</a>' if url else ''
    if args.download_url:
        base = (repository_url or "").rstrip("/")
        release = re.escape(base) + r"/releases/download/[A-Za-z0-9_-][A-Za-z0-9._-]*/"
        raw = re.escape(base.replace("https://github.com/", "https://raw.githubusercontent.com/")) + r"/[0-9a-f]{40}/"
        zip_name = r"[A-Za-z0-9_-][A-Za-z0-9._-]*\.zip"
        if not base or not any(re.fullmatch(prefix + zip_name, args.download_url) for prefix in (release, raw)):
            parser.error("Expected a release ZIP or a full-commit raw ZIP from the selected GitHub repository")
        source_link += f'<a class="secondary" href="{html.escape(args.download_url, quote=True)}">ソースZIP / Download ZIP</a>'
    operation = "検査記録と実行手順をソースに同梱しています。"
    if status["evidence"].get("independent_verifier_executed"):
        operation = "開発版のGitバンドルには、同じ14定理をLean 4.36.0の6カーネルで検査した記録も収録しています。"
    page = '''<!doctype html>
<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="実装は作り直せる。業務の約束と証拠を引き継ぐ、Leanベースの公開スターター。">
<title>Lean Regen — 約束を残し、実装を更新する</title>
<style>
:root{color-scheme:light;--ink:#142c38;--muted:#536873;--accent:#086d63;--line:#cddbdc;--paper:#f5f8f6}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:system-ui,-apple-system,"Noto Sans JP",sans-serif;line-height:1.8}a{color:var(--accent)}main,header,footer{max-width:1120px;margin:auto;padding:26px}header{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--line)}.brand{font-weight:800;font-size:22px;letter-spacing:-.7px}.label{font-size:12px;font-weight:700;letter-spacing:1.4px;text-transform:uppercase}.pill{padding:4px 12px;border:1px solid var(--line);border-radius:20px;font-size:12px}.hero{padding:70px 0 54px;display:grid;grid-template-columns:1.5fr 1fr;gap:40px;align-items:start}h1{font-size:clamp(32px,4.3vw,52px);line-height:1.4;letter-spacing:-1.5px;margin:18px 0 24px}h2{font-size:27px;line-height:1.5;margin:0 0 18px}h3{font-size:18px;margin:0 0 12px}p{margin:0 0 20px}.intro{font-size:17px;max-width:650px;color:var(--muted)}.button,.secondary{display:inline-block;font-weight:700;text-decoration:none;padding:12px 20px;margin:6px 10px 6px 0;border-radius:7px}.button{background:var(--accent);color:white}.secondary{border:1px solid var(--accent)}.note{font-size:13px;color:var(--muted)}.status{background:#e4efeb;padding:28px;border:1px solid #b5cec6;border-radius:12px}.number{font-size:44px;font-weight:800;line-height:1.1}.status hr{border:0;border-top:1px solid #b5cec6;margin:22px 0}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.card{padding:26px;background:white;border:1px solid var(--line);border-radius:10px}.section{padding:45px 0;border-top:1px solid var(--line)}.overline{display:block;color:var(--accent);font-size:12px;font-weight:800;letter-spacing:1px;margin-bottom:10px}pre{overflow:auto;padding:22px;background:#152f39;color:#e3f3ef;border-radius:10px;font-size:13px;line-height:1.7}code{font-family:ui-monospace,SFMono-Regular,monospace}ul{padding-left:22px}footer{font-size:12px;color:var(--muted);border-top:1px solid var(--line)}a:focus-visible{outline:3px solid #b47800;outline-offset:4px}@media(max-width:760px){.hero{grid-template-columns:1fr;padding-top:38px;gap:22px}.grid{grid-template-columns:1fr}main,header,footer{padding:20px}h1{letter-spacing:-.7px}.section{padding:32px 0}}
</style></head><body>
<header><span class="brand">Lean Regen</span><nav aria-label="Language"><a href="#ja" lang="ja">日本語</a> · <a href="#en" lang="en">English</a></nav></header>
<div id="ja"></div>
<main><section class="hero"><div><h1>予約の実装を変えても、<br>同じ契約を満たすか確かめる。</h1><p class="intro">10枠の在庫から3枠を予約し、2枠を解放すると、残りは9枠です。上限を超える予約は拒否されます。この動作を定めるLeanの仕様、実装、証明と検査手順を、登録せずに手元で試せます。</p><a class="button" href="#quickstart">登録せず、無料で試す</a><a class="secondary" href="#scope">検証の範囲を見る</a>__SOURCE_LINK__</div>
<aside class="status"><span class="overline">純粋コアの検査</span><p><span class="number">__COUNT__</span> 個の登録定理</p><p>逐次・単一資源の数量予約モデルを、Lean 4.19.0で検査済み。</p><hr><p class="note">__OPERATION__</p></aside></section>
__TRACE_CHECKER__
<section id="scope" class="section"><h2>このデモで、確かめたこと。</h2><div class="grid"><article class="card"><h3>正しく成功する</h3><p>許される数量の予約・解放は、定義された正確な増減を行います。</p></article><article class="card"><h3>拒否で状態を変えない</h3><p>条件を満たさない操作は拒否し、元の状態を返します。</p></article><article class="card"><h3>数量を保存する</h3><p>モデル内の任意の有限操作列で、容量の不変条件が維持されます。</p></article></div><p class="note" style="margin-top:22px">この証明は単一資源を逐次操作する純粋コアが対象です。個別予約の所有権、認証、データベースの並行更新、再送、障害復旧、コンパイラやOSの正しさは対象外です。</p></section>
<section id="quickstart" class="section"><span class="overline">Local first. No account.</span><h2>まず、手元で同じ例を動かす。</h2><p>ソースZIPを展開し、README.mdのあるフォルダーに移動します。Python 3.11以上と公式のLean/Lake 4.19.0を用意し、下のパスを手元のbinフォルダーに置き換えてください。</p><pre><code>python3 scripts/leanregen.py check-upstream
python3 scripts/leanregen.py demo \\
  --tool-bin /absolute/path/to/lean-4.19.0/bin \\
  --workdir ../lean-regen-demo-001</code></pre><p class="note">ソースのライセンスはApache-2.0です。ローカルでの検査に利用登録は不要です。実行手順と前提はREADMEをご覧ください。</p></section>
<section class="section"><h2>サービスの提供状況</h2><p>無料のOSSを登録なしで利用できます。ホスト型の検査、利用登録の受付、有料運用はいずれも提供していません。</p></section>
<section id="en" class="section" lang="en"><h2>Check changes to reservation logic</h2><p class="intro">A reservation for every remaining unit should succeed. A request for one extra unit should leave the inventory untouched. Lean Regen supplies a fixed contract, 14 checked theorems and three intentionally broken implementations that the checks reject.</p><p>Download the source ZIP, extract it and run the <a href="#quickstart">quickstart commands</a> from the directory containing README.md. Use Python 3.11 or later and the official Lean/Lake 4.19.0 toolchain. You can compare the file hashes, rebuild the source archive and rerun the checks offline once the tools are installed.</p>__SOURCE_LINK__<h3>What the evidence covers</h3><p>The proofs cover sequential reserve and release operations on one resource. Database concurrency, per-user authorization, crash recovery and deployed application behavior need their own checks. The offline development bundle includes a separate six-kernel run on the same 14 obligations under Lean 4.36.0.</p><p>Free local use requires no account. Hosted checking, enrollment and payments are offline. The project is released under Apache-2.0.</p></section></main>
<footer>Lean Regen · BreamResearch · Apache-2.0</footer>
</body></html>'''.replace("__SOURCE_LINK__", source_link).replace("__COUNT__", str(count)).replace("__OPERATION__", html.escape(operation))
    checker = status.get("conformance_distribution", {}).get("checker_url")
    trace_section = ''
    if checker:
        repo_path = (repository_url or '').removeprefix('https://github.com/').rstrip('/')
        pattern = r'https://raw\.githubusercontent\.com/' + re.escape(repo_path) + r'/[0-9a-f]{40}/lean-regen-check\.pyz'
        if not repo_path or not re.fullmatch(pattern, checker):
            parser.error('Expected the commit-pinned checker from the selected repository')
        trace_section = f'''<section class="section" id="trace"><h2>既存アプリを照合する / Check your app</h2>
<p>残り8枠をすべて予約できるのに、境界条件を誤ったSQLは拒否しました。合計10枠という制約は正常です。チェッカーはSQLiteの実行記録から、4件目の誤拒否とその直前の残高を特定しました。</p>
<p lang="en">The example SQL application rejected all eight remaining units while its totals still balanced. The checker identified the fourth operation, its starting balances and the expected acceptance. Export a sequential JSONL journal from your own app and compare its recorded decisions and committed balances offline.</p>
<a class="button" href="{html.escape(checker, quote=True)}">照合器を取得 / Download checker</a><pre><code>python3 lean-regen-check.pyz my-trace.jsonl</code></pre>
<p class="note">Python 3.9+ · 1,153件のLean参照結果を同梱。未収録の入力は範囲外と表示します。The bundled oracle covers 1,153 specific inputs. Use the native Lean mode to check additional inputs. A matching journal covers only its recorded operations.</p></section>'''
    page = page.replace('__TRACE_CHECKER__', trace_section)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w" if args.replace else "x", encoding="utf-8") as stream:
        stream.write(page)
    print(f"BUILT OSS_SHOWCASE {args.out}; signup disabled; no network deployment")


if __name__ == "__main__":
    main()
