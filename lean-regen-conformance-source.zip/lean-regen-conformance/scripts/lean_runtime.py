"""Check the historical source snapshot and select its explicit Lean/Lake runtime."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UPSTREAM = ROOT / "packages" / "lean-verified-sdlc"
# Pin the manifest supplied with the immutable v1.0.0 snapshot. This detects
# a changed index even if someone also removed or rehashed the changed files.
PROVENANCE_SHA256 = "4f65c07a3d6f0b87f5274d72858c23fbda9a62fb4ae7b29304d683a1a5b9fb10"


def check_upstream(root=ROOT):
    manifest = root / "UPSTREAM_PROVENANCE.json"
    if manifest.is_symlink():
        raise ValueError("Unexpected symlink for upstream provenance")
    raw = manifest.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PROVENANCE_SHA256:
        raise ValueError("Pinned upstream provenance digest differs")
    record = json.loads(raw)
    source = root / "packages" / "lean-verified-sdlc"
    if source.is_symlink() or source.parent.is_symlink():
        raise ValueError("Unexpected symlink for upstream distribution")
    entries = record.get("files")
    if not isinstance(entries, dict) or not entries:
        raise ValueError("Missing upstream file index")
    errors = []
    for name, expected in entries.items():
        rel = Path(name)
        if rel.is_absolute() or rel.as_posix() != name or ".." in rel.parts:
            raise ValueError("Unsafe upstream index path")
        path = source / rel
        if path.is_symlink() or not path.is_file():
            errors.append(name + ": missing or symlink")
        elif hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            errors.append(name + ": digest differs")
    extra = []
    for path in source.rglob("*"):
        relative = path.relative_to(source)
        if any(part in {"__pycache__", ".lake"} for part in relative.parts):
            continue
        if path.is_symlink():
            errors.append(str(relative) + ": symlink")
        elif path.is_file() and relative.as_posix() not in entries:
            extra.append(relative.as_posix())
    if errors or extra:
        raise ValueError("Upstream distribution changed: " + "; ".join(errors + extra))
    return {"status": "UPSTREAM_BYTES_MATCH", "file_count": len(entries),
            "version": record["upstream_version"],
            "notice": "Content identity only; this is not a fresh proof or approval."}


def doctor(tool_bin):
    binary_dir = tool_bin.expanduser().resolve()
    results = {}
    for name in ("lean", "lake"):
        binary = binary_dir / name
        if not binary.is_file():
            raise ValueError(f"Missing trusted runtime executable: {binary}")
        run = subprocess.run([str(binary), "--version"], capture_output=True,
                             text=True, timeout=30, check=False)
        if run.returncode:
            raise ValueError(f"{name} --version failed: exit {run.returncode}")
        results[name] = run.stdout.strip()
        results[name + "_sha256"] = hashlib.sha256(binary.read_bytes()).hexdigest()
    if not re.match(r"^Lean \(version 4\.19\.0[,)]", results["lean"]):
        raise ValueError("The historical demo requires stable Lean 4.19.0.")
    if not re.fullmatch(r"Lake version [^\s]+ \(Lean version 4\.19\.0\)", results["lake"]):
        raise ValueError("The historical demo requires Lake built for stable Lean 4.19.0.")
    return {"status": "HISTORICAL_RUNTIME_FOUND", "tool_bin": str(binary_dir), **results}
