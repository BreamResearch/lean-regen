# セキュリティと報告 · Security and reporting

一般公開してよい不具合は、合成データを使って Issue に報告できます。機密を含む脆弱性は、GitHub の **Security → Report a vulnerability** が表示されていれば、そちらから非公開で報告してください。非公開窓口が利用できない場合は、公開 Issue に詳細を書かず、機密を含まない形で連絡先だけを尋ねてください。

Use synthetic data for public bug reports. For a sensitive vulnerability, use **Security → Report a vulnerability** when available. If private reporting is unavailable, ask for a private contact channel without posting sensitive details. [GitHub Security](https://github.com/BreamResearch/lean-regen/security)

P0 の検査スクリプトは、信頼できるローカルの Lean プロジェクトを実行します。不特定利用者のアップロードを受け付けるサービスには、別途、隔離された実行環境と独立した検査権限が必要です。

The source alpha runs trusted local Lean projects. Accepting arbitrary uploads requires isolated workers and an independent verifier. Proof soundness, specification meaning, worker isolation, identity, release binding and runtime assumptions each require their own evidence. [検査範囲 / Proof and runtime scope (JA)](docs/PROOF_AND_RUNTIME_SCOPE_JA.md)

運用上の事故では記録を保全し、影響を受けた権限を失効させ、危険な配布を停止します。For an operational incident, preserve historical evidence, revoke affected capabilities, stop unsafe promotion and select rollback or quarantine under the standing policy.
