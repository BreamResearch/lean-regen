# Lean release observations

Run this optional network operation locally with Python 3.11+. It reads the official stable release metadata from GitHub and writes to a local SQLite database. It issues no GitHub writes and uses no credentials.

```sh
python3 autonomy/watch_lean.py poll --database local-runs/observations.sqlite --candidates local-runs/candidates
python3 autonomy/watch_lean.py status --database local-runs/observations.sqlite
python3 -m unittest discover -s autonomy -p test_watch_lean.py
```

The historical inventory profile covers newer stable releases in the pinned Lean major version for the selected official Linux archive, including its bundled Lake. Select the target using `--arch x86_64` (default) or `--arch aarch64`. The target is part of the request identity. Other majors and older versions are recorded as outside scope. Each distinct release identity and reported archive digest yields one observation per baseline. Repeated polling preserves the existing record. A change to an already observed tag is quarantined. The observation records the upstream digest as metadata. Download integrity and proof checking belong to the verifier.

When the upstream archive matches the local checker's pinned release, the optional candidate directory receives the historical proof module and a manifest. The manifest binds the release observation, compiler archive, contract file, solution and checker profile. This producer reuses the current implementation and proof for a compatibility check. It has no signing or publishing credentials. Repeated observations reproduce the same candidate. Conflicting release identities stop further preparation.

The metrics use distinct change requests as denominators. Blocked requests count, unchanged polls and replays do not. Failed network pulls that yielded no identifiable request are reported separately. This observer has no promotion path. Its completion numerator is consequently zero. Operators may invoke it from an existing scheduler. A continuously deployed scheduler, external spending limits, Lake package dependency resolution, repair of failed proofs and unattended publishing require later work.

For unattended polling, run the same program with `watch` in place of `poll`. It stays in the foreground, polls daily by default, and continues after an observation failure. A process supervisor can restart it using the same database. `--interval-seconds` changes the interval. To prepare an already observed request offline, use `prepare --request-id ID --database FILE --candidates DIR`.
