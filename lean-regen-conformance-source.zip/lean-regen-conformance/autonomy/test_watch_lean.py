import sqlite3
import tempfile
import unittest
from pathlib import Path
from watch_lean import initialize, metrics, observe
from prepare_candidate import prepare


def release(tag="v4.36.0", digest="a" * 64):
    url = "https://github.com/leanprover/lean4/releases"
    name = f"lean-{tag[1:]}-linux.tar.zst"
    return {"id": 123, "draft": False, "prerelease": False, "tag_name": tag,
            "html_url": f"{url}/tag/{tag}", "assets": [
                {"name": name, "browser_download_url": f"{url}/download/{tag}/{name}",
                 "digest": "sha256:" + digest}]}


class ObserverTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.addCleanup(self.db.close)
        initialize(self.db)

    def record(self, item):
        return observe(self.db, item, "v4.19.0")

    def test_replay_conflict_and_no_promotion(self):
        first = self.record(release())
        self.assertFalse(first["replay"])
        self.assertIn("BLOCKED_INDEPENDENT", first["state"])
        self.assertTrue(self.record(release())["replay"])
        self.assertEqual(self.record(release(digest="b"*64))["state"], "BLOCKED_RELEASE_IDENTITY_CHANGED")
        self.assertEqual(metrics(self.db)["declared_in_scope"]["update_requests"], 2)

    def test_predeclared_scope(self):
        self.record(release("v4.19.0"))
        self.record(release("v5.0.0"))
        result = self.record(release(digest=""))
        self.assertEqual(result["state"], "BLOCKED_MISSING_DISTRIBUTION_DIGEST")
        self.assertEqual(metrics(self.db)["all_requests"], {"unattended_promotions": 0, "update_requests": 2, "rate": 0})
        self.assertEqual(metrics(self.db)["declared_in_scope"]["update_requests"], 1)

    def test_source_mismatch_is_rejected(self):
        value = release()
        value["html_url"] += "/different"
        with self.assertRaises(ValueError):
            self.record(value)
        self.assertIsNone(metrics(self.db)["all_requests"]["rate"])

    def test_architecture_is_part_of_the_observed_identity(self):
        value = release()
        first = self.record(value)
        second = observe(self.db, value, "v4.19.0", "aarch64")
        self.assertNotEqual(first["request_id"], second["request_id"])
        self.assertEqual(second["state"], "BLOCKED_MISSING_DISTRIBUTION_DIGEST")

    def test_real_profile_replay_and_retarget(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            db_name = path / "events.sqlite"
            db = sqlite3.connect(db_name)
            self.addCleanup(db.close)
            initialize(db)
            value = release(digest="2b7ab1ed8b92d2e6abfaf41344823b510064dbc9c0260cac73eb496ab2dea6eb")
            event = observe(db, value, "v4.19.0")
            result = prepare(db_name, event, path / "candidates")
            self.assertEqual(result["state"], "CANDIDATE_PREPARED")
            self.assertEqual(result, prepare(db_name, event, path / "candidates"))
            proof = path / "candidates" / result["candidate_id"] / "Solution.lean"
            proof.write_text("changed")
            with self.assertRaisesRegex(ValueError, "differs"):
                prepare(db_name, event, path / "candidates")
            observe(db, release(digest="b" * 64), "v4.19.0")
            self.assertEqual(prepare(db_name, event, path / "candidates")["reason"], "AMBIGUOUS_RELEASE")


if __name__ == "__main__":
    unittest.main()
