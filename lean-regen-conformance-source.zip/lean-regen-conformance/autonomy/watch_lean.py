#!/usr/bin/env python3
"""Observe Lean's official stable Linux x86_64 release and persist update requests."""
import argparse
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys
import time
from urllib.error import URLError
from urllib.request import Request, urlopen
from prepare_candidate import prepare

ROOT = Path(__file__).resolve().parents[1]
PIN = ROOT / "packages/lean-verified-sdlc/assets/lean-starter/lean-toolchain"
API = "https://api.github.com/repos/leanprover/lean4/releases/latest"
ARCHIVES = {"x86_64": "linux", "aarch64": "linux_aarch64"}


def version(tag):
    if not isinstance(tag, str) or not re.fullmatch(r"v(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)", tag):
        raise ValueError("Expected a stable semantic version tag")
    return tuple(map(int, tag[1:].split(".")))


def fetch():
    request = Request(API, headers={"Accept": "application/vnd.github+json", "User-Agent": "lean-regen-release-observer"})
    with urlopen(request, timeout=25) as response:
        if response.geturl() != API:
            raise ValueError("Unexpected release metadata URL")
        raw = response.read(2_000_001)
    if len(raw) > 2_000_000:
        raise ValueError("Release metadata exceeds size limit")
    return json.loads(raw)


def observe(db, release, pin, architecture="x86_64"):
    """Serialize observations so replays and simultaneous polls have a single outcome."""
    tag = release["tag_name"]
    new, old = version(tag), version(pin)
    url = f"https://github.com/leanprover/lean4/releases/tag/{tag}"
    if (release["draft"] is not False or release["prerelease"] is not False or
            release["html_url"] != url or type(release["id"]) is not int or release["id"] <= 0):
        raise ValueError("Unexpected release identity")
    profile = f"historical-core-linux-{architecture}-v1"
    name = f"lean-{tag[1:]}-{ARCHIVES[architecture]}.tar.zst"
    assets = [asset for asset in release["assets"] if asset["name"] == name]
    digest = None
    if len(assets) == 1 and assets[0].get("browser_download_url") == (
            f"https://github.com/leanprover/lean4/releases/download/{tag}/{name}"):
        value = assets[0].get("digest")
        if isinstance(value, str) and re.fullmatch(r"sha256:[0-9a-f]{64}", value):
            digest = value
    subject = {"profile": profile, "base": pin, "release_id": release["id"], "tag": tag,
               "asset": name, "upstream_digest": digest, "url": url}
    request_id = hashlib.sha256(json.dumps(subject, sort_keys=True).encode()).hexdigest()
    with db:
        db.execute("BEGIN IMMEDIATE")
        duplicate = db.execute("SELECT result FROM observations WHERE id=?", (request_id,)).fetchone()
        if duplicate:
            return {**subject, "request_id": request_id, "state": duplicate[0], "replay": True}
        conflict = db.execute("SELECT 1 FROM observations WHERE profile=? AND base=? AND tag=?",
                              (profile, pin, tag)).fetchone()
        in_scope = new > old and new[0] == old[0]
        if conflict:
            result = "BLOCKED_RELEASE_IDENTITY_CHANGED"
        elif not in_scope:
            result = "UNCHANGED" if new == old else "OUT_OF_SCOPE"
        elif not digest:
            result = "BLOCKED_MISSING_DISTRIBUTION_DIGEST"
        else:
            result = "BLOCKED_INDEPENDENT_RECEIPT_AND_STANDING_AUTHORITY"
        db.execute("INSERT INTO observations VALUES (?,?,?,?,?,?,?,?,?)",
                   (request_id, profile, pin, tag, int(in_scope), result,
                    json.dumps(subject, sort_keys=True), datetime.now(timezone.utc).isoformat(),
                    int(new != old or bool(conflict))))
    return {**subject, "request_id": request_id, "state": result, "replay": False}


def initialize(db):
    db.execute("""CREATE TABLE IF NOT EXISTS observations (
        id TEXT PRIMARY KEY, profile TEXT NOT NULL, base TEXT NOT NULL, tag TEXT NOT NULL,
        in_scope INTEGER NOT NULL, result TEXT NOT NULL, subject TEXT NOT NULL,
        seen_at TEXT NOT NULL, update_event INTEGER NOT NULL)""")
    db.execute("""CREATE TABLE IF NOT EXISTS failed_polls (
        seen_at TEXT NOT NULL, error_type TEXT NOT NULL)""")


def metrics(db):
    all_count, scoped = db.execute(
        "SELECT COUNT(*), COALESCE(SUM(in_scope),0) FROM observations WHERE update_event=1"
    ).fetchone()
    def rate(total):
        return {"unattended_promotions": 0, "update_requests": total, "rate": 0 if total else None}
    return {"all_requests": rate(all_count), "declared_in_scope": rate(scoped),
            "failed_polls_before_event_identification": db.execute("SELECT COUNT(*) FROM failed_polls").fetchone()[0]}


def run_once(args):
    try:
        if args.command not in {"poll", "watch"} and not args.database.is_file():
            raise ValueError("No observation database yet")
        if args.command in {"poll", "watch"}:
            args.database.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(args.database, timeout=15)) as db:
            initialize(db)
            report = {}
            if args.command in {"poll", "watch"}:
                try:
                    pin = PIN.read_text().strip().removeprefix("leanprover/lean4:")
                    report["observation"] = observe(db, fetch(), pin, args.arch)
                except (ValueError, KeyError, OSError, URLError, TypeError) as error:
                    with db:
                        db.execute("INSERT INTO failed_polls VALUES (?,?)",
                                   (datetime.now(timezone.utc).isoformat(), type(error).__name__))
                    raise
            if args.command == "prepare":
                row = db.execute("SELECT result, subject FROM observations WHERE id=?", (args.request_id,)).fetchone()
                if row is None:
                    raise ValueError("Unknown update request")
                report["observation"] = {**json.loads(row[1]), "request_id": args.request_id, "state": row[0]}
            if args.candidates:
                report["candidate"] = prepare(args.database, report["observation"], args.candidates)
            report["metrics"] = metrics(db)
            print(json.dumps(report, indent=2), flush=True)
        return 0
    except (ValueError, KeyError, TypeError, OSError, URLError, sqlite3.Error) as error:
        print(json.dumps({"state": "POLL_OR_STORAGE_FAILED", "reason": str(error)}), file=sys.stderr)
        return 2



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["poll", "watch", "status", "prepare"])
    parser.add_argument("--database", type=Path, required=True)
    parser.add_argument("--candidates", type=Path, help="Prepare an unsigned local candidate for a matching checker profile")
    parser.add_argument("--request-id", help="Previously observed request for offline preparation")
    parser.add_argument("--interval-seconds", type=int, default=86400, help="Foreground watch interval, minimum 60s")
    parser.add_argument("--arch", choices=sorted(ARCHIVES), default="x86_64", help="Target Linux architecture for an upstream poll")
    args = parser.parse_args()
    if args.interval_seconds < 60:
        parser.error("The minimum polling interval is 60 seconds")
    if args.command == "prepare" and (not args.candidates or not args.request_id):
        parser.error("prepare requires --candidates and --request-id")
    if (args.candidates and args.command == "status") or (args.request_id and args.command != "prepare"):
        parser.error("Unexpected arguments for this command")
    if args.command != "watch":
        return run_once(args)
    try:
        while True:
            run_once(args)
            time.sleep(args.interval_seconds)
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main())
