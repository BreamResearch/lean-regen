"""Prepare a local proof candidate for the fixed inventory profile."""
from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile

ROOT = Path(__file__).resolve().parents[1]
HISTORICAL = ROOT / "packages/lean-verified-sdlc/assets/lean-starter"
CHECKER = ROOT / "packages/independent-checker"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def prepare(database, observation, destination):
    if observation["state"] != "BLOCKED_INDEPENDENT_RECEIPT_AND_STANDING_AUTHORITY":
        return {"state": "NO_CANDIDATE", "reason": observation["state"]}
    with closing(sqlite3.connect(database, timeout=15)) as db:
        # Serializes the conflict check with concurrent polls until the snapshot is complete.
        db.execute("BEGIN IMMEDIATE")
        tags = db.execute("SELECT id FROM observations WHERE profile=? AND base=? AND tag=?",
                          tuple(observation[k] for k in ("profile", "base", "tag"))).fetchall()
        if tags != [(observation["request_id"],)]:
            return {"state": "NO_CANDIDATE", "reason": "AMBIGUOUS_RELEASE"}
        lock = (CHECKER / "profile.lock.json").read_bytes()
        profile = json.loads(lock)
        platforms = {"historical-core-linux-x86_64-v1": "x86_64", "historical-core-linux-aarch64-v1": "aarch64"}
        archive = profile["toolchains"][platforms[observation["profile"]]]
        if (observation["tag"] != "v" + profile["lean"] or
                archive["url"].rsplit("/", 1)[-1] != observation["asset"] or
                observation["upstream_digest"] != "sha256:" + archive["sha256"]):
            return {"state": "NO_CANDIDATE", "reason": "NO_MATCHING_CHECKER_PROFILE"}
        for module in ("Specification", "Implementation"):
            name = f"VerifiedInventory/{module}.lean"
            if profile["files"][name] != digest((HISTORICAL / name).read_bytes()):
                raise ValueError("Frozen historical module differs from checker: " + name)
        proof = (HISTORICAL / "VerifiedInventory/Proofs.lean").read_bytes()
        manifest = {"schema": 1, "request_id": observation["request_id"], "base": observation["base"],
                    "target": observation["tag"], "target_archive_sha256": archive["sha256"],
                    "profile_sha256": digest(lock), "solution_sha256": digest(proof),
                    "seed_contract_sha256": digest((HISTORICAL / "Contract.lean").read_bytes()),
                    "generation": "reuse_seed_proof_against_frozen_implementation",
                    "assurance": "UNVERIFIED_CANDIDATE"}
        encoded = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
        candidate_id = digest(encoded)
        destination.mkdir(exist_ok=True, parents=True)
        target = destination / candidate_id
        if not target.exists():
            with tempfile.TemporaryDirectory(dir=destination) as staging:
                complete = Path(staging) / "candidate"
                complete.mkdir()
                (complete / "candidate.json").write_bytes(encoded)
                (complete / "Solution.lean").write_bytes(proof)
                try:
                    complete.rename(target)
                except OSError:
                    if not target.is_dir():
                        raise
        if (target.is_symlink() or {item.name for item in target.iterdir()} != {"candidate.json", "Solution.lean"}
                or any(p.is_symlink() or not p.is_file() for p in target.iterdir())
                or (target / "candidate.json").read_bytes() != encoded
                or (target / "Solution.lean").read_bytes() != proof):
            raise ValueError("Existing candidate directory differs from the computed snapshot")
        return {"state": "CANDIDATE_PREPARED", "candidate_id": candidate_id, "manifest": manifest}
