"""Integration checks with a real, previously built Lean executable and SQLite."""
import argparse
import concurrent.futures
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

import inventory as inv

HERE = Path(__file__).resolve().parent


class InventoryTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.dir = Path(tmp.name)
        self.db = self.dir / "inventory.db"

    def apply(self, key, operation, quantity):
        return inv.apply_request(self.db, self.engine, key, operation, quantity)

    def test_cli_and_replay_of_accepted_and_rejected_requests(self):
        def cli(*args):
            result = subprocess.run([sys.executable, HERE / "inventory.py", *args], text=True,
                                    capture_output=True, check=True, timeout=10)
            return json.loads(result.stdout)
        cli("init", "--db", self.db, "--capacity", "3")
        def request(key, op, q):
            return cli("apply", "--db", self.db, "--engine", self.engine, "--id", key, op, q)
        accepted = request("a", "reserve", "2")
        rejected = request("b", "reserve", "2")
        self.assertEqual((accepted["outcome"], rejected["outcome"]), ("accepted", "rejected"))
        request("c", "release", "2")
        self.assertEqual(request("a", "reserve", "2"), accepted)
        self.assertEqual(request("b", "reserve", "2"), rejected)
        self.assertEqual(cli("show", "--db", self.db),
                         {"schema_version": 2, "capacity": 3, "available": 3, "reserved": 0, "requests": 3})
        with self.assertRaisesRegex(ValueError, "different operation"):
            self.apply("a", "release", 2)

    def test_concurrent_distinct_and_duplicate_requests(self):
        inv.initialize(self.db, 4)
        requests = ["duplicate"] * 8 + [f"other-{i}" for i in range(8)]
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda key: self.apply(key, "reserve", 1), requests))
        distinct = {r["request_id"]: r for r in results}
        self.assertEqual(results[:8], [results[0]] * 8)
        self.assertEqual(sum(r["outcome"] == "accepted" for r in distinct.values()), 4)
        self.assertEqual((inv.inspect(self.db)["reserved"],inv.inspect(self.db)["requests"]), (4,9))

    def test_64_bit_quantities_and_input_decoding(self):
        inv.initialize(self.db, inv.MAX_INT)
        self.assertEqual(self.apply("full", "reserve", inv.MAX_INT)["reserved"], inv.MAX_INT)
        self.assertEqual(self.apply("release", "release", inv.MAX_INT)["available"], inv.MAX_INT)
        self.assertEqual(self.apply("zero", "release", 0)["outcome"], "rejected")
        for value in ("18446744073709551616", str(inv.MAX_INT+1), "-1", "1.0", " 1", "01", "１"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                inv.natural(value)
        for value in (True, 1.5, -1, inv.MAX_INT+1):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.apply("invalid", "reserve", value)
        self.assertEqual(inv.inspect(self.db)["requests"], 3)

    def test_failed_engine_and_invalid_response_leave_no_request(self):
        inv.initialize(self.db, 7)
        before = inv.inspect(self.db)
        invalid = self.dir / "invalid-output"
        invalid.write_text("#!/bin/sh\necho 'accepted 7 7'\n")
        invalid.chmod(0o700)
        with self.assertRaises(subprocess.CalledProcessError):
            inv.apply_request(self.db, Path("/usr/bin/false"), "again", "reserve", 1)
        with self.assertRaisesRegex(ValueError, "boundary checks"):
            inv.apply_request(self.db, invalid, "again", "reserve", 1)
        stalled = self.dir / "stalled"
        stalled.write_text("#!/bin/sh\nexec /bin/sleep 15\n")
        stalled.chmod(0o700)
        with self.assertRaises(subprocess.TimeoutExpired):
            inv.apply_request(self.db, stalled, "again", "reserve", 1)
        self.assertEqual(inv.inspect(self.db), before)
        self.assertEqual(self.apply("again", "reserve", 1)["reserved"], 1)

    def test_sqlite_recovers_after_writer_exits_before_commit(self):
        inv.initialize(self.db, 8)
        self.apply("before", "reserve", 2)
        before = inv.inspect(self.db)
        code = """import os,sqlite3,sys
db = sqlite3.connect(sys.argv[1])
db.execute('BEGIN IMMEDIATE')
db.execute('UPDATE pool SET reserved=7 WHERE id=1')
db.execute("INSERT INTO requests VALUES(2,'inflight','reserve',5,'accepted',1,7)")
os._exit(91)
"""
        child = subprocess.run([sys.executable, "-c", code, self.db], timeout=5)
        self.assertEqual(child.returncode, 91)
        self.assertEqual(inv.inspect(self.db), before)
        self.assertEqual(self.apply("inflight", "reserve", 5)["reserved"], 7)

    def test_migration_replay_and_restore_to_a_new_database(self):
        inv.initialize(self.db, 10, schema_version=1)
        with closing(inv.connect(self.db, "rw")) as db, inv.write_transaction(db):
            db.execute("UPDATE pool SET available=7,reserved=3")
            db.execute("INSERT INTO requests VALUES(1,'old','reserve',3,'accepted',7,3)")
            db.execute("INSERT INTO requests VALUES(2,'denied','release',9,'rejected',7,3)")
        old = inv.inspect(self.db)
        with self.assertRaisesRegex(ValueError, "Migrate"):
            self.apply("later", "release", 3)
        backup = self.dir / "previous.db"
        self.assertTrue(inv.migrate(self.db, backup)["changed"])
        self.assertEqual(inv.inspect(backup), old)
        self.assertEqual(inv.inspect(self.db), {**old, "schema_version": 2})
        self.assertFalse(inv.migrate(self.db, backup)["changed"])
        self.assertEqual(self.apply("old", "reserve", 3)["outcome"], "accepted")
        self.assertEqual(self.apply("denied", "release", 9)["outcome"], "rejected")
        self.apply("later", "release", 3)
        restored = self.dir / "restored.db"
        inv.copy_database(backup, restored)
        self.assertEqual(inv.inspect(restored), old)
        with closing(inv.connect(restored, "ro")) as db:
            self.assertEqual([tuple(r) for r in db.execute("SELECT * FROM requests ORDER BY seq")],
                             [(1,"old","reserve",3,"accepted",7,3),(2,"denied","release",9,"rejected",7,3)])
        self.assertEqual(inv.inspect(self.db)["requests"], 3)
        with self.assertRaises(FileExistsError):
            inv.copy_database(backup, self.db)
        current_copy = self.dir / "current.db"
        inv.copy_database(self.db, current_copy)
        self.assertEqual(inv.inspect(current_copy), inv.inspect(self.db))
        self.assertEqual(os.stat(current_copy).st_mode & 0o777, 0o600)

    def test_unknown_database_or_unavailable_backup_blocks_migration(self):
        with sqlite3.connect(self.db) as unrelated:
            unrelated.execute("CREATE TABLE unrelated(value INTEGER)")
        with self.assertRaisesRegex(ValueError, "Unknown SQLite application"):
            inv.inspect(self.db)
        old = self.dir / "old.db"
        inv.initialize(old, 1, schema_version=1)
        with self.assertRaises(FileExistsError):
            inv.migrate(old, self.db)
        self.assertEqual(inv.inspect(old)["schema_version"], 1)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--engine", required=True, type=Path)
    InventoryTests.engine = p.parse_args().engine.resolve(strict=True)
    unittest.main(argv=[__file__, "-v"])
