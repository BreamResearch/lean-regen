import VerifiedInventory

open VerifiedInventory

def main (args : List String) : IO UInt32 := do
  let [a, r, name, q] := args | return 2
  let some available := a.toNat? | return 2
  let some reserved := r.toNat? | return 2
  let some quantity := q.toNat? | return 2
  let parsed : Option Command := match name with
    | "reserve" => some (.reserve quantity)
    | "release" => some (.release quantity)
    | _ => none
  let some cmd := parsed | return 2
  let result := step ⟨available, reserved⟩ cmd
  let label := match result with
    | .accepted _ => "accepted"
    | .rejected _ => "rejected"
  IO.println s!"{label} {result.state.available} {result.state.reserved}"
  return 0
