# 単一管理者の在庫台帳 · Single-custodian SQLite inventory

このローカルCLIは、既存の予約・解放関数 `VerifiedInventory.step` をネイティブ実行し、応答と要求IDをSQLiteに保存します。登録とネットワーク接続は不要です。1人の管理者が1つの資源の数量を扱う例です。アカウント別の予約、ネットワークAPI、顧客の稼働データへの接続は対象外です。

The local CLI calls the compiled `VerifiedInventory.step` decision function, then stores the result and request ID in SQLite. One custodian manages one resource. You can run it offline without an account. Per-user ownership and a network API are outside this example’s scope.

## 実行 · Run the example

LinuxまたはmacOSで、Python 3.11以上、SQLite 3.37以上、Lean 4.19.0と同梱のLakeを使用します。リポジトリのルートから実行してください。新規のビルド先はチェックアウトの外に置きます。

macOS 27のApple Silicon機では、ルートREADMEのmacOS用設定でXcodeのリンカーを選択してからビルドします。手元で検査した環境はmacOS 27.0.1とXcode 27.2です。

From the repository root, use Python 3.11+, SQLite 3.37+ and Lean/Lake 4.19.0 for macOS or Linux. Choose fresh paths outside the checkout. On Apple Silicon with macOS 27, first apply the linker settings in the [root README](../../README.md).

```sh
example=examples/sqlite_inventory
python3 "$example/build_engine.py" --tool-bin /absolute/path/to/lean-4.19.0/bin --dest ../inventory-build
engine=../inventory-build/.lake/build/bin/inventory_step
python3 "$example/test_inventory.py" --engine "$engine"
python3 "$example/inventory.py" init --db ../inventory.db --capacity 10
python3 "$example/inventory.py" apply --db ../inventory.db --engine "$engine" --id order-1 reserve 3
python3 "$example/inventory.py" show --db ../inventory.db
python3 "$example/inventory.py" backup --db ../inventory.db --out ../saved.db
python3 "$example/inventory.py" restore --db ../restored.db --backup ../saved.db
```

`order-1` を同じ内容で再送すると、初回の応答（上の例では予約済み3、利用可能7）を返します。初回の拒否も記録します。異なる内容でのID再利用はエラーです。現在の残高は `show` で確認できます。数量の入力は0から9223372036854775807までの10進整数です。数量0の予約・解放はLean関数が拒否します。

The commands above start a fresh ledger with 10 units and reserve 3, leaving 7 available. Retry `order-1` with the same inputs to read the original outcome. The ledger also records rejections and refuses reuse of the ID with different inputs. Quantities range from 0 to 9,223,372,036,854,775,807. A request for 0 is rejected by the Lean decision function.

## 永続化と復元 · Persistence and recovery

`BEGIN IMMEDIATE` の中で重複検査、Lean呼び出し、状態の更新、要求の記録を行います。別の書き手は最長15秒待ちます。Lean実行は5秒でタイムアウトします。タイムアウト、プロセス失敗、範囲外の応答、保存失敗時は処理をロールバックします。SQLiteはローカルファイルシステム上で `synchronous=FULL` を使用します。DBとそのディレクトリ、実行するバイナリの保護はOSの管理者が担います。新規DBとバックアップは所有者専用モード0600で作成します。ハードリンクによる新規パスへの公開に対応したファイルシステムが必要です。

v1は利用可能数と予約済み数を別々に保存します。v2は容量と予約済み数を保存し、利用可能数を生成列で計算します。`Migration.lean` は、容量保存条件を満たすすべてのモデル状態で、容量と予約済み数から元の両方の数量を復元できることを示します。ビルドはこの定理と許容公理も検査します。

`migrate --db OLD.db --backup BEFORE.db` は書込みロックを取得し、SQLiteのバックアップAPIで旧版を新規パスへ保存して整合性を検査した後、移行前後の数量を同一トランザクションで照合します。要求履歴のテーブルは引き継ぎます。v2での再実行は冪等です。途中で停止した場合は `show` で版を確認し、v1なら新規バックアップ名で再試行できます。

`restore` は新規DBを作ります。現行DBへの上書きは拒否します。移行後に受け付けた要求は移行前のバックアップに含まれません。旧コードの再配布とデータの復元には別の判断が必要です。

One `BEGIN IMMEDIATE` transaction covers duplicate detection, the native decision, the state update and the request log. A failed decision or failed write rolls back. `migrate --db OLD.db --backup BEFORE.db` backs up the previous version, then checks the quantities in the migration transaction. `restore` writes a new database. Restoring a backup also restores its point in time.

## 検査の範囲 · Evidence and assumptions

ビルド時は68個の歴史的ソースを照合し、変更していない仕様・実装・証明を別のディレクトリでコンパイルします。`Bridge.lean` が入力をLeanの自然数に変換し、`step` の結果を標準出力に書き出します。保存側は結果の書式、許可条件、数量増減を照合します。入出力・コンパイラ・OS・SQLite・ファイルシステム・並行処理・移行の正しさについては、統合テストと明示した前提が根拠です。これらを対象とする精密化証明、独立検査の署名、本番配布は未実施です。

The build verifies 68 historical files before compiling the fixed source. A Lean theorem verifies the quantities in the schema migration model. Integration tests exercise the native bridge, SQLite and recovery under the documented filesystem assumptions.

## ソースとネイティブ配布物のライセンス · Licensing

この例のプロジェクトソースはApache-2.0です。macOSで手元に生成した `inventory_step` にはLeanランタイム、GNU MP、libuv、mimallocのシンボルが含まれました。Lean 4.19.0配布物の `LICENSES` はGNU MPについてLGPLv3を掲げています。ネイティブバイナリを再配布する際は実際にリンクされた各部品の条件も適用されます。ソースアルファの配布物と依存の範囲は[第三者通知](../../THIRD_PARTY_NOTICES.md)に記載しています。

Project sources use Apache-2.0. A locally linked macOS executable included Lean runtime, GNU MP, libuv and mimalloc symbols. Binary redistribution must account for the linked component licenses, including the GNU MP terms identified by the toolchain. [Third-party notices](../../THIRD_PARTY_NOTICES.md)
