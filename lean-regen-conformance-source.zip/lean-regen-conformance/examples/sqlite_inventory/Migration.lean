import VerifiedInventory.Specification

namespace InventoryMigration
open VerifiedInventory

/-- The v2 quantity view stores the capacity and reserved count. -/
def observe (capacity reserved : Nat) : State :=
  { available := capacity - reserved, reserved := reserved }

/-- Reconstructing a valid v1 inventory from just those stored fields preserves
    both visible quantities. SQLite execution and the request ledger are tested separately. -/
theorem preserve_quantities (capacity : Nat) (s : State) (valid : WellFormed capacity s) :
    observe capacity s.reserved = s := by
  cases s with
  | mk available reserved =>
    change available + reserved = capacity at valid
    subst capacity
    simp [observe]

end InventoryMigration

#print axioms InventoryMigration.preserve_quantities
