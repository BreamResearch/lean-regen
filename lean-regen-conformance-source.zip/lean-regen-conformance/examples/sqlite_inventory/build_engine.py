"""Build a native adapter to the unchanged v1.0.0 core in a fresh directory."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from leanregen import UPSTREAM, check_upstream, doctor


def build(tool_bin, dest):
    check_upstream()
    runtime = doctor(tool_bin)
    dest = dest.resolve()
    if dest == ROOT or ROOT in dest.parents:
        raise ValueError("Choose a new build directory outside the source checkout")
    dest.mkdir(parents=True, exist_ok=False)
    source = UPSTREAM / "assets/lean-starter"
    for name in ("VerifiedInventory.lean", "lean-toolchain", "lake-manifest.json", "lakefile.toml"):
        shutil.copyfile(source / name, dest / name)
    shutil.copytree(source / "VerifiedInventory", dest / "VerifiedInventory")
    shutil.copyfile(HERE / "Bridge.lean", dest / "Bridge.lean")
    shutil.copyfile(HERE / "Migration.lean", dest / "Migration.lean")
    with (dest / "lakefile.toml").open("a") as handle:
        handle.write('\n[[lean_exe]]\nname = "inventory_step"\nroot = "Bridge"\n')
    env = {k: v for k, v in os.environ.items() if not k.startswith(("LEAN", "LAKE", "ELAN", "DYLD_", "LD_"))}
    env["PATH"] = runtime["tool_bin"] + os.pathsep + env.get("PATH", "")
    subprocess.run([str(Path(runtime["tool_bin"]) / "lake"), "build", "inventory_step"],
                   env=env, cwd=dest, timeout=300, check=True)
    audit = subprocess.run([str(Path(runtime["tool_bin"]) / "lake"), "env",
                            str(Path(runtime["tool_bin"]) / "lean"), "-DwarningAsError=true", "Migration.lean"],
                           env=env, cwd=dest, timeout=60, text=True, capture_output=True)
    print(audit.stdout, end="")
    print(audit.stderr, file=sys.stderr, end="")
    audit.check_returncode()
    sys.path.insert(0, str(UPSTREAM / "scripts"))
    from assurance_lib import parse_axioms
    allowed = json.loads((source / "assurance.json").read_text())["allowed_axioms"]
    axioms = parse_axioms(audit.stdout, ["InventoryMigration.preserve_quantities"], allowed)
    exe = dest / ".lake/build/bin/inventory_step"
    digest = hashlib.sha256(exe.read_bytes()).hexdigest()
    print(json.dumps({"engine": str(exe), "sha256": digest, "lean_version": runtime["lean"],
                      "migration_model_axioms": axioms}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tool-bin", required=True, type=Path)
    parser.add_argument("--dest", required=True, type=Path)
    args = parser.parse_args()
    try:
        build(args.tool_bin, args.dest)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        parser.exit(2, f"Build failed: {exc}\n")
