"""Single-custodian SQLite inventory backed by the native Lean step function."""
import argparse
import json
import os
import re
import sqlite3
import subprocess
import tempfile
from contextlib import closing, contextmanager
from pathlib import Path

APP_ID = 0x4C524749
MAX_INT = (1 << 63) - 1
CURRENT = 2
POOL_V1 = """CREATE TABLE pool(
    id INTEGER PRIMARY KEY CHECK(id=1), capacity INTEGER NOT NULL CHECK(capacity>=0),
    available INTEGER NOT NULL CHECK(available BETWEEN 0 AND capacity),
    reserved INTEGER NOT NULL CHECK(reserved=capacity-available)) STRICT"""
POOL_V2 = """CREATE TABLE pool(
    id INTEGER PRIMARY KEY CHECK(id=1), capacity INTEGER NOT NULL CHECK(capacity>=0),
    reserved INTEGER NOT NULL CHECK(reserved BETWEEN 0 AND capacity),
    available INTEGER GENERATED ALWAYS AS (capacity-reserved) VIRTUAL) STRICT"""
JOURNAL = """CREATE TABLE requests(
    seq INTEGER PRIMARY KEY, request_id TEXT NOT NULL UNIQUE,
    operation TEXT NOT NULL CHECK(operation IN ('reserve','release')),
    quantity INTEGER NOT NULL CHECK(quantity>=0),
    outcome TEXT NOT NULL CHECK(outcome IN ('accepted','rejected')),
    available INTEGER NOT NULL CHECK(available>=0), reserved INTEGER NOT NULL CHECK(reserved>=0)
) STRICT"""


def natural(value):
    if not isinstance(value, str) or not re.fullmatch(r"0|[1-9][0-9]{0,18}", value):
        raise ValueError("Expected a canonical nonnegative decimal integer")
    number = int(value)
    if number > MAX_INT:
        raise ValueError("Integer exceeds the signed 64-bit storage range")
    return number


def connect(path, mode):
    uri = path.resolve().as_uri() + "?mode=" + mode
    db = sqlite3.connect(uri, uri=True, isolation_level=None, timeout=15)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA trusted_schema=OFF")
    if mode == "rw":
        db.execute("PRAGMA synchronous=FULL")
    return db


def version(db):
    if db.execute("PRAGMA application_id").fetchone()[0] != APP_ID:
        raise ValueError("Unknown SQLite application")
    value = db.execute("PRAGMA user_version").fetchone()[0]
    if value not in (1, CURRENT):
        raise ValueError("Unsupported inventory schema version")
    return value


@contextmanager
def write_transaction(db):
    db.execute("BEGIN IMMEDIATE")
    try:
        yield
        db.commit()
    except BaseException:
        db.rollback()
        raise


@contextmanager
def new_database(path):
    # Stage an entire database before exposing it. A hard link publishes only
    # to a previously absent name on the same local filesystem.
    if os.path.lexists(path):
        raise FileExistsError(f"Destination already exists: {path}")
    fd, raw = tempfile.mkstemp(prefix=".inventory-", dir=path.parent)
    os.close(fd)
    stage = Path(raw)
    try:
        with closing(sqlite3.connect(stage, isolation_level=None)) as db:
            db.execute("PRAGMA synchronous=FULL")
            yield db
        os.link(stage, path)
    finally:
        stage.unlink(missing_ok=True)


def initialize(path, capacity, schema_version=CURRENT):
    if type(capacity) is not int or not 0 <= capacity <= MAX_INT or schema_version not in (1, CURRENT):
        raise ValueError("Invalid capacity or schema")
    with new_database(path) as db, write_transaction(db):
        db.execute(f"PRAGMA application_id={APP_ID}")
        db.execute(f"PRAGMA user_version={schema_version}")
        db.execute(POOL_V1 if schema_version == 1 else POOL_V2)
        db.execute(JOURNAL)
        if schema_version == 1:
            db.execute("INSERT INTO pool VALUES(1,?,?,0)", (capacity, capacity))
        else:
            db.execute("INSERT INTO pool(id,capacity,reserved) VALUES(1,?,0)", (capacity,))


def state(db):
    row = db.execute("SELECT capacity,available,reserved FROM pool WHERE id=1").fetchone()
    if row is None or min(row) < 0 or row[1] + row[2] != row[0]:
        raise ValueError("Stored inventory violates capacity conservation")
    return dict(row)


def checked_step(engine, current, operation, quantity):
    available, reserved = current["available"], current["reserved"]
    proc = subprocess.run([str(engine.resolve()), str(available), str(reserved), operation, str(quantity)],
                          capture_output=True, text=True, check=True, timeout=5)
    match = re.fullmatch(r"(accepted|rejected) ([0-9]{1,19}) ([0-9]{1,19})\n", proc.stdout)
    if not match:
        raise ValueError("Unexpected native step output")
    outcome = match[1]
    next_available, next_reserved = natural(match[2]), natural(match[3])
    allowed = 0 < quantity <= (available if operation == "reserve" else reserved)
    delta = (quantity if operation == "reserve" else -quantity) if allowed else 0
    if (outcome != ("accepted" if allowed else "rejected")
            or (next_available, next_reserved) != (available - delta, reserved + delta)):
        raise ValueError("Native response disagrees with the persistence boundary checks")
    return outcome, next_available, next_reserved


def apply_request(path, engine, request_id, operation, quantity):
    if not isinstance(request_id, str) or not re.fullmatch(r"[A-Za-z0-9._:-]{1,128}", request_id):
        raise ValueError("Expected a 1–128 character ASCII request ID")
    if operation not in ("reserve", "release") or type(quantity) is not int or not 0 <= quantity <= MAX_INT:
        raise ValueError("Invalid operation or quantity")
    with closing(connect(path, "rw")) as db, write_transaction(db):
        if version(db) != CURRENT:
            raise ValueError("Migrate this database before submitting requests")
        result = db.execute("SELECT request_id,operation,quantity,outcome,available,reserved FROM requests WHERE request_id=?",
                            (request_id,)).fetchone()
        if result is not None:
            if (result["operation"], result["quantity"]) != (operation, quantity):
                raise ValueError("Request ID already binds a different operation or quantity")
            return dict(result)
        outcome, available, reserved = checked_step(engine, state(db), operation, quantity)
        db.execute("UPDATE pool SET reserved=? WHERE id=1", (reserved,))
        db.execute("INSERT INTO requests(request_id,operation,quantity,outcome,available,reserved) VALUES(?,?,?,?,?,?)",
                   (request_id, operation, quantity, outcome, available, reserved))
        return dict(request_id=request_id, operation=operation, quantity=quantity, outcome=outcome,
                    available=available, reserved=reserved)


def inspect(path):
    with closing(connect(path, "ro")) as db:
        db.execute("BEGIN")
        return {"schema_version": version(db), **state(db),
                "requests": db.execute("SELECT COUNT(*) FROM requests").fetchone()[0]}


def copy_database(source, destination):
    with closing(connect(source, "ro")) as src, new_database(destination) as dest:
        version(src)
        src.backup(dest)
        dest.row_factory = sqlite3.Row
        version(dest)
        if [row[0] for row in dest.execute("PRAGMA integrity_check")] != ["ok"]:
            raise ValueError("SQLite backup integrity check failed")
        state(dest)


def migrate(path, backup):
    with closing(connect(path, "rw")) as db, write_transaction(db):
        if version(db) == CURRENT:
            return {"changed": False, "schema_version": CURRENT}
        before = state(db)
        # A separate read connection sees the exact committed v1 database while
        # this connection holds the writer reservation. Keep the copy on failure.
        copy_database(path, backup)
        db.execute("ALTER TABLE pool RENAME TO pool_v1")
        db.execute(POOL_V2)
        db.execute("INSERT INTO pool(id,capacity,reserved) SELECT id,capacity,reserved FROM pool_v1")
        if state(db) != before:
            raise ValueError("State observations changed during schema migration")
        db.execute("DROP TABLE pool_v1")
        db.execute(f"PRAGMA user_version={CURRENT}")
        return {"changed": True, "schema_version": CURRENT}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("init", "apply", "show", "backup", "restore", "migrate"):
        cmd = sub.add_parser(name)
        cmd.add_argument("--db", required=True, type=Path)
        if name == "init":
            cmd.add_argument("--capacity", required=True, type=natural)
        elif name == "apply":
            cmd.add_argument("--engine", required=True, type=Path)
            cmd.add_argument("--id", required=True)
            cmd.add_argument("operation", choices=("reserve", "release"))
            cmd.add_argument("quantity", type=natural)
        elif name == "backup":
            cmd.add_argument("--out", required=True, type=Path)
        elif name in ("restore", "migrate"):
            cmd.add_argument("--backup", required=True, type=Path)
    args = parser.parse_args()
    try:
        if args.command == "init":
            initialize(args.db, args.capacity)
            value = inspect(args.db)
        elif args.command == "apply":
            value = apply_request(args.db, args.engine, args.id, args.operation, args.quantity)
        elif args.command == "show":
            value = inspect(args.db)
        elif args.command == "migrate":
            value = migrate(args.db, args.backup)
        elif args.command == "restore":
            copy_database(args.backup, args.db)
            value = inspect(args.db)
        else:
            copy_database(args.db, args.out)
            value = inspect(args.out)
        print(json.dumps(value))
    except (OSError, sqlite3.Error, ValueError, subprocess.SubprocessError) as exc:
        parser.exit(2, f"Inventory operation failed: {exc}\n")


if __name__ == "__main__":
    main()
