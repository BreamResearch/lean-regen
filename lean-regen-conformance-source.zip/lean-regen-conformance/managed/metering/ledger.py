#!/usr/bin/env python3
"""Local cost accounting only. No billing, credentials, external jobs or spend authority."""
import argparse
import json
import os
import re
import sqlite3
import sys
import time
from contextlib import contextmanager
from pathlib import Path

MAX = 10**12
COSTS = ("compute", "model", "storage", "support")
OUTCOMES = ("succeeded", "failed", "timeout", "cancelled")


def amount(value, minimum=0):
    if type(value) is not int or not minimum <= value <= MAX:
        raise ValueError(f"Expected an integer between {minimum} and {MAX}")
    return value


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_.-]{0,79}", value):
        raise ValueError("Invalid tenant or job identifier")
    return value


class Ledger:
    def __init__(self, path):
        self.path = Path(path)
        fd = os.open(self.path, os.O_CREAT | os.O_RDWR, 0o600)
        os.close(fd)
        with self.transaction() as con:
            con.executescript("""
              CREATE TABLE IF NOT EXISTS tenants(
                tenant TEXT PRIMARY KEY, currency TEXT NOT NULL, cap INTEGER NOT NULL,
                blocked INTEGER NOT NULL DEFAULT 0);
              CREATE TABLE IF NOT EXISTS attempts(
                tenant TEXT NOT NULL REFERENCES tenants(tenant), job TEXT NOT NULL, attempt INTEGER NOT NULL,
                reserved INTEGER NOT NULL, created INTEGER NOT NULL, outcome TEXT, settled INTEGER,
                compute INTEGER, model INTEGER, storage INTEGER, support INTEGER, support_seconds INTEGER,
                PRIMARY KEY(tenant,job,attempt));
            """)

    @contextmanager
    def transaction(self):
        con = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        con.row_factory = sqlite3.Row
        try:
            con.execute("PRAGMA foreign_keys=ON")
            con.execute("BEGIN IMMEDIATE")
            yield con
            con.commit()
        finally:
            con.close()

    def open_tenant(self, tenant, currency, cap=0):
        identifier(tenant)
        amount(cap)
        if not re.fullmatch(r"[A-Z]{3}", currency):
            raise ValueError("Supply a three-letter currency code")
        with self.transaction() as con:
            old = con.execute("SELECT currency,cap FROM tenants WHERE tenant=?", (tenant,)).fetchone()
            if old and tuple(old) != (currency, cap):
                raise ValueError("Existing budget or currency differs")
            if not old:
                con.execute("INSERT INTO tenants(tenant,currency,cap) VALUES (?,?,?)", (tenant,currency,cap))
            return {"tenant": tenant, "currency": currency, "cap": cap, "created": not bool(old)}

    @staticmethod
    def totals(con, tenant):
        row = con.execute("SELECT * FROM tenants WHERE tenant=?", (tenant,)).fetchone()
        if row is None:
            raise ValueError("Unknown tenant")
        result = dict(row)
        held, spent, seconds = 0, 0, 0
        breakdown = {outcome: 0 for outcome in OUTCOMES}
        categories = {name: 0 for name in COSTS}
        retries = 0
        for attempt in con.execute("SELECT * FROM attempts WHERE tenant=?", (tenant,)):
            if attempt["outcome"] is None:
                held += attempt["reserved"]
            else:
                cost = sum(attempt[k] for k in COSTS)
                spent += cost
                for name in COSTS:
                    categories[name] += attempt[name]
                breakdown[attempt["outcome"]] += cost
                seconds += attempt["support_seconds"]
                if attempt["attempt"] > 1:
                    retries += cost
        result.update(held=held, spent=spent, remaining=row["cap"]-spent-held, by_outcome=breakdown,
                      retry_cost=retries, by_category=categories, support_seconds=seconds, blocked=bool(row["blocked"]))
        return result

    def reserve(self, tenant, job, attempt, maximum):
        key = identifier(tenant), identifier(job), amount(attempt, 1)
        amount(maximum, 1)
        with self.transaction() as con:
            old = con.execute("SELECT reserved,outcome FROM attempts WHERE tenant=? AND job=? AND attempt=?", key).fetchone()
            if old:
                if maximum != old["reserved"]:
                    raise ValueError("Conflicting replay of a reservation")
                return {"new_reservation": False, "reserved": maximum, "outcome": old["outcome"]}
            totals = self.totals(con, tenant)
            if totals["blocked"] or maximum > totals["remaining"]:
                raise ValueError("Budget unavailable or tenant frozen")
            if attempt > 1:
                prior = con.execute("SELECT outcome FROM attempts WHERE tenant=? AND job=? AND attempt=?",
                                    (tenant,job,attempt-1)).fetchone()
                if not prior or prior["outcome"] not in {"failed", "timeout", "cancelled"}:
                    raise ValueError("Retry requires a settled unsuccessful previous attempt")
            con.execute("INSERT INTO attempts(tenant,job,attempt,reserved,created) VALUES (?,?,?,?,?)",
                        (*key, maximum, int(time.time())))
            return {"new_reservation": True, "reserved": maximum, "outcome": None}

    def settle(self, tenant, job, attempt, outcome, costs, support_seconds):
        key = identifier(tenant), identifier(job), amount(attempt, 1)
        if outcome not in OUTCOMES or set(costs) != set(COSTS):
            raise ValueError("Supply outcome and all four measured cost categories")
        amounts = tuple(amount(costs[k]) for k in COSTS)
        total = amount(sum(amounts))
        amount(support_seconds)
        with self.transaction() as con:
            old = con.execute("SELECT * FROM attempts WHERE tenant=? AND job=? AND attempt=?", key).fetchone()
            if not old:
                raise ValueError("No reservation for this attempt")
            if old["outcome"] is not None:
                if (old["outcome"] != outcome or tuple(old[k] for k in COSTS) != amounts
                        or old["support_seconds"] != support_seconds):
                    raise ValueError("Conflicting replay of a settlement")
            else:
                con.execute("""UPDATE attempts SET outcome=?,settled=?,compute=?,model=?,storage=?,support=?,
                    support_seconds=? WHERE tenant=? AND job=? AND attempt=?""",
                    (outcome, int(time.time()), *amounts, support_seconds, *key))
                if total > old["reserved"]:
                    con.execute("UPDATE tenants SET blocked=1 WHERE tenant=?", (tenant,))
            return {"new_settlement": old["outcome"] is None, "total": total, "outcome": outcome,
                    "over_reservation": total > old["reserved"]}

    def export(self, tenant):
        identifier(tenant)
        with self.transaction() as con:
            totals = self.totals(con, tenant)
            attempts = [dict(x) for x in con.execute("SELECT * FROM attempts WHERE tenant=? ORDER BY job,attempt", (tenant,))]
            return {"summary": totals, "attempts": attempts}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--db", type=Path, required=True)
    sub = p.add_subparsers(dest="action", required=True)
    for name in ("open", "reserve", "settle", "export"):
        cmd = sub.add_parser(name)
        cmd.add_argument("tenant")
        if name == "open":
            cmd.add_argument("--currency", required=True)
            cmd.add_argument("--cap", type=int, default=0)
        if name in ("reserve", "settle"):
            cmd.add_argument("job")
            cmd.add_argument("attempt", type=int)
        if name == "reserve":
            cmd.add_argument("--maximum", type=int, required=True)
        if name == "settle":
            cmd.add_argument("--outcome", choices=OUTCOMES, required=True)
            for metric in (*COSTS, "support-seconds"):
                cmd.add_argument("--" + metric, required=True, type=int)
    a = p.parse_args()
    try:
        book = Ledger(a.db)
        if a.action == "open":
            output = book.open_tenant(a.tenant, a.currency, a.cap)
        elif a.action == "reserve":
            output = book.reserve(a.tenant, a.job, a.attempt, a.maximum)
        elif a.action == "settle":
            output = book.settle(a.tenant, a.job, a.attempt, a.outcome, {k:getattr(a,k) for k in COSTS}, a.support_seconds)
        else:
            output = book.export(a.tenant)
        print(json.dumps(output, indent=2))
    except (ValueError, sqlite3.Error, OSError) as exc:
        print(json.dumps({"status":"blocked","reason":str(exc)}), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
