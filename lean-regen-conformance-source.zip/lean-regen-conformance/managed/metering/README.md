# Local prebilling ledger

Use `python3 managed/metering/ledger.py --help` for the local CLI. It accepts one SQLite database for a budget period. Keep it in an operator-only directory outside Git. Tenant and job IDs are labels in a trusted local process. No accounts, credentials, provider calls or payments are created.

An operator first opens a tenant's fixed budget and three-letter currency with `open`. The default cap is zero. Values are integer minor units in that currency, each in the inclusive range 0–1,000,000,000,000. Zero-cost settlement is permitted. Reserve a positive maximum for a specific job and attempt before recording its work. Funds held by concurrent attempts count toward the same cap. A replay with the same tenant, job, attempt and maximum returns the prior result. Conflicting replays and adverse budget checks return exit 2.

Settle the attempt once, providing the measured compute, model, storage and support costs, support seconds and outcome. Unused reservation capacity becomes available. Failure, cancellation and timeouts retain their actual costs. A retry uses the next integer attempt after the previous unsuccessful settlement and obtains its own reservation. Outstanding reservations persist until the operator reconciles them with actual work. The ledger retains a provider overrun as measured cost and freezes new reservations for that tenant. Open another period only under a separate real allocation.

`export` includes all attempts, current reservations, remaining budget, totals by outcome and cost category, retry costs and support time. Retry costs overlap the relevant outcome totals. Source measurements, currency rounding and labor rates belong to the operator. This prototype trusts the local database writer. Production requires authenticated tenant isolation, protected append/audit storage, measured usage from real providers, external hard spend limits and an idempotent billing provider integration. A local reservation alone cannot authorize external work.

Run `python3 -m unittest discover -s managed/metering -v` for synthetic offline tests.
