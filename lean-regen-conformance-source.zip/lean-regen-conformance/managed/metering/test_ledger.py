import json
import subprocess
import sys
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from ledger import COSTS, MAX, Ledger


def costs(**values):
    return {key: values.get(key, 0) for key in COSTS}


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Path(self.tmp.name) / "usage.sqlite"
        self.book = Ledger(self.db)
        self.book.open_tenant("pilot", "JPY", 100)

    def test_zero_cap_and_immutable_period(self):
        self.book.open_tenant("free", "JPY")
        with self.assertRaisesRegex(ValueError, "unavailable"):
            self.book.reserve("free", "j", 1, 1)
        self.assertFalse(self.book.open_tenant("pilot", "JPY", 100)["created"])
        with self.assertRaisesRegex(ValueError, "differs"):
            self.book.open_tenant("pilot", "USD", 110)

    def test_concurrent_reservations_obey_total_cap_across_jobs(self):
        def reserve(i):
            try:
                return Ledger(self.db).reserve("pilot", str(i), 1, 60)["new_reservation"]
            except ValueError:
                return False
        with ThreadPoolExecutor(max_workers=2) as pool:
            self.assertEqual(sorted(pool.map(reserve, range(2))), [False, True])
        summary = self.book.export("pilot")["summary"]
        self.assertEqual((summary["held"],summary["remaining"]),(60,40))

    def test_failure_and_retry_include_support_and_replay_after_restart(self):
        self.book.reserve("pilot", "job", 1, 60)
        self.assertFalse(Ledger(self.db).reserve("pilot","job",1,60)["new_reservation"])
        with self.assertRaisesRegex(ValueError, "replay"):
            self.book.reserve("pilot","job",1,61)
        with self.assertRaisesRegex(ValueError, "Retry"):
            self.book.reserve("pilot","job",2,10)
        items = costs(compute=12, model=5, storage=1, support=2)
        self.book.settle("pilot","job",1,"failed",items,30)
        self.assertFalse(self.book.settle("pilot","job",1,"failed",items,30)["new_settlement"])
        with self.assertRaisesRegex(ValueError,"replay"):
            self.book.settle("pilot","job",1,"failed",items,31)
        self.book.reserve("pilot","job",2,80)
        self.book.settle("pilot","job",2,"succeeded",costs(model=7,support=3),4)
        data = Ledger(self.db).export("pilot")
        self.assertEqual([x["outcome"] for x in data["attempts"]], ["failed", "succeeded"])
        summary = data["summary"]
        self.assertEqual([summary[k] for k in ("spent","held","remaining","retry_cost","support_seconds")],
                         [30,0,70,10,34])
        self.assertEqual(summary["by_outcome"]["failed"],20)
        self.assertEqual(summary["by_category"], costs(compute=12, model=12, storage=1, support=5))
        with self.assertRaisesRegex(ValueError, "Retry"):
            self.book.reserve("pilot","job",3,1)

    def test_provider_overrun_is_recorded_and_freezes_only_that_tenant(self):
        self.book.reserve("pilot","a",1,50)
        self.book.reserve("pilot","b",1,20)
        self.book.settle("pilot","a",1,"timeout",costs(compute=105),0)
        with self.assertRaisesRegex(ValueError,"frozen"):
            self.book.reserve("pilot","c",1,1)
        self.book.settle("pilot","b",1,"cancelled",costs(),0)
        self.assertEqual(self.book.export("pilot")["summary"]["remaining"], -5)
        self.book.open_tenant("another","USD",8)
        self.assertTrue(self.book.reserve("another","a",1,8)["new_reservation"])
        self.assertEqual(len(self.book.export("another")["attempts"]), 1)

    def test_non_integer_negative_and_oversized_values_fail_without_mutation(self):
        for bad in [False, 1.5, -1, MAX+1]:
            with self.assertRaises(ValueError):
                self.book.reserve("pilot","j",1,bad)
        self.book.reserve("pilot","j",1,2)
        with self.assertRaises(ValueError):
            self.book.settle("pilot","j",1,"failed",costs(compute=MAX,storage=1),0)
        self.assertEqual(self.book.export("pilot")["summary"]["held"],2)

    def test_cli_reports_blocked_attempt_without_side_effects(self):
        argv = [sys.executable, str(Path(__file__).with_name("ledger.py")), "--db", str(self.db),
                "reserve", "pilot", "j", "1", "--maximum", "101"]
        result = subprocess.run(argv, capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(json.loads(result.stderr)["status"], "blocked")
        self.assertEqual(self.book.export("pilot")["attempts"], [])


if __name__ == "__main__":
    unittest.main()
