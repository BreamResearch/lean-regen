import io
import re
import smtplib
import sqlite3
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import urlencode
from unittest.mock import MagicMock, patch

from app import DAY, Waitlist, application, smtp_sender


class WaitlistTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.now = 100000
        self.cfg = dict(operator="Test fixture", contact="support@example.test", consent_version="test-v1",
                        privacy_url="https://example.test/privacy", origin="https://example.test", retention_days=7,
                        database=str(Path(tmp.name) / "synthetic.sqlite"), sender="verify@example.test",
                        smtp_host="smtp.example.test", smtp_port=465)
        self.store = Waitlist(self.cfg, b"x" * 32, lambda: self.now)
        self.web = application(self.store)
        self.fields = dict(email="case@EXAMPLE.test", consent="test-v1")

    def request(self, path, fields=None, origin=None, web=None):
        body = urlencode(fields or {}).encode()
        env = dict(PATH_INFO=path, REQUEST_METHOD="GET" if fields is None else "POST",
                   REMOTE_ADDR="127.0.0.1", HTTP_ORIGIN=origin or self.cfg["origin"],
                   CONTENT_TYPE="application/x-www-form-urlencoded", CONTENT_LENGTH=str(len(body)))
        env["wsgi.input"] = io.BytesIO(body)
        response = {}
        def start(status, headers):
            response.update(code=int(status[:3]), headers=dict(headers))
        data = b"".join((web or self.web)(env, start)).decode()
        return response["code"], data

    def get_codes(self):
        messages = []
        self.assertEqual(self.store.deliver_one(messages.append), "sent")
        self.assertEqual(len(messages), 1)
        msg = messages[0]
        return re.findall(r"コード ([0-9a-f]{32})", msg.get_content())

    def test_consent_is_durable_and_double_submission_deduplicates(self):
        with ThreadPoolExecutor(max_workers=2) as pool:
            statuses = list(pool.map(lambda _: self.request("/signup", self.fields)[0], range(2)))
        self.assertEqual(statuses, [202, 202])
        with sqlite3.connect(self.store.db) as con:
            stored = con.execute("SELECT email, version, marketing, confirmed, privacy_url FROM entries").fetchall()
        self.assertEqual(stored, [("case@example.test", "test-v1", 0, None, self.cfg["privacy_url"])])
        confirm, delete = self.get_codes()
        self.assertEqual(self.store.deliver_one(self.fail), "idle")
        reopened = Waitlist(self.cfg, b"x"*32, lambda: self.now)
        self.web = application(reopened)
        self.assertEqual(self.request("/confirm", {"code": delete})[0], 400)
        self.assertEqual(self.request("/confirm", {"code": confirm})[0], 200)
        self.assertEqual(self.request("/confirm", {"code": confirm})[0], 400)
        self.assertEqual(self.request("/delete", {"code": confirm})[0], 400)
        self.assertEqual(self.request("/delete", {"code": delete})[0], 200)
        self.assertEqual(self.request("/delete", {"code": delete})[0], 400)
        with sqlite3.connect(self.store.db) as con:
            self.assertEqual(con.execute("SELECT COUNT(*) FROM entries").fetchone(), (0,))

    def test_marketing_optout_preserves_confirmed_pilot_registration(self):
        self.assertEqual(self.request("/signup", dict(self.fields, marketing="yes"))[0], 202)
        confirm, delete = self.get_codes()
        self.assertEqual(self.request("/confirm", {"code": confirm})[0], 200)
        for _ in range(2):
            self.assertEqual(self.request("/optout", {"code": delete})[0], 200)
        with sqlite3.connect(self.store.db) as con:
            self.assertEqual(con.execute("SELECT marketing,confirmed,opted_out FROM entries").fetchone(),
                             (0, self.now, self.now))

    def test_failed_delivery_has_bounded_durable_retry(self):
        self.request("/signup", self.fields)
        ids = set()
        for _ in range(4):
            def fail(msg):
                ids.add(msg["Message-ID"])
                raise smtplib.SMTPServerDisconnected()
            self.assertEqual(self.store.deliver_one(fail), "failed")
            self.assertEqual(self.store.deliver_one(self.fail), "idle")
            self.now += 3600
        self.assertEqual(len(ids), 1)
        self.assertEqual(self.store.deliver_one(self.fail), "idle")
        self.now += DAY
        self.assertEqual(self.store.deliver_one(self.fail), "idle")
        with sqlite3.connect(self.store.db) as con:
            self.assertEqual(con.execute("SELECT count(*) FROM entries").fetchone(), (0,))
            self.assertEqual(con.execute("SELECT count(*) FROM outbox").fetchone(), (0,))

    def test_expired_confirmed_contact_and_replayed_codes_are_purged(self):
        self.request("/signup", self.fields)
        confirm, delete = self.get_codes()
        self.request("/confirm", {"code": confirm})
        self.now += 7 * DAY
        self.assertEqual(self.request("/delete", {"code": delete})[0], 400)
        with sqlite3.connect(self.store.db) as con:
            self.assertEqual(con.execute("SELECT count(*) FROM entries").fetchone(), (0,))

    def test_disabled_origin_consent_validation_and_rate_limit(self):
        with self.assertRaisesRegex(ValueError, "SMTP"):
            Waitlist(dict(self.cfg, smtp_host=None), b"x"*32)
        self.assertNotIn("<form", self.request("/", web=application())[1])
        self.assertEqual(self.request("/signup", self.fields, web=application())[0], 404)
        self.assertEqual(self.request("/signup", self.fields, origin="https://other.test")[0], 403)
        for fields in [dict(self.fields, consent="old"), dict(self.fields, email="a@invalid"),
                       dict(self.fields, email="a@a.test\nb@b.test"), dict(self.fields, extra="x")]:
            self.assertEqual(self.request("/signup", fields)[0], 400)
        self.assertEqual(self.store.deliver_one(self.fail), "idle")
        for _ in range(16):
            status, _ = self.request("/signup", self.fields)
        self.assertEqual(status, 429)

    def test_global_mail_cap_does_not_reveal_registered_addresses(self):
        for i in range(50):
            fields = dict(self.fields, email=f"case{i}@example.test")
            self.assertEqual(self.store.submit("signup", fields, f"peer-{i}")[0], 202)
        for address in ["case0@example.test", "unknown@example.test"]:
            self.assertEqual(self.store.submit("signup", dict(self.fields, email=address), "last")[0], 429)

    def test_successful_retry_sends_same_message_id_and_removes_queue_item(self):
        self.request("/signup", self.fields)
        messages = []
        def fail(msg):
            messages.append(msg)
            raise smtplib.SMTPServerDisconnected()
        self.assertEqual(self.store.deliver_one(fail), "failed")
        self.now += 3600
        self.assertEqual(self.store.deliver_one(messages.append), "sent")
        self.assertEqual(messages[0]["Message-ID"], messages[1]["Message-ID"])
        self.assertEqual(messages[0].get_content(), messages[1].get_content())
        self.assertEqual(self.store.deliver_one(self.fail), "idle")

    def test_storage_error_has_retryable_response_and_no_success_claim(self):
        with patch.object(self.store, "submit", side_effect=sqlite3.OperationalError()):
            self.assertEqual(self.request("/signup", self.fields)[0], 503)

    def test_smtp_adapter_uses_verified_tls_and_explicit_configuration(self):
        self.request("/signup", self.fields)
        with patch.dict("os.environ", {"LEAN_REGEN_SMTP_USER":"fixture", "LEAN_REGEN_SMTP_PASSWORD":"fixture"}):
            send = smtp_sender(dict(self.cfg, smtp_host="smtp.example.test", smtp_port=465))
        client = MagicMock()
        with patch("app.smtplib.SMTP_SSL", return_value=client) as connect:
            self.assertEqual(self.store.deliver_one(send), "sent")
        self.assertTrue(connect.call_args.kwargs["context"].check_hostname)
        session = client.__enter__.return_value
        session.login.assert_called_once_with("fixture", "fixture")
        self.assertEqual(session.send_message.call_args.args[0]["To"], "case@example.test")


if __name__ == "__main__":
    unittest.main()
