# Optional managed-operation waitlist

The public CLI and OSS showcase operate independently of this service. The local WSGI entry point shows a preparation notice by default. The implementation stores consent in SQLite and sends confirmation and deletion codes through a separate TLS SMTP worker. Confirmation records interest in a pilot. It grants no paid account or service entitlement.

## Local checks

Use Python 3.11+ with a supported OpenSSL build. From the repository root run:

```sh
python3 -m unittest discover -s managed/waitlist -v
python3 managed/waitlist/app.py serve
```

For an end-to-end local transport check, run `python3 managed/waitlist/smoke_loopback.py` with OpenSSL 3 on PATH. It creates an ephemeral localhost certificate, accepts one message at a synthetic SMTP sink and deletes the synthetic contact through the HTTP endpoint. It connects only to loopback.

The second command binds the disabled page to loopback port 8733. The tests use synthetic contacts, temporary databases and a test mail transport. They exercise confirmed consent, opt-out with the waitlist entry retained, expiry, erasure, replay, concurrent duplicate submissions, provider failure and rate limits.

## Configured operation

Use an operator-owned commercial host with HTTPS, a private SQLite directory, a monitored reply channel and verified SMTP sender. Configure the external provider's spend cap before enabling mail. This module can be hosted by mounting `application(Waitlist(...))` in a production WSGI server with matching settings. The bundled loopback server is for development.

Provide a private JSON configuration outside the repository with the following values:

| Field | Meaning |
| --- | --- |
| `origin` | Actual HTTPS scheme and host of this service, with optional port and no trailing slash. |
| `operator`, `contact`, `privacy_url` | Responsible operator, monitored email and public HTTPS privacy text for the chosen host. |
| `consent_version`, `retention_days` | Operator-adopted consent version and confirmed-contact retention period, 1–365 days. |
| `database` | Absolute path in an owner-only directory. Protect the host and apply the same expiry/deletion policy to backups. |
| `smtp_host`, `smtp_port`, `sender` | Authorized SMTP server supporting implicit TLS, port and verified From address. |

Inject `LEAN_REGEN_WAITLIST_KEY` (at least 32 cryptographically random bytes encoded as hex) through the host's secret manager. Give `LEAN_REGEN_SMTP_USER` and `LEAN_REGEN_SMTP_PASSWORD` only to the delivery worker. Preserve the key across restarts so queued claims and rate limits work. Keep the TLS edge and access logs free of addresses and codes. Pass the genuine client peer in WSGI `REMOTE_ADDR`; when the reverse proxy supplies only its own address, clients share a limit.

Start the configured HTTP service with the explicit config path, then schedule `python3 managed/waitlist/app.py deliver --config /path/to/private-config.json` once per minute under the responsible operator. The worker processes up to ten queued emails per invocation and prunes expired entries even on idle runs. A host interruption delays pruning until the first subsequent form submission or worker run.

The form requires an explicit current consent version. Marketing consent is optional and initially clear. Only the confirmed entries with separate affirmative marketing consent can be selected for any future marketing use. Records unconfirmed after 24 hours expire. Confirmation and deletion use different codes, carried in the email body and submitted in POST bodies. Deleting the record removes its consent and queued work. Removing marketing consent preserves the pilot request. Users who lose the email can contact the operator for identity-checked assistance.

The service limits requests to 15 per peer per hour and new addresses to 50 per UTC day per database. It hashes temporary peer identifiers. An SMTP failure schedules up to four attempts, preserving the message ID and the same codes. A dropped SMTP acknowledgment can produce duplicate delivery. One already in-flight email can arrive after deletion. Backlog and worker failures need monitoring; this implementation logs delivery counts. DNS, TLS, operator terms, backup retention, actual provider delivery, provider rate limits and the public URL require live validation before the OSS showcase enables an interest link.
