#!/usr/bin/env python3
"""Exercise actual HTTP, SQLite and TLS SMTP on loopback using one synthetic mailbox."""
import hashlib
import io
import json
import os
import re
import socketserver
import sqlite3
import sys
import ssl
import subprocess
import tempfile
import threading
from contextlib import ExitStack
from datetime import datetime, timezone
from email import policy
from email.parser import BytesParser
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from wsgiref.simple_server import make_server

from app import QuietHandler, Waitlist, application, smtp_sender


class MailSink(socketserver.StreamRequestHandler):
    def handle(self):
        self.wfile.write(b"220 localhost synthetic test sink\r\n")
        while line := self.rfile.readline(4096):
            command = line.split()[0].upper()
            if command == b"EHLO":
                self.wfile.write(b"250-localhost\r\n250 AUTH PLAIN\r\n")
            elif command == b"AUTH":
                self.wfile.write(b"235 authenticated synthetic account\r\n")
            elif command == b"DATA":
                self.wfile.write(b"354 data\r\n")
                data = io.BytesIO()
                while payload := self.rfile.readline(4096):
                    if payload == b".\r\n":
                        break
                    data.write(payload)
                self.server.messages.append(BytesParser(policy=policy.default).parsebytes(data.getvalue()))
                self.wfile.write(b"250 accepted locally\r\n")
            elif command == b"QUIT":
                self.wfile.write(b"221 closing\r\n")
                break
            elif command in {b"MAIL", b"RCPT"}:
                self.wfile.write(b"250 ok\r\n")
            else:
                self.wfile.write(b"502 unsupported command\r\n")


def start(server, stack):
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    stack.callback(thread.join, 5)
    stack.callback(server.shutdown)


def main():
    with tempfile.TemporaryDirectory() as tmp, ExitStack() as stack:
        cert, key = Path(tmp)/"cert.pem", Path(tmp)/"key.pem"
        subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1",
                        "-subj", "/CN=localhost", "-addext", "subjectAltName=DNS:localhost",
                        "-keyout", str(key), "-out", str(cert)], check=True, capture_output=True)
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(cert, key)
        sink = stack.enter_context(socketserver.TCPServer(("127.0.0.1", 0), MailSink))
        sink.socket = ctx.wrap_socket(sink.socket, server_side=True)
        sink.messages = []
        start(sink, stack)
        os.environ.update(SSL_CERT_FILE=str(cert), LEAN_REGEN_SMTP_USER="synthetic",
                          LEAN_REGEN_SMTP_PASSWORD="synthetic")
        cfg = dict(operator="Synthetic operator", contact="test@example.test", consent_version="synthetic-v1",
                   privacy_url="https://example.test/privacy", origin="https://example.test", retention_days=1,
                   database=str(Path(tmp)/"consent.sqlite"), sender="test@example.test",
                   smtp_host="localhost", smtp_port=sink.server_address[1])
        store = Waitlist(cfg, os.urandom(32))
        http = stack.enter_context(make_server("127.0.0.1", 0, application(store), handler_class=QuietHandler))
        start(http, stack)
        base = f"http://127.0.0.1:{http.server_port}"

        def post(path, fields, expected):
            query = Request(base + "/" + path, data=urlencode(fields).encode(), headers={"Origin": cfg["origin"]})
            with urlopen(query, timeout=5) as response:
                if response.status != expected:
                    raise ValueError("Unexpected HTTP status for " + path)

        signup = {"email":"synthetic@example.test", "consent":"synthetic-v1", "marketing":"yes"}
        post("signup", signup, 202)
        post("signup", signup, 202)
        transport = smtp_sender(cfg)
        def deliver(message):
            try:
                transport(message)
            except Exception as exc:
                raise RuntimeError("Loopback SMTP failure") from exc
        if store.deliver_one(deliver) != "sent" or len(sink.messages) != 1:
            raise ValueError("Expected a single local SMTP delivery")
        confirm, delete = re.findall(r"コード ([0-9a-f]{32})", sink.messages[0].get_content())
        post("confirm", {"code":confirm}, 200)
        post("optout", {"code":delete}, 200)
        post("delete", {"code":delete}, 200)
        with store.tx() as con:
            if con.execute("SELECT count(*) FROM entries").fetchone()[0]:
                raise ValueError("Synthetic address survived deletion")
        print(json.dumps({"scope": "loopback_http_sqlite_tls_smtp", "consent_submits": 2,
                          "local_messages": 1, "confirmed": True, "opted_out": True, "erased": True,
                          "external_delivery": False, "recorded_utc": datetime.now(timezone.utc).isoformat(),
                          "app_sha256": hashlib.sha256(Path(__file__).with_name("app.py").read_bytes()).hexdigest(),
                          "python": sys.version.split()[0], "sqlite": sqlite3.sqlite_version, "tls": ssl.OPENSSL_VERSION}))


if __name__ == "__main__":
    main()
