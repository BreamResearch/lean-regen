#!/usr/bin/env python3
"""Optional managed-operation waitlist. Run separately from the public OSS showcase."""
import argparse
import hashlib
import hmac
import html
import json
import os
import re
import secrets
import smtplib
import sqlite3
import ssl
import time
from contextlib import contextmanager
from email.message import EmailMessage
from http import HTTPStatus
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
from wsgiref.simple_server import WSGIRequestHandler, make_server

CONSENT = "運用パイロットの参加希望の受付・確認・連絡にメールアドレスを使用することに同意します。"
MARKETING = "更新情報の配信も希望します。"
ADDRESS = re.compile(r"[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9.-]+")
HOUR = 3600
DAY = 24 * HOUR


def email_address(value):
    if not isinstance(value, str) or len(value) > 254 or not ADDRESS.fullmatch(value):
        raise ValueError("有効なメールアドレスを入力してください。")
    local, domain = value.rsplit("@", 1)
    labels = domain.split(".")
    if (len(local) > 64 or local.startswith(".") or local.endswith(".") or ".." in local
            or len(labels) < 2 or any(not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?", s)
                                     for s in labels)):
        raise ValueError("有効なメールアドレスを入力してください。")
    return local + "@" + domain.lower()


def smtp_endpoint(config):
    host, port = config.get("smtp_host"), config.get("smtp_port")
    if not isinstance(host, str) or not host.strip() or type(port) is not int or not 1 <= port <= 65535:
        raise ValueError("Missing SMTP host or port")
    email_address(config.get("sender"))
    return host, port


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


class Waitlist:
    def __init__(self, config, key, clock=time.time):
        self.cfg, self.key, self.clock = config, key, clock
        for field in ("operator", "contact", "privacy_url", "origin", "consent_version", "database"):
            if not isinstance(config.get(field), str) or not config[field].strip():
                raise ValueError("Missing configuration: " + field)
        for name in ("origin", "privacy_url"):
            url = urlsplit(config[name])
            if (url.scheme != "https" or not url.hostname or url.username or url.password
                    or url.query or url.fragment or (name == "origin" and url.path)):
                raise ValueError("Expected HTTPS URL: " + name)
        email_address(config["contact"])
        smtp_endpoint(config)
        if not (isinstance(config.get("retention_days"), int) and 1 <= config["retention_days"] <= 365):
            raise ValueError("retention_days must be 1–365")
        if len(key) < 32:
            raise ValueError("A persistent secret of at least 32 bytes is required")
        self.db = Path(config["database"])
        if not self.db.is_absolute():
            raise ValueError("Use an absolute database path in a private directory")
        fd = os.open(self.db, os.O_CREAT | os.O_RDWR, 0o600)
        os.close(fd)
        with self.tx() as con:
            con.executescript("""
                CREATE TABLE IF NOT EXISTS entries(
                    email TEXT PRIMARY KEY, nonce TEXT UNIQUE NOT NULL, confirm_hash TEXT,
                    delete_hash TEXT UNIQUE NOT NULL, created INTEGER NOT NULL, confirmed INTEGER,
                    expires INTEGER NOT NULL, version TEXT NOT NULL, purpose TEXT NOT NULL,
                    privacy_url TEXT NOT NULL, marketing INTEGER NOT NULL, opted_out INTEGER);
                CREATE UNIQUE INDEX IF NOT EXISTS confirmation ON entries(confirm_hash);
                CREATE TABLE IF NOT EXISTS outbox(
                    nonce TEXT PRIMARY KEY REFERENCES entries(nonce) ON DELETE CASCADE,
                    attempts INTEGER NOT NULL DEFAULT 0, due INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS limits(
                    bucket TEXT PRIMARY KEY, count INTEGER NOT NULL, expires INTEGER NOT NULL);
            """)

    @contextmanager
    def tx(self):
        con = sqlite3.connect(self.db, timeout=5, isolation_level=None)
        con.row_factory = sqlite3.Row
        try:
            con.execute("PRAGMA foreign_keys=ON")
            con.execute("PRAGMA secure_delete=ON")
            con.execute("BEGIN IMMEDIATE")
            yield con
            con.commit()
        finally:
            con.close()

    def code(self, purpose, nonce):
        return hmac.new(self.key, (purpose + ":" + nonce).encode(), hashlib.sha256).hexdigest()[:32]

    @staticmethod
    def prune(con, now):
        con.execute("DELETE FROM entries WHERE expires <= ?", (now,))
        con.execute("DELETE FROM limits WHERE expires <= ?", (now,))

    @staticmethod
    def limit(con, bucket, expires, maximum):
        count = con.execute("SELECT count FROM limits WHERE bucket=?", (bucket,)).fetchone()
        if count and count[0] >= maximum:
            return False
        con.execute("""INSERT INTO limits VALUES (?,1,?) ON CONFLICT(bucket)
                       DO UPDATE SET count=count+1""", (bucket, expires))
        return True

    def submit(self, action, fields, peer):
        now = int(self.clock())
        with self.tx() as con:
            self.prune(con, now)
            hour = now // HOUR
            bucket = self.code("rate", f"{hour}:{peer}")
            if not self.limit(con, bucket, (hour + 1) * HOUR, 15):
                return 429, "少し時間を置いてから再試行してください。"
            if action == "signup":
                try:
                    email = email_address(fields.get("email", "").strip())
                except ValueError as exc:
                    return 400, str(exc)
                if (fields.get("consent") != self.cfg["consent_version"]
                        or fields.get("marketing", "") not in ("", "yes")):
                    return 400, "現在の利用目的をご確認のうえ、同意してください。"
                reply = (202, "新規のお申し込みへ確認コードをメールで送る手続きに入ります。確認後に参加希望を記録します。")
                day = now // DAY
                daily = con.execute("SELECT count FROM limits WHERE bucket=?", (f"new:{day}",)).fetchone()
                if daily and daily[0] >= 50:
                    return 429, "本日の受付上限に達しました。後日再試行してください。"
                if con.execute("SELECT 1 FROM entries WHERE email=?", (email,)).fetchone():
                    return reply
                self.limit(con, f"new:{day}", (day + 1) * DAY, 50)
                nonce = secrets.token_hex(16)
                con.execute("""INSERT INTO entries
                    (email,nonce,confirm_hash,delete_hash,created,expires,version,purpose,privacy_url,marketing)
                    VALUES (?,?,?,?,?,?,?,?,?,?)""", (
                    email, nonce, digest(self.code("confirm", nonce)), digest(self.code("delete", nonce)),
                    now, now + DAY, self.cfg["consent_version"], CONSENT, self.cfg["privacy_url"],
                    int(fields.get("marketing") == "yes")))
                con.execute("INSERT INTO outbox(nonce,due) VALUES (?,?)", (nonce, now))
                return reply
            code = fields.get("code", "").strip()
            if not re.fullmatch(r"[a-f0-9]{32}", code):
                return 400, "コードを確認してください。"
            hashed = digest(code)
            if action == "confirm":
                con.execute("DELETE FROM outbox WHERE nonce=(SELECT nonce FROM entries WHERE confirm_hash=?)", (hashed,))
                updated = con.execute("""UPDATE entries SET confirmed=?, expires=?, confirm_hash=NULL
                    WHERE confirm_hash=?""", (now, now + self.cfg["retention_days"] * DAY, hashed))
                if updated.rowcount:
                    return 200, "運用パイロットの参加希望を確認しました。"
            elif action == "optout":
                updated = con.execute("UPDATE entries SET marketing=0, opted_out=coalesce(opted_out, ?) WHERE delete_hash=?",
                                      (now, hashed))
                if updated.rowcount:
                    return 200, "更新情報の配信希望を解除しました。"
            elif action == "delete":
                if con.execute("DELETE FROM entries WHERE delete_hash=?", (hashed,)).rowcount:
                    return 200, "参加希望と連絡先を削除しました。"
            return 400, "コードが無効か、使用済みまたは期限切れです。"

    def deliver_one(self, send):
        now = int(self.clock())
        with self.tx() as con:
            self.prune(con, now)
            row = con.execute("""SELECT e.email, e.nonce, e.marketing, o.attempts
                FROM outbox o JOIN entries e USING(nonce) WHERE o.due<=? AND o.attempts<4
                ORDER BY o.due,e.created LIMIT 1""", (now,)).fetchone()
            if row is None:
                return "idle"
            attempt = row["attempts"] + 1
            con.execute("UPDATE outbox SET attempts=?,due=? WHERE nonce=?",
                        (attempt, now + min(3600, 60 * 2**attempt), row["nonce"]))
        try:
            send(self.message(row))
        except (OSError, smtplib.SMTPException):
            return "failed"
        with self.tx() as con:
            con.execute("DELETE FROM outbox WHERE nonce=? AND attempts=?", (row["nonce"], attempt))
        return "sent"

    def message(self, row):
        msg = EmailMessage()
        msg["Subject"] = "Lean Regen 運用パイロット参加希望の確認"
        msg["From"] = email_address(self.cfg["sender"])
        msg["To"] = row["email"]
        msg["Message-ID"] = f"<waitlist.{row['nonce']}@{self.cfg['sender'].split('@')[-1]}>"
        marketing = "希望する" if row["marketing"] else "希望しない"
        msg.set_content(f"{self.cfg['operator']} が運用パイロットの参加希望を受け付けます。\n"
                        f"更新情報の配信希望：{marketing}\n"
                        f"{self.cfg['origin']}/ で確認コードを入力してください（24時間有効）。\n"
                        f"確認コード {self.code('confirm', row['nonce'])}\n"
                        f"配信解除・削除コード {self.code('delete', row['nonce'])}\n"
                        "配信解除・削除コードは保管してください。心当たりのないときは確認せず破棄できます。\n"
                        f"お問い合わせ {self.cfg['contact']}\n")
        return msg


def smtp_sender(config):
    username = os.environ["LEAN_REGEN_SMTP_USER"]
    password = os.environ["LEAN_REGEN_SMTP_PASSWORD"]
    host, port = smtp_endpoint(config)
    if not username or not password:
        raise ValueError("Missing SMTP credentials")

    def send(message):
        with smtplib.SMTP_SSL(host, port, timeout=12, context=ssl.create_default_context()) as client:
            client.login(username, password)
            client.send_message(message)
    return send


def page(service):
    if service is None:
        return "<h1>運用パイロットは準備中です</h1><p>公開ソースとローカル検査は登録なしで利用できます。</p>"
    c = {k: html.escape(str(v), quote=True) for k, v in service.cfg.items()}
    blocks = [f"""<h1>運用パイロットの参加希望</h1>
<p>公開ソースの利用は無料です。参加希望の登録は任意です。</p>
<p>受付主体 {c['operator']} ／ お問い合わせ {c['contact']}<br>
未確認の希望は24時間、確認済みの希望は確認から{c['retention_days']}日保存します。
<a href="{c['privacy_url']}">プライバシーについて</a></p>
<form method="post" action="/signup"><label>メールアドレス <input type="email" name="email" maxlength="254" required></label>
<label><input type="checkbox" name="consent" value="{c['consent_version']}" required>{CONSENT}</label>
<label><input type="checkbox" name="marketing" value="yes">{MARKETING}</label>
<button>確認メールを申し込む</button></form>"""]
    for path, label, kind in [("confirm", "参加希望を確認", "確認"), ("optout", "更新情報の配信を解除", "配信解除・削除"),
                              ("delete", "参加希望と連絡先を削除", "配信解除・削除")]:
        blocks.append(f'<form method="post" action="/{path}"><label>{kind}コード '
                      f'<input name="code" maxlength="32" required autocomplete="off"></label><button>{label}</button></form>')
    return "".join(blocks)


def application(service=None):
    def handle(env, respond):
        path = env["PATH_INFO"]
        if env["REQUEST_METHOD"] == "GET" and path == "/" and not env.get("QUERY_STRING"):
            status, body = 200, page(service)
        elif service is None or path not in {"/signup", "/confirm", "/optout", "/delete"}:
            status, body = 404, "対象のページがありません。"
        elif env["REQUEST_METHOD"] != "POST":
            status, body = 405, "フォームから送信してください。"
        elif env.get("HTTP_ORIGIN") != service.cfg["origin"] or env.get("QUERY_STRING"):
            status, body = 403, "登録ページから送信してください。"
        else:
            try:
                size = int(env.get("CONTENT_LENGTH") or 0)
                if (not 0 < size <= 2048 or env.get("CONTENT_TYPE", "").split(";")[0] !=
                        "application/x-www-form-urlencoded"):
                    raise ValueError()
                data = env["wsgi.input"].read(size)
                if len(data) != size:
                    raise ValueError()
                form = parse_qs(data.decode("utf-8"), keep_blank_values=True, strict_parsing=True, max_num_fields=3)
                allowed = {"email", "consent", "marketing"} if path == "/signup" else {"code"}
                if set(form) - allowed or any(len(v) != 1 for v in form.values()):
                    raise ValueError()
                status, msg = service.submit(path[1:], {k: v[0] for k, v in form.items()}, env.get("REMOTE_ADDR", ""))
            except (ValueError, UnicodeError):
                status, msg = 400, "入力内容を確認してください。"
            except sqlite3.Error:
                status, msg = 503, "受付を完了できませんでした。後で再試行してください。"
            body = f"<p>{html.escape(msg)}</p><a href='/'>参加希望のページに戻る</a>"
        body = ("<!doctype html><html lang='ja'><meta charset='utf-8'>"
                "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                "<title>Lean Regen 運用パイロット</title><style>body{font:1em/1.7 system-ui;max-width:42rem;"
                "margin:2rem auto;padding:0 1rem}form{margin:1.5rem 0}label{display:block;margin:.55em 0}"
                "button,input{font:inherit}</style><main>" + body + "</main></html>").encode()
        respond(f"{status} {HTTPStatus(status).phrase}", [("Content-Type", "text/html; charset=utf-8"),
                ("Content-Length", str(len(body))), ("Cache-Control", "no-store"), ("Referrer-Policy", "no-referrer"),
                ("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'")])
        return [body]
    return handle


class QuietHandler(WSGIRequestHandler):
    def log_request(self, code="-", size="-"):
        pass


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("command", choices=["serve", "deliver"])
    p.add_argument("--config", type=Path)
    p.add_argument("--port", type=int, default=8733)
    args = p.parse_args()
    os.umask(0o077)
    state = None
    if args.config:
        cfg = json.loads(args.config.read_text())
        state = Waitlist(cfg, bytes.fromhex(os.environ["LEAN_REGEN_WAITLIST_KEY"]))
    if args.command == "deliver":
        if state is None:
            p.error("Mail delivery requires an explicit configuration")
        send = smtp_sender(cfg)
        counts = {"sent": 0, "failed": 0}
        for _ in range(10):
            result = state.deliver_one(send)
            if result == "idle":
                break
            counts[result] += 1
        with state.tx() as con:
            counts["exhausted"] = con.execute("SELECT COUNT(*) FROM outbox WHERE attempts>=4").fetchone()[0]
        print(json.dumps(counts))
        return 1 if counts["failed"] or counts["exhausted"] else 0
    with make_server("127.0.0.1", args.port, application(state), handler_class=QuietHandler) as http:
        http.serve_forever()


if __name__ == "__main__":
    raise SystemExit(main())
