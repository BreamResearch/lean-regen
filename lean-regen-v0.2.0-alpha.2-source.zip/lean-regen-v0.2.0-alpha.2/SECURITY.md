# Security and trust boundaries

This source alpha includes a trusted local Lean example. The historical verifier is not an adversarial execution sandbox and must not be offered as a service for arbitrary uploads. Implement the isolated independent-verification milestone before accepting untrusted projects.

Read `docs/PROOF_AND_RUNTIME_SCOPE_JA.md`. Proof soundness, challenge meaning, host isolation, identity, release binding and runtime assumptions are separate obligations. A green CI job or valid signature is not a mathematical proof of all system behavior.

For the public source release, open the **Security** tab in the BreamResearch/lean-regen repository and choose **Report a vulnerability**. The source publisher enables and reads back GitHub private vulnerability reporting before pushing the initial source. This local release candidate was prepared before that channel went live. Public issues are suitable for nonsensitive bug reports.

Operational incidents must preserve evidence, revoke affected capabilities, stop unsafe promotion and select rollback/quarantine according to the standing policy. They must not rewrite a historical report to make the incident disappear.
