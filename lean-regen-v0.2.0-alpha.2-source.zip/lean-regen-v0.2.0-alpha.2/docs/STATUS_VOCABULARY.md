# Status vocabulary

Status is a tuple, not a single green badge. Keep execution, evidence, runtime
availability and public distribution separate. `autonomy/state-machine.json`
defines the future controller's internal states.

| Meaning | Canonical status or interpretation |
|---|---|
| A component has a design, not running infrastructure | `DESIGN_ONLY` |
| Reference model or component actually ran its stated tests | `EXECUTED_PASS`, scoped by its report |
| Historical normal Lean checking path | upstream `CORE_KERNEL_CHECKED`; wrapper display `LOCAL_CORE_KERNEL_CHECKED` is an alias with the same limited meaning |
| Actual independently checked pure-core contract | `INDEPENDENT_CORE_VERIFIED`; never infer it from local checks or model fixtures |
| Future particular runtime correspondence | `SCOPED_RUNTIME_REFINEMENT_VERIFIED`; separate profile required, not currently represented by the core model |
| Honest source alpha publication | `SOURCE_ALPHA`; a distribution category, not a proof status |
| Hosted service not deployed | `NOT_DEPLOYED` |
| Signup not connected | `disabled`; no submission form |

Older design prose may use the descriptive phrase “independently scoped
verification”. For the initial core implementation, serialize it as
`INDEPENDENT_CORE_VERIFIED`. Do not create a mapping that upgrades historical
evidence or widens its scope.

The state model's `PUBLISHED` is the future independently verified artifact
channel. P0 source publication uses its separate source-alpha gate. The draft
runtime policy need not become active to publish the alpha sources.
