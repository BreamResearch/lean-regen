# Lean Regen — 公開導線・登録・Sponsors の仕様

調査日: 2026-11-24。公開名・実 URL・受付主体・決済 provider は未確定。Codex は接続済みの実アカウントを確認して設定し、未設定のものを動いているように見せない。

## 1. 最初の訪問で得られる体験

一番目の導線は **「無料で試す」**、二番目は **「検証結果を見る」**、三番目は GitHub のソースである。メール登録をダウンロードやローカル検証の条件にしない。製品の価値を理解してから、必要な利用者が運用サービスへ進む。

公開ページの推奨構成:

1. 見出し: 「変更のたびに、仕様との一致を確かめて届ける。」
2. 説明: 「業務ルール、Lean の証明、更新履歴を結び付ける公開スターター。対応する範囲を明示し、同じ証拠を手元で再検査できます。」
3. 実例: 固定した業務ルール、正常な実装、意図的に壊した実装、Lean が受理／拒否した実際の記録。
4. 保証範囲: 証明した性質、前提、未検証の境界、対象 version を同じ画面で確認できる。
5. 入手: 無料 download、GitHub、インストール・再検証手順。
6. 運用: private 検証・更新監視・企業利用に興味がある人だけが、外部の登録ページへ進む。

「手動のコードレビューを減らす」「事前に承認された条件内では自動受入れできる」を中心に説明する。未完成の段階で「全業務システム完全無欠陥」「要件確認も例外なく不要」「安全性が認証された」等の表現を使わない。

## 2. サイト配置

| 場所 | 内容 | 初期状態 |
|---|---|---|
| 公開 GitHub repo | source、skills、template、証拠、issue、release | account 確定後に公開可能 |
| GitHub Pages | OSS docs、project showcase、公開デモの説明、download へのリンク | 実際の Pages URL が確定してから表示 |
| 別の明示した hosting | commercial service の LP、任意登録、認証、課金、管理画面 | provider、所有権、予算、実装が揃うまで未提供 |
| GitHub Sponsors / 実在する支援先 | 任意の開発支援 | 有効 profile の確認後に表示 |

GitHub Pages は project showcase に使えるが、主目的が商取引や commercial SaaS であるサイトの無料 hosting としては認められていない。支援ボタン・crowdfunding link は規約に例示されている。したがって、販売中心の LP、登録 backend、決済画面は Pages に載せず、別 hosting へ置く。[S01][S02]

managed verification の実行基盤も別に設計する。OSS 自身の検査・公開の CI と、任意の顧客ファイルを受け取る常設サービスを混同しない。GitHub Actions 自体を商用計算サービスとして再販する構成を採らない。顧客の正当に認可された CI integration は、具体的な利用方法と契約を確認して設計する。[S01]

## 3. 登録の段階と動作

登録状態を `disabled`、`waitlist_live`、`service_live` の三つで管理する。

### disabled

接続先の URL や受付主体が未確定ならフォームを出さない。「運用サービスは準備中」と表示し、無料 core を利用できる導線を残す。存在しない `mailto:`、何も保存しない送信ボタン、成功するだけの mock は公開しない。

### waitlist_live

本当に受け付けられる endpoint が用意できたら、原則はメールアドレスと任意の用途だけを収集する。収集主体、目的、問い合わせ先、保存期間・削除方法、privacy 文書を示す。marketing 配信の同意は資料 download と結び付けず、初期状態で選択しない。メール確認・配信を導入する際は、送信 domain と provider を認可済みのものにする。

フォームには server 側検証、rate limit、CSRF 対策が必要な構成ではその対策、重複登録の冪等処理、エラー表示、削除経路を実装する。公開 GitHub issue や公開ログに登録内容を書かない。認証 token を URL や analytics に漏らさない。顧客の機密要件・source を初回登録で要求しない。

### service_live

実際の利用開始、認証、project 分離、データ保存・削除、利用枠、課金状態、障害時の挙動が完成してから切り替える。カード情報は選んだ決済 provider の適切な hosted flow で扱う。決済 webhook の署名、再送、重複、順序、解約・返金と利用権限の関係を検証する。収益計算上、verification の compute cost、失敗再試行、保管 cost を含める。

自動化する場合も、本人確認、銀行・税情報、利用規約への同意を勝手な値で代行しない。必要な本人作業以外の実装・設定を先に完了する。

## 4. 公開前の受入れシナリオ

| シナリオ | 期待する挙動 |
|---|---|
| 未登録の訪問者 | ソース、実例、証拠、ローカル再検証に到達できる |
| signup provider 未設定 | 登録・決済を装わず、利用できる無料導線を表示 |
| 正常な waitlist 登録 | 実際の保存・受付が確認され、目的と次の段階が分かる |
| 不正入力・通信失敗 | 保存できたと誤表示せず、再試行できる |
| 二重送信 | 設計どおり重複を抑止。通知や課金が増えない |
| marketing 同意なし | サービス上必要な連絡と marketing 配信を区別する |
| 削除依頼 | 明示した経路と保存ポリシーで処理できる |
| 非対応環境の利用者 | 対応済みと装わず、実際に確認した環境と制約を表示 |
| 古い公開デモ | 実行日時・version・再実行方法が分かり、現在 live 実行と誤解しない |

解析データは必要最小限とし、初期は登録不要の試用成功率、検証完了、導線の離脱で改善する。成約率や売上予測は仮説として計測し、根拠のない導入企業・顧客の声・利用人数を表示しない。

## 5. Sponsors の立ち上げ

Sponsors は core の継続開発を任意に支援する導線とする。初期 tier の価値は、謝辞、公開の開発状況、希望するテーマへの投票など、実際に提供可能なものを選ぶ。名前・ロゴ掲載は同意した人だけに行う。証明の合否や脆弱性修正を支援額で変えない。個別の応答 SLA や managed compute は、別の有償サービス条件で扱う。

Codex が準備するもの:

- 短い bio、開発目的、支援金の用途、実現可能な tier 案。
- 有効な支援先が決まったら `.github/FUNDING.yml` の実アカウントまたは実 URL。
- README と docs の支援導線、運用費の説明。

本人／権限者が満たす必要があるもの:

- 対応地域・アカウント・2FA の条件、受領主体、銀行または fiscal host。
- 正確な銀行・税情報、必要な署名、規約の確認・受諾。
- GitHub 側の申請審査と公開状態。

Sponsors の有効化にはこれらの手続があり、単に `FUNDING.yml` を追加しても受領設定は完了しない。[S03][S04] すでに有効な支援先と権限が提供されていれば、公開済み情報の設定で毎回人の承認を挟む必要はない。新しい本人情報・契約・課金の権限が不足する場合だけ、必要な入力と理由を具体的に示す。

## 6. Codex の完了報告に必須の内容

実際の repo / release / docs URL、実際に動く signup URL と登録状態、有効な支援先、公開した保証範囲、実施した動作確認、未解決の account 作業、次に進むための具体的な入力を報告する。準備完了、公開完了、課金受付完了を同じ言葉で表さない。

## 一次資料

- [S01 — GitHub Terms for Additional Products and Features](https://docs.github.com/en/site-policy/github-terms/github-terms-for-additional-products-and-features)
- [S02 — GitHub Pages limits](https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits)
- [S03 — Setting up GitHub Sponsors](https://docs.github.com/en/sponsors/receiving-sponsorships-through-github-sponsors/setting-up-github-sponsors-for-your-personal-account)
- [S04 — Displaying a sponsor button](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/displaying-a-sponsor-button-in-your-repository)

本仕様のデータ最小化・UI・計測項目は設計上の提案である。法域や provider 固有の obligations は公開実装の実条件で確定する。
