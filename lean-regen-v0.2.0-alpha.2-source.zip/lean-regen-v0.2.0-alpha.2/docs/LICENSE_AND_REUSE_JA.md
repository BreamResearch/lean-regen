# Lean Regen — ライセンス・再利用・貢献の設計

調査日: 2026-11-24。以下は自由配布と事業化を両立するための採用方針であり、第三者の権利や個別の法的適合性が証明済みという意味ではない。

## 採用案

### 今回のソースアルファへの適用（2026-11-24 確認）

P0のZIPに収めるものはBreamResearchプロジェクトのソース、証明、文書、検査記録です。Lean証明支援系とLakeは利用者が公式の固定版を取得します。4.19.0と、独立検査で使用する4.36.0の本体はいずれもApache-2.0です。この条件は商用利用を認めており、検証や運用の対価を受け取れます。対象ソフトウェアを再配布する場合には、ライセンス本文、該当する帰属・NOTICE、変更したファイルの変更表示など第4条を適用します。[4.19.0の本文](https://github.com/leanprover/lean4/blob/v4.19.0/LICENSE)・[4.36.0の本文](https://github.com/leanprover/lean4/blob/v4.36.0/LICENSE)。

公式バイナリ配布には、LLVM例外付きApache-2.0のLLVMやLGPLv3のGNU MPなどの部品が含まれます。ネイティブ実行ファイルやコンテナを新たに配布するときは、実際の同梱物と静的・動的リンクの構成を調べ、対象部品に応じて通知、ソース提供、再リンク手段などを整えます。P0の配布ファイル一覧はリリースの `manifest.json` に収録します。[4.19.0同梱通知](https://github.com/leanprover/lean4/blob/v4.19.0/LICENSES)・[4.36.0同梱通知](https://github.com/leanprover/lean4/blob/v4.36.0/LICENSES)。

GitHubの `lean-regen` はLean証明支援系との対応を示すリポジトリ名です。公式商標方針は、この用途と商用を含む正確な互換性表示を、公式・提携と誤認させない条件で認めています。別の商標に「Lean」を組み込むにはLean FROの書面許諾が必要です。有料サービスの商標・ブランド名は未確定です。[Lean FRO商標方針](https://lean-lang.org/trademark-policy/)。

自作のコード、スキル、仕様 template、文書の標準ライセンスを **Apache-2.0** に統一する。完全な公式英文をリポジトリ直下の `LICENSE` に入れる。README の「一般公開」「無料配布」だけでは許諾条件にならない。[L01][L02]

| 観点 | Apache-2.0 | MIT |
|---|---|---|
| 商用利用・改変・再配布 | 許諾条件を守って可能 | 許諾条件を守って可能 |
| ソース非公開の派生利用 | 可能 | 可能 |
| 特許 | 貢献に関連する明示的な grant と特許訴訟時の終了条項がある | Apache と同様の明示的特許条項はない |
| 配布時の主な対応 | LICENSE、帰属、変更表示、該当する NOTICE の保持 | 著作権・許諾表示の保持 |
| 本案との適合 | 企業利用、複数貢献者、再利用条件の明示を重視する標準 | とにかく短い許諾を優先する選択肢 |

この比較の根拠は両ライセンスの公式本文・GitHub のライセンス案内である。[L02][L03] Apache を選んでも特許非侵害、すべての依存の適合性、著作権の存在・帰属が自動保証されるわけではない。

## 配布範囲

- 新規に作成して権利を持つファイルには Apache-2.0 を適用する。SPDX identifier と出典の運用を統一する。
- 既存ライセンス付きファイル、第三者のコード、引用、画像、フォント、runtime 同梱物は元の条件を保持する。自分の root `LICENSE` だけで上書きしない。
- 公開 archive は必要なソース・証拠・文書を中心とし、巨大な toolchain binary を無条件に再配布しない。同梱する場合は固定版について第三者 notices を収集する。
- Lean と mathlib の root は現在 Apache-2.0 だが、将来採用する正確な commit、transitive dependencies、binary 同梱物は別に調べる。現行スターターが mathlib を使わないなら、利用しているとは記載しない。[L04][L05]
- 顧客の要件、秘密情報、生成された独自業務資産を自動で公表する設計にしない。テンプレートの許諾と顧客データの取扱いを分ける。生成物の権利を一律に保証せず、コピーされた第三者資産の条件は引き継ぐ。

## 公開前に作るライセンス資料

1. `LICENSE`: 改変していない Apache-2.0 の全文。
2. `NOTICE`: 実在する帰属と、引き継ぐ必要のある notices。未確認の権利者名を埋めない。
3. `THIRD_PARTY_NOTICES`: 配布対象ごとの名称、version / commit、入手元、ライセンス、必要な本文・帰属の所在。
4. `CONTRIBUTING`: 貢献者が提出権限と元の出典を確認すること、既存通知を削除しないこと、通常の inbound contribution 方針。
5. package metadata / README: 実際の SPDX identifier とライセンスへのリンク。

ライセンススキャナーの成功だけで権利確認が完了したとはしない。出典不明・相反するヘッダー・配布範囲不明のファイルは具体的な解決項目として記録する。

## 貢献を増やしつつ、権利の経路を残す

通常の contribution はプロジェクトの Apache-2.0 の条件を前提に受け付ける。会社が所有する資産を投稿する場合は投稿者に提出権限が必要である。別途の著作権譲渡を初期参加の必須条件にはしない。

Developer Certificate of Origin を導入する場合は、投稿者の提出権限の表明として扱う。著作権譲渡や法律的な無瑕疵保証の代用品ではない。DCO の文面・sign-off を本人の事実に基づかずエージェントが作らない。生成 AI の利用有無と関係なく、コピー元、権利、必要な通知を確認する。[L06]

## 自由配布と売上の両立

無料の core は誰でも取得・改変・商用利用・自己ホストできる状態を維持する。収益は、管理された検証環境、private project の実行、依存更新監視、証拠保管、企業認証、運用支援、応答時間など、実際の追加サービスから得る。無料版から証明の再検査機能を外さない。

Apache-2.0 は第三者による再配布や商用派生も許すため、コード独占による防御は期待しない。実績のある更新対応、使いやすい業務仕様、信頼できる証拠、利用者との関係を事業上の強みにする。非商用条件や競合利用禁止を追加したものを Apache-2.0 と呼ばない。

商品名・ロゴ・公式サービスの表示は、ソフトウェアの利用許諾とは別に説明できる。Apache-2.0 は商標の一般的利用権を与えない。[L02] 「Lean」「Codex」や第三者組織との公式提携・認証を事実なく表示しない。`Lean Regen` は仮称なので公開前に既存名称との衝突を調べる。

## 一次資料

- [L01 — GitHub: Licensing a repository](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository)
- [L02 — Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0.html)
- [L03 — MIT License](https://choosealicense.com/licenses/mit/)
- [L04 — Lean 4 LICENSE](https://github.com/leanprover/lean4/blob/master/LICENSE)
- [L05 — mathlib4 LICENSE](https://github.com/leanprover-community/mathlib4/blob/master/LICENSE)
- [L06 — Developer Certificate of Origin](https://developercertificate.org/)

上流の `master` は調査用リンクであり、製品 release の固定 revision ではない。配布時には採用した実際の revision とライセンスを evidence に残す。
