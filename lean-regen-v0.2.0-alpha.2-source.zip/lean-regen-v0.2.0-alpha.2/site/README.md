# OSS showcase source

Build the standalone static showcase from the repository's recorded status:

```bash
python3 scripts/build_site.py --out site/index.html
```

The handoff may already include a generated page. Use `--replace` to intentionally
regenerate it. After the actual public repository exists, pass
`--repository-url https://github.com/ACTUAL_OWNER/ACTUAL_REPOSITORY` with the resolved
real URL, not these example identifiers. The builder will not guess one.

This page is an OSS project showcase. It collects no personal data and has no
fake signup form. Signup must be implemented and tested on an explicitly chosen
external commercial host before changing the flow. `waitlist_live` and
`service_live` are different states. See `docs/SIGNUP_AND_SPONSORS_JA.md`.

The generated page is a dated source-alpha snapshot. It is not a live proof
dashboard. In P0, check responsive layout, keyboard navigation, source/download
links, scope labels and the actual Pages URL before publishing. P1/P2 should
replace the snapshot status mapping only after real evidence exists.

No images, trackers, external fonts or JavaScript packages are required.
