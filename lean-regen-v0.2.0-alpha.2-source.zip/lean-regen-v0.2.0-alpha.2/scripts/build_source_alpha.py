#!/usr/bin/env python3
"""Build unsigned, reproducible source-alpha assets from the bytes of one Git commit."""
import argparse
import hashlib
import io
import json
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
TAG = "v0.2.0-alpha.2"
UPSTREAM = "packages/lean-verified-sdlc/"
STARTER = UPSTREAM + "assets/lean-starter/"
UPSTREAM_INDEX = "283d48ac0085a4cfc016a2226d00493991b7d2df3d96925da74477f390dc2048"
BUILD_STEPS = ["build", "fixed_challenge", "axioms", "kernel_examples", "runtime_smoke"]
MUTATIONS = {"wrong_reserved_delta", "reject_all_reservations", "remove_reservation_guard"}
PRIVATE_PARTS = {
    ".git", ".codex", ".aws", ".ssh", ".gnupg", ".config", ".netrc", ".npmrc",
    "credentials", "credentials.json", ".lake", ".venv", "__pycache__", ".pytest_cache", ".ds_store", ".idea",
    "runtime", "local-runs", "node_modules", "dist"
}
PRIVATE_SUFFIXES = {".pyc", ".pyo", ".key", ".pem", ".p12", ".p8", ".pfx", ".keystore", ".olean",
                   ".a", ".o", ".dylib", ".so", ".exe", ".sqlite", ".db", ".zip", ".gz", ".zst"}
PRIVATE_TEXT = re.compile(
    rb"-----BEGIN (?:[A-Z0-9 ]+ )?PRIVATE KEY-----"
    rb"|(?:gh[pousr]_|github_pat_)[A-Za-z0-9_]{20,}|(?:AKIA|ASIA)[0-9A-Z]{16}"
    rb"|/(?:Users|home)/[^/\s\"']+/|/private/var/folders/[A-Za-z0-9]+/"
    rb"|(?:sk_live_|sk-proj-|xox[baprs]-)[A-Za-z0-9_-]{18,}|AIza[A-Za-z0-9_-]{35}"
    rb"|https?://[^/\s:@]+:[^/\s@]+@"
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def index_digest(index):
    return sha(json.dumps(index, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode())


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def check_file(name, data):
    path = PurePosixPath(name)
    if not path.parts or path.is_absolute() or path.as_posix() != name or any(
        not re.fullmatch(r"[A-Za-z0-9_.-]+", part) or part == ".." or part.lower() in PRIVATE_PARTS
        or part.lower().startswith(".env") or part.lower().startswith("id_rsa")
        or part.lower().startswith("id_ed25519") for part in path.parts
    ) or path.suffix.lower() in PRIVATE_SUFFIXES:
        raise ValueError(f"Non-distributable filename: {name}")
    if b"\x00" in data or PRIVATE_TEXT.search(data):
        raise ValueError(f"Binary, private path or credential marker in {name}")
    data.decode("utf-8")


def committed_sources(revision):
    if Path(git("rev-parse", "--show-toplevel").decode().strip()).resolve() != ROOT:
        raise ValueError("The release builder requires a checkout rooted at the product repository")
    commit = git("rev-parse", "--verify", "--end-of-options", revision + "^{commit}").decode().strip()
    files, modes = {}, {}
    for entry in git("ls-tree", "-rz", "--full-tree", commit).split(b"\0"):
        if not entry:
            continue
        header, path = entry.split(b"\t", 1)
        mode, kind, oid = header.decode().split()
        name = path.decode()
        if kind != "blob" or mode not in {"100644", "100755"}:
            raise ValueError(f"Source alpha requires regular files: {name}")
        data = git("cat-file", "blob", oid)
        check_file(name, data)
        files[name] = data
        modes[name] = int(mode, 8)
    return commit, files, modes


def check_evidence(files):
    upstream = {name[len(UPSTREAM):]: sha(data) for name, data in files.items() if name.startswith(UPSTREAM)}
    if index_digest(upstream) != UPSTREAM_INDEX or json.loads(files["UPSTREAM_PROVENANCE.json"])["files"] != upstream:
        raise ValueError("Historical source inventory differs from v1.0.0")
    name = json.loads(files["STATUS.json"])["evidence"]["p0a_core_report"]
    if not re.fullmatch(r"validation/p0a-[a-zA-Z0-9_-]+/core-check\.json", name):
        raise ValueError("Expected a fresh P0A run directory")
    run = name.rsplit("/", 1)[0] + "/"
    originals = ("validation/cli_core_check.json", STARTER + "evidence/actual-kernel-report.json")
    if any(files[name] == files[path] for path in originals):
        raise ValueError("Fresh P0A report duplicates the historical evidence")
    report = json.loads(files[name])
    spec = json.loads(files[STARTER + "assurance.json"])
    obligations = {theorem["name"] for theorem in spec["theorems"]}
    audit = report["theorem_axioms"]
    if (report["status"] != "CORE_KERNEL_CHECKED" or report["formal_check_passed"] is not True
            or report["checker_profile"] != "ordinary_lean_kernel" or report["errors"]
            or report["end_to_end_verified"] is not False or report["manual_code_review_waiver"] is not False
            or report["toolchain_pin"] != files[STARTER + "lean-toolchain"].decode().strip()
            or report["theorem_count"] != len(obligations) or set(audit) != obligations
            or any(not set(axioms) <= set(spec["allowed_axioms"]) for axioms in audit.values())):
        raise ValueError("Expected a complete ordinary-kernel result for the registered obligations")
    inputs = {k[len(STARTER):]: sha(v) for k, v in files.items()
              if k.startswith(STARTER) and not k.startswith(STARTER + "evidence/")}
    templates = UPSTREAM + "assets/templates/"
    inputs.update({"worksheets/" + k[len(templates):]: sha(v) for k, v in files.items() if k.startswith(templates)})
    contract = {k: inputs[k] for k in spec["contract_files"]}
    if (report["source_files"] != inputs or report["source_digest"] != index_digest(inputs)
            or report["contract_digest"] != index_digest(contract)):
        raise ValueError("Report inputs differ from the distributed demo")
    verifier = {k: sha(files[UPSTREAM + "scripts/" + k]) for k in ("assurance_lib.py", "verify_project.py")}
    if report["verifier_source_sha256"] != verifier:
        raise ValueError("Reported verifier differs from the distributed verifier")
    if [s["name"] for s in report["steps"]] != BUILD_STEPS:
        raise ValueError("Missing required Lean verification step")
    for step in report["steps"]:
        log = files[run + "core-check_logs/" + step["name"] + ".log"]
        if step["exit_code"] != 0 or step["log_sha256"] != sha(log):
            raise ValueError("Invalid verification step or log: " + step["name"])
    mutations = json.loads(files[run + "mutations/summary.json"])
    results = mutations["results"]
    if (mutations["all_expected_rejections_observed"] is not True or len(results) != len(MUTATIONS)
            or {r["case"] for r in results} != MUTATIONS):
        raise ValueError("Expected all three semantic mutation checks")
    for result in results:
        log = files[run + "mutations/" + result["case"] + ".log"]
        if (result["rejected_by_unchanged_proofs"] is not True or result["exit_code"] == 0
                or result["log_sha256"] != sha(log)):
            raise ValueError("Invalid mutation evidence: " + result["case"])
    return name, report


def release_assets(commit, files, modes):
    name, report = check_evidence(files)
    archive_name = f"lean-regen-{TAG}-source.zip"
    archive = io.BytesIO()
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_STORED) as out:
        for path, data in sorted(files.items()):
            entry = zipfile.ZipInfo(f"lean-regen-{TAG}/{path}", date_time=(1980, 1, 1, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = modes[path] << 16
            out.writestr(entry, data)
    assets = {archive_name: archive.getvalue(), "core-check.json": files[name],
              "RELEASE-NOTES.md": files["CHANGELOG.md"]}
    manifest = {
        "format": "lean-regen-source-alpha-v1", "tag": TAG, "commit": commit,
        "archive": archive_name, "archive_sha256": sha(assets[archive_name]),
        "license": "Apache-2.0", "notice_files": ["LICENSE", "NOTICE", "THIRD_PARTY_NOTICES.md"],
        "files": {k: sha(v) for k, v in sorted(files.items())},
        "core_report": name, "core_report_sha256": sha(files[name]),
        "core_contract_sha256": report["contract_digest"], "core_source_sha256": report["source_digest"],
        "lean_toolchain": report["toolchain_pin"], "checker_profile": report["checker_profile"],
        "theorem_count": report["theorem_count"], "independent_receipt": None,
        "scope": "Unsigned source distribution. The local kernel evidence covers only the sequential synthetic inventory core."
    }
    for required in manifest["notice_files"]:
        if required not in files:
            raise ValueError("Missing license material: " + required)
    assets["manifest.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    assets["SHA256SUMS"] = "".join(f"{sha(v)}  {k}\n" for k, v in sorted(assets.items())).encode()
    return assets


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--commit", default="HEAD", help="Commit or ref to package")
    parser.add_argument("--out", type=Path, required=True, help="New output directory")
    args = parser.parse_args()
    try:
        commit, files, modes = committed_sources(args.commit)
        assets = release_assets(commit, files, modes)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        if args.out.exists() or args.out.is_symlink():
            raise FileExistsError("Choose a new output directory")
        with tempfile.TemporaryDirectory(dir=args.out.parent) as staging:
            complete = Path(staging) / "assets"
            complete.mkdir()
            for name, data in assets.items():
                (complete / name).write_bytes(data)
            complete.rename(args.out)
        print(f"Packaged {len(files)} source files at {commit} into {args.out}")
    except (ValueError, KeyError, OSError, subprocess.CalledProcessError) as error:
        print(f"BLOCKED: {error}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
