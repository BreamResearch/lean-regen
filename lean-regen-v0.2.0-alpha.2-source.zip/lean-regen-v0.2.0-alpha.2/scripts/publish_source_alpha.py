#!/usr/bin/env python3
"""Publish the tagged OSS source alpha from a trusted operator checkout and prepared assets."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
from urllib.request import urlopen

import build_source_alpha as builder

ROOT = Path(__file__).resolve().parents[1]
TAG = builder.TAG
ZIP = "lean-regen-" + TAG + "-source.zip"
ASSETS = {ZIP, "manifest.json", "RELEASE-NOTES.md", "SHA256SUMS", "core-check.json"}


def run(*command):
    return subprocess.check_output(command, cwd=ROOT, text=True).strip()


def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs(assets):
    if set(p.name for p in assets.iterdir()) != ASSETS or any(
            not p.is_file() or p.is_symlink() for p in assets.iterdir()):
        raise ValueError("Expected the five complete source-alpha assets")
    commit, files, modes = builder.committed_sources("refs/tags/" + TAG)
    expected = builder.release_assets(commit, files, modes)
    if set(expected) != ASSETS:
        raise ValueError("Unexpected canonical release asset set")
    for name, data in expected.items():
        if (assets / name).read_bytes() != data:
            raise ValueError("Release asset differs from the canonical tagged build: " + name)
    return commit, {name: hashlib.sha256(data).hexdigest() for name, data in expected.items()}


def api(gh, path, *args, allow_missing=False, payload=None):
    cmd = [gh, "api", "--hostname", "github.com", path, *args]
    if payload is not None:
        cmd.extend(["--input", "-"])
    result = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True,
                            input=json.dumps(payload) if payload is not None else None)
    if result.returncode:
        if allow_missing and "(HTTP 404)" in result.stderr:
            return None
        raise ValueError(result.stderr.strip())
    return json.loads(result.stdout) if result.stdout.strip() else {}


def protect_tag(gh, repo, allow_create):
    # Rules apply to one tag. Creation remains available for the initial push.
    name = "Lean Regen protect " + TAG
    path = f"repos/{repo}/rulesets"
    conditions = {"ref_name": {"include": ["refs/tags/" + TAG], "exclude": []}}
    policy = {"name": name, "target": "tag", "enforcement": "active", "conditions": conditions,
              "bypass_actors": [], "rules": [{"type": "update"}, {"type": "deletion"}]}
    page = 1
    matches = []
    while True:
        items = api(gh, path + f"?includes_parents=false&per_page=100&page={page}")
        matches.extend(item for item in items if item["name"] == name)
        if len(items) < 100:
            break
        page += 1
    if len(matches) > 1:
        raise ValueError("Ambiguous source tag protection rulesets")
    if not matches and not allow_create:
        raise ValueError("Published source tag has no matching protection ruleset")
    rule = matches[0] if matches else api(gh, path, "-X", "POST", payload=policy)
    rule = api(gh, path + "/" + str(rule["id"]))
    if (rule["source_type"] != "Repository" or rule["source"].casefold() != repo.casefold()
            or any(rule.get(key) != policy[key] for key in ("name", "target", "enforcement", "conditions", "bypass_actors"))
            or sorted(r["type"] for r in rule["rules"]) != ["deletion", "update"]):
        raise ValueError("Existing source tag ruleset differs from the required protection")
    for entry in rule["rules"]:
        parameters = entry.get("parameters", {})
        if parameters and not (entry["type"] == "update" and parameters == {"update_allows_fetch_and_merge": False}):
            raise ValueError("Source tag rule has unexpected parameters")


def check_remote_tag(git, git_url, ref, tag_object, commit):
    refs = {}
    for line in run(*git, "ls-remote", git_url, ref, ref + "^{}").splitlines():
        oid, name = line.split("\t")
        refs[name] = oid
    if refs.get(ref) != tag_object or refs.get(ref + "^{}", refs.get(ref)) != commit:
        raise ValueError("Remote source tag or peeled commit differs from the checked candidate")


def check_ci_job(gh, repo, workflow_run):
    run_id = workflow_run["id"]
    attempt = workflow_run["run_attempt"]
    data = api(gh, f"repos/{repo}/actions/runs/{run_id}/attempts/{attempt}/jobs?per_page=100")
    matches = [job for job in data["jobs"] if job["name"] == "source-checks"]
    if (len(matches) != 1 or matches[0]["status"] != "completed" or matches[0]["conclusion"] != "success"
            or matches[0]["head_sha"] != workflow_run["head_sha"]):
        raise ValueError("The required source-checks job did not succeed")
    required = {"Read source without persisting credentials", "Check immutable upstream bytes",
                "Exercise CLI, packaging and state model", "Exercise historical evidence tooling",
                "Fetch and check the pinned historical toolchain", "Rebuild and check the sequential inventory model",
                "Rebuild source assets from the tested commit"}
    passed = {step["name"] for step in matches[0]["steps"]
              if step["status"] == "completed" and step["conclusion"] == "success"}
    if not required <= passed:
        raise ValueError("A required source-checks step did not run successfully")


def check_published_release(rel, title, notes, hashes):
    if (rel["tag_name"] != TAG or rel["name"] != title
            or (rel["body"] or "").replace("\r\n", "\n").rstrip("\n") != notes.rstrip("\n")
            or rel["draft"] or not rel["immutable"] or not rel["prerelease"]
            or {a["name"]: a.get("digest") for a in rel["assets"]} != {n: "sha256:" + h for n, h in hashes.items()}):
        raise ValueError("Published release metadata did not satisfy the source-alpha profile")


def wait_for_ci(gh, repo, commit):
    end = time.monotonic() + 35 * 60
    while time.monotonic() < end:
        jobs = api(gh, f"repos/{repo}/actions/workflows/source-checks.yml/runs?branch=main&head_sha={commit}",
                   allow_missing=True) or {}
        matches = [j for j in jobs.get("workflow_runs", []) if j["head_sha"] == commit
                   and j["event"] in ("push", "workflow_dispatch") and j["head_branch"] == "main"
                   and j["path"] == ".github/workflows/source-checks.yml"
                   and j["repository"]["full_name"].casefold() == repo.casefold()
                   and j["head_repository"]["full_name"].casefold() == repo.casefold()]
        if matches:
            newest = max(matches, key=lambda j: (j["run_number"], j["run_attempt"]))
            if newest["status"] == "completed":
                if newest["conclusion"] != "success":
                    raise ValueError("Source checks require attention: " + newest["html_url"])
                check_ci_job(gh, repo, newest)
                return newest["html_url"]
        time.sleep(15)
    raise ValueError("Source checks have not completed; rerun after the GitHub check finishes")


def publish(gh, repo, assets, commit, hashes):
    if not re.fullmatch(r"[A-Za-z0-9-]+/[A-Za-z0-9._-]+", repo):
        raise ValueError("Expected owner/repository")
    owner = repo.split("/")[0]
    actor = api(gh, "user")["login"]
    if actor.casefold() != owner.casefold():
        raise ValueError("This personal-repository bootstrap requires the specified authenticated owner")
    path = f"repos/{repo}"
    url = f"https://github.com/{repo}"
    git_url = url + ".git"
    if run("git", "remote", "get-url", "--push", "origin") != git_url:
        raise ValueError("origin differs from the selected target")
    info = api(gh, path, allow_missing=True)
    if info is None:
        run(gh, "repo", "create", repo, "--public", "--description", "Lean contracts and reproducible evidence for a sequential inventory core.")
        info = api(gh, path)
    if (info["full_name"].casefold() != repo.casefold() or info["private"] or info["fork"]
            or info["archived"] or not info["permissions"]["admin"]):
        raise ValueError("Expected a public, active, owner-administered source repository")
    git = ["git", "-c", "core.hooksPath=/dev/null", "-c", "credential.helper=",
           "-c", "credential.helper=!" + shlex.quote(gh) + " auth git-credential"]
    refs = {}
    for line in run(*git, "ls-remote", git_url).splitlines():
        oid, ref = line.split("\t")
        refs[ref] = oid
    main_ref = "refs/heads/main"
    tag_ref = f"refs/tags/{TAG}"
    tag_object = run("git", "rev-parse", tag_ref)
    title = "Lean Regen source alpha " + TAG
    notes = (assets / "RELEASE-NOTES.md").read_text(encoding="utf-8")
    rel = api(gh, path + f"/releases/tags/{TAG}", allow_missing=True)
    published = rel is not None and not rel["draft"]
    if published:
        check_published_release(rel, title, notes, hashes)
        check_remote_tag(git, git_url, tag_ref, tag_object, commit)
    elif refs and (refs.get(main_ref) != commit or refs.get(tag_ref, tag_object) != tag_object):
        raise ValueError("Existing remote history differs. No push or settings change was made.")
    protect_tag(gh, repo, allow_create=not published)
    for setting in ("/private-vulnerability-reporting", "/immutable-releases"):
        current = api(gh, path + setting, allow_missing=True) or {}
        if current.get("enabled") is True:
            continue
        if published:
            raise ValueError("Published repository setting is disabled: " + setting)
        api(gh, path + setting, "-X", "PUT")
        if api(gh, path + setting).get("enabled") is not True:
            raise ValueError("Required GitHub setting is disabled: " + setting)
    if not published:
        run(*git, "push", "--atomic", git_url, f"{commit}:{main_ref}", f"{tag_ref}:{tag_ref}")
    check_remote_tag(git, git_url, tag_ref, tag_object, commit)
    ci = wait_for_ci(gh, repo, commit)
    if rel is None:
        rel = next((r for r in api(gh, path + "/releases?per_page=100") if r["tag_name"] == TAG), None)
    if rel is None:
        run(gh, "release", "create", TAG, "--repo", repo, "--draft", "--prerelease", "--verify-tag",
            "--title", title, "--notes-file", str(assets / "RELEASE-NOTES.md"))
        rel = next(r for r in api(gh, path + "/releases?per_page=100") if r["tag_name"] == TAG)
    uploaded = {a["name"]: a.get("digest") for a in rel["assets"]}
    if set(uploaded) - ASSETS or any(uploaded[n] != "sha256:" + hashes[n] for n in uploaded):
        raise ValueError("Release contains unexpected asset bytes; existing assets were preserved")
    for name in sorted(ASSETS - set(uploaded)):
        if not rel["draft"]:
            raise ValueError("Published release is missing an asset")
        run(gh, "release", "upload", TAG, str(assets / name), "--repo", repo)
    rel = api(gh, path + f"/releases/{rel['id']}")
    if {a["name"]: a.get("digest") for a in rel["assets"]} != {n: "sha256:" + h for n, h in hashes.items()}:
        raise ValueError("Uploaded release assets differ from prepared assets")
    check_remote_tag(git, git_url, tag_ref, tag_object, commit)
    if rel["draft"]:
        run(gh, "release", "edit", TAG, "--repo", repo, "--draft=false", "--prerelease",
            "--title", title, "--notes", notes)
    rel = api(gh, path + f"/releases/tags/{TAG}")
    check_remote_tag(git, git_url, tag_ref, tag_object, commit)
    check_published_release(rel, title, notes, hashes)
    for asset in rel["assets"]:
        with urlopen(asset["browser_download_url"], timeout=60) as response:
            content = response.read((assets / asset["name"]).stat().st_size + 1)
        if hashlib.sha256(content).hexdigest() != hashes[asset["name"]]:
            raise ValueError("Anonymous download checksum mismatch: " + asset["name"])
    return {"repository": url, "release": rel["html_url"], "commit": commit, "source_checks": ci,
            "download": next(a["browser_download_url"] for a in rel["assets"] if a["name"] == ZIP),
            "private_reporting": url + "/security/advisories/new", "immutable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True)
    parser.add_argument("--assets", type=Path, required=True)
    args = parser.parse_args()
    try:
        gh = shutil.which("gh")
        if not gh:
            raise ValueError("The operator needs an authenticated GitHub CLI")
        os.environ["GH_HOST"] = "github.com"
        os.environ.pop("GH_REPO", None)
        os.environ["GH_PROMPT_DISABLED"] = "1"
        os.environ["GIT_TERMINAL_PROMPT"] = "0"
        assets = args.assets.resolve(strict=True)
        commit, hashes = inputs(assets)
        # Keep the verified inputs stable through CI and all draft uploads.
        with tempfile.TemporaryDirectory(prefix="lean-regen-publish-") as folder:
            frozen = Path(folder)
            for name, digest in hashes.items():
                shutil.copyfile(assets / name, frozen / name)
                if hash_file(frozen / name) != digest:
                    raise ValueError("Release inputs changed while staging: " + name)
            print(json.dumps(publish(gh, args.repo, frozen, commit, hashes), indent=2))
    except (OSError, ValueError, KeyError, StopIteration, subprocess.SubprocessError) as error:
        parser.exit(2, f"BLOCKED: {error}\n")


if __name__ == "__main__":
    main()
