#!/usr/bin/env python3
"""Build a self-contained OSS showcase. Signup stays disabled until separately implemented."""
import argparse
import html
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--repository-url")
    parser.add_argument("--download-url", help="Anonymous release asset URL verified after publication")
    parser.add_argument("--replace", action="store_true")
    args = parser.parse_args()
    status = json.loads((ROOT / "STATUS.json").read_text())
    repository_url = args.repository_url or status["publication"].get("github_repository")
    if repository_url and not re.fullmatch(r"https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/?", repository_url):
        parser.error("Use an actual https://github.com/owner/repository URL")
    if status["publication"]["signup_state"] != "disabled":
        parser.error("This alpha showcase has no signup backend; implement the real service flow before changing signup state")
    count = int(status["implementation"]["historical_inventory_theorems"])
    url = html.escape(repository_url or "", quote=True)
    source_link = f'<a class="secondary" href="{url}">GitHubでソースを見る ↗</a>' if url else '<p class="note">ソース公開先は、公開作業で実際のURLを設定します。</p>'
    if args.download_url:
        base = (repository_url or "").rstrip("/")
        if not base or not re.fullmatch(re.escape(base) + r"/releases/download/[A-Za-z0-9._-]+/[A-Za-z0-9._-]+\.zip", args.download_url):
            parser.error("Expected an HTTPS ZIP asset of the selected GitHub repository")
        source_link += f'<a class="secondary" href="{html.escape(args.download_url, quote=True)}">ソースZIPを取得</a>'
    page = '''<!doctype html>
<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="実装は作り直せる。業務の約束と証拠を引き継ぐ、Leanベースの公開スターター。">
<title>Lean Regen — 約束を残し、実装を更新する</title>
<style>
:root{color-scheme:light;--ink:#142c38;--muted:#536873;--accent:#086d63;--line:#cddbdc;--paper:#f5f8f6}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:system-ui,-apple-system,"Noto Sans JP",sans-serif;line-height:1.8}a{color:var(--accent)}main,header,footer{max-width:1120px;margin:auto;padding:26px}header{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--line)}.brand{font-weight:800;font-size:22px;letter-spacing:-.7px}.label{font-size:12px;font-weight:700;letter-spacing:1.4px;text-transform:uppercase}.pill{padding:4px 12px;border:1px solid var(--line);border-radius:20px;font-size:12px}.hero{padding:70px 0 54px;display:grid;grid-template-columns:1.5fr 1fr;gap:40px;align-items:start}h1{font-size:clamp(32px,4.3vw,52px);line-height:1.4;letter-spacing:-1.5px;margin:18px 0 24px}h2{font-size:27px;line-height:1.5;margin:0 0 18px}h3{font-size:18px;margin:0 0 12px}p{margin:0 0 20px}.intro{font-size:17px;max-width:650px;color:var(--muted)}.button,.secondary{display:inline-block;font-weight:700;text-decoration:none;padding:12px 20px;margin:6px 10px 6px 0;border-radius:7px}.button{background:var(--accent);color:white}.secondary{border:1px solid var(--accent)}.note{font-size:13px;color:var(--muted)}.status{background:#e4efeb;padding:28px;border:1px solid #b5cec6;border-radius:12px}.number{font-size:44px;font-weight:800;line-height:1.1}.status hr{border:0;border-top:1px solid #b5cec6;margin:22px 0}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.card{padding:26px;background:white;border:1px solid var(--line);border-radius:10px}.section{padding:45px 0;border-top:1px solid var(--line)}.overline{display:block;color:var(--accent);font-size:12px;font-weight:800;letter-spacing:1px;margin-bottom:10px}pre{overflow:auto;padding:22px;background:#152f39;color:#e3f3ef;border-radius:10px;font-size:13px;line-height:1.7}code{font-family:ui-monospace,SFMono-Regular,monospace}ul{padding-left:22px}footer{font-size:12px;color:var(--muted);border-top:1px solid var(--line)}a:focus-visible{outline:3px solid #b47800;outline-offset:4px}@media(max-width:760px){.hero{grid-template-columns:1fr;padding-top:38px;gap:22px}.grid{grid-template-columns:1fr}main,header,footer{padding:20px}h1{letter-spacing:-.7px}.section{padding:32px 0}}
</style></head><body>
<header><span class="brand">BreamResearch / lean-regen</span><span class="pill">SOURCE ALPHA · 開発中</span></header>
<main><section class="hero"><div><h1>予約の実装を変えても、<br>同じ契約を満たすか確かめる。</h1><p class="intro">10枠の在庫から3枠を予約し、2枠を解放すると、残りは9枠です。上限を超える予約は拒否されます。この動作を定めるLeanの仕様、実装、証明と検査手順を、登録せずに手元で試せます。</p><a class="button" href="#quickstart">登録せず、無料で試す</a><a class="secondary" href="#scope">検証の範囲を見る</a>__SOURCE_LINK__</div>
<aside class="status"><span class="overline">純粋コアの検査</span><p><span class="number">__COUNT__</span> 個の登録定理</p><p>逐次・単一資源の数量予約モデルを、Lean 4.19.0で検査済み。</p><hr><p class="note">独立検査サービス、無人での更新・公開、DB等との実行対応、有料運用は今後の実装対象です。このページは稼働サービスのダッシュボードではありません。</p></aside></section>
<section class="section"><h2>ソースに含まれるもの</h2><div class="grid"><article class="card"><h3>仕様を資産にする</h3><p>成功・拒否の条件、前提、具体例を、実装から独立した契約として残します。</p></article><article class="card"><h3>変更を検証する</h3><p>新しい実装を同じ契約に照らします。証明を通すために要求を緩めない設計です。</p></article><article class="card"><h3>証拠を持ち運ぶ</h3><p>仕様、証明、対象バージョン、検査記録を一緒に保ち、手元で確認できます。</p></article></div></section>
<section id="scope" class="section"><h2>このデモで、確かめたこと。</h2><div class="grid"><article class="card"><h3>正しく成功する</h3><p>許される数量の予約・解放は、定義された正確な増減を行います。</p></article><article class="card"><h3>拒否で状態を変えない</h3><p>条件を満たさない操作は拒否し、元の状態を返します。</p></article><article class="card"><h3>数量を保存する</h3><p>モデル内の任意の有限操作列で、容量の不変条件が維持されます。</p></article></div><p class="note" style="margin-top:22px">対象外: 個別予約の所有権、認証、DB、並行実行、再送の重複排除、障害回復、コンパイラやOSの正しさ。純粋コアの証明から、実システム全体の無欠陥性を主張しません。</p></section>
<section id="quickstart" class="section"><span class="overline">Local first. No account.</span><h2>まず、手元で同じ例を動かす。</h2><p>公開ソースを取得し、Python 3.11以上と、明示的に信頼したLean/Lake 4.19.0を用意します。新しい作業フォルダーへ結果を書き出します。</p><pre><code>python3 scripts/leanregen.py check-upstream
python3 scripts/leanregen.py demo \\
  --tool-bin /absolute/path/to/lean-4.19.0/bin \\
  --workdir ../lean-regen-demo-001</code></pre><p class="note">ソースと検査手順はApache-2.0で配布できます。ローカルでの検査に利用登録は不要です。実行手順と前提はREADMEをご覧ください。</p></section>
<section class="section"><span class="overline">Optional managed operation</span><h2>マネージド運用の提供状況</h2><p>非公開プロジェクトの隔離実行、依存更新の監視、計算予算の管理を任意サービスとして計画しています。</p><p class="note">BreamResearchの運用サービスと申込受付は準備中です。現在このページではメールアドレスや決済情報を収集しません。</p></section></main>
<footer>Lean Regen · 暫定名称 · Apache-2.0 · 2026-11-24時点の公開準備用ソース。Leanおよび参照先組織による認定・推奨を意味しません。</footer>
</body></html>'''.replace("__SOURCE_LINK__", source_link).replace("__COUNT__", str(count))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w" if args.replace else "x", encoding="utf-8") as stream:
        stream.write(page)
    print(f"BUILT OSS_SHOWCASE {args.out}; signup disabled; no network deployment")


if __name__ == "__main__":
    main()
