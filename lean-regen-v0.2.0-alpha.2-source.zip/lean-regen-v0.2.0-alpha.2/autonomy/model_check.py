#!/usr/bin/env python3
"""Check Lean Regen's design state model; never a production release verifier.

This script uses test-fixture booleans. It does not run Lean, authenticate a
receipt, enforce IAM or budgets, publish an artifact, or deploy a service.
Default execution requires Python 3.10+ standard library only.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def guard_value(guard: Any, facts: dict[str, Any]) -> bool:
    """Only literal JSON true satisfies a named positive evidence fact."""
    if type(guard) is bool:
        return guard
    if isinstance(guard, str):
        return facts.get(guard) is True
    if not isinstance(guard, dict) or len(guard) != 1:
        raise ValueError(f"Invalid guard: {guard!r}")
    op, operand = next(iter(guard.items()))
    if op == "not":
        return not guard_value(operand, facts)
    if op in ("all", "any"):
        if not isinstance(operand, list) or not operand:
            raise ValueError(f"{op} requires a nonempty list")
        values = [guard_value(child, facts) for child in operand]
        return all(values) if op == "all" else any(values)
    raise ValueError(f"Unknown guard operator: {op!r}")


def validate_machine(document: dict[str, Any]) -> None:
    if document.get("implementation_status") != "DESIGN_REFERENCE_MODEL_ONLY":
        raise ValueError("This checker is restricted to design reference models")
    for name, machine in document["machines"].items():
        states = machine["states"]
        if not states or len(set(states)) != len(states):
            raise ValueError(f"{name}: states must be unique and nonempty")
        if machine["initial"] not in states:
            raise ValueError(f"{name}: invalid initial state")
        terminals = set(machine["terminal"])
        if not terminals.issubset(states):
            raise ValueError(f"{name}: unknown terminal state")
        for entry in machine["transitions"]:
            sources = entry["from"]
            if not isinstance(sources, list) or not sources:
                raise ValueError(f"{name}: missing source states")
            if not set(sources).issubset(states) or entry["to"] not in states:
                raise ValueError(f"{name}: invalid transition endpoint")
            if terminals.intersection(sources):
                raise ValueError(f"{name}: terminal state has outgoing transition")
            if not isinstance(entry["event"], str) or not entry["event"]:
                raise ValueError(f"{name}: invalid event")
            guard_value(entry["guard"], {})


def step(
    machine: dict[str, Any], state: str, event: str, facts: dict[str, Any]
) -> tuple[str, bool, str]:
    if state not in machine["states"]:
        raise ValueError(f"Unknown state: {state}")
    if state in machine["terminal"]:
        return state, True, "TERMINAL_CANDIDATE_IMMUTABLE"
    for entry in machine["transitions"]:
        if state not in entry["from"]:
            continue
        if entry["event"] not in (event, "*"):
            continue
        if guard_value(entry["guard"], facts):
            return entry["to"], False, entry.get("reason", "GUARDS_SATISFIED")
    return state, True, "EVENT_REJECTED"


def run_case(machines: dict[str, Any], case: dict[str, Any]) -> dict[str, Any]:
    machine = machines[case["machine"]]
    state = case["initial_state"]
    rejected = False
    trace = []
    if not case["events"]:
        raise ValueError(f"{case['id']}: at least one event is required")
    for event in case["events"]:
        facts = {**case.get("base_facts", {}), **event.get("facts", {})}
        before = state
        state, rejected, reason = step(machine, state, event["event"], facts)
        trace.append(
            {
                "from": before,
                "event": event["event"],
                "to": state,
                "event_rejected": rejected,
                "reason": reason,
            }
        )
    passed = (
        state == case["expected_state"]
        and rejected is case["expected_last_event_rejected"]
    )
    return {
        "id": case["id"],
        "passed": passed,
        "expected_state": case["expected_state"],
        "actual_state": state,
        "expected_last_event_rejected": case["expected_last_event_rejected"],
        "actual_last_event_rejected": rejected,
        "trace": trace,
    }


def policy_semantic_errors(policy: dict[str, Any]) -> list[str]:
    """Selected cross-field design rules; not authorization verification."""
    errors = []
    budget = policy["budget"]
    if budget["max_cost_minor_per_candidate"] > budget["max_cost_minor_per_project_day"]:
        errors.append("candidate_budget_exceeds_project_day_budget")
    autonomy = policy["autonomy"]
    envelopes = autonomy["parameter_envelopes"]
    ids = [envelope["id"] for envelope in envelopes]
    if len(ids) != len(set(ids)):
        errors.append("parameter_envelope_ids_not_unique")
    for envelope in envelopes:
        if envelope["integer_minimum"] > envelope["integer_maximum"]:
            errors.append("parameter_envelope_empty_range")
    if "parameter_selection" in autonomy["allowed_change_classes"]:
        if "A2_PREAUTHORIZED_PARAMETERS" not in autonomy["enabled_tiers"] or not envelopes:
            errors.append("parameter_selection_has_no_authorized_envelope")
    elif envelopes or "A2_PREAUTHORIZED_PARAMETERS" in autonomy["enabled_tiers"]:
        errors.append("parameter_tier_and_change_class_mismatch")
    if policy["publication"]["auto_publish_after_all_gates"]:
        if "A3_PUBLIC_DISTRIBUTION" not in autonomy["enabled_tiers"]:
            errors.append("publication_tier_missing")
    if policy["lifecycle"] == "active":
        actors = [
            policy["identities"][name]
            for name in ("producer", "verifier", "publisher", "policy_evaluator")
        ]
        if not all(isinstance(actor, str) and actor for actor in actors):
            errors.append("active_role_identity_missing")
        elif len(set(actors)) != len(actors):
            errors.append("active_role_identities_not_distinct")
        version = policy["verification"]["lean_version"]
        match = re.fullmatch(r"4\.(\d+)\.(\d+)", version or "")
        if match is None or int(match.group(1)) < 35:
            errors.append("active_profile_requires_supported_lean_4_35_or_later")
    return errors


def policy_cross_field_cases(policy: dict[str, Any]) -> list[dict[str, Any]]:
    cases = []

    def check(name: str, candidate: dict[str, Any], expected: str | None) -> None:
        observed = policy_semantic_errors(candidate)
        passed = not observed if expected is None else expected in observed
        cases.append({"id": name, "passed": passed, "observed_errors": observed})

    check("POL-001-example-cross-fields", policy, None)
    candidate = copy.deepcopy(policy)
    candidate["budget"]["max_cost_minor_per_candidate"] = (
        candidate["budget"]["max_cost_minor_per_project_day"] + 1
    )
    check("POL-002-cumulative-budget", candidate, "candidate_budget_exceeds_project_day_budget")
    candidate = copy.deepcopy(policy)
    candidate["autonomy"]["allowed_change_classes"].append("parameter_selection")
    check("POL-003-unbounded-parameter-change", candidate, "parameter_selection_has_no_authorized_envelope")
    candidate = copy.deepcopy(policy)
    candidate["autonomy"]["enabled_tiers"].remove("A3_PUBLIC_DISTRIBUTION")
    check("POL-004-publish-without-tier", candidate, "publication_tier_missing")
    candidate = copy.deepcopy(policy)
    candidate["lifecycle"] = "active"
    check("POL-005-no-fabricated-identities", candidate, "active_role_identity_missing")
    candidate = copy.deepcopy(policy)
    candidate["lifecycle"] = "active"
    for name in ("producer", "verifier", "publisher", "policy_evaluator"):
        candidate["identities"][name] = "test-only-shared-actor"
    check("POL-006-separate-role-ids", candidate, "active_role_identities_not_distinct")
    candidate = copy.deepcopy(policy)
    candidate["lifecycle"] = "active"
    candidate["verification"]["lean_version"] = "4.19.0"
    check("POL-007-no-old-comparator-success", candidate, "active_profile_requires_supported_lean_4_35_or_later")
    return cases


def schema_cases(schema: dict[str, Any], policy: dict[str, Any]) -> dict[str, Any]:
    try:
        from jsonschema import Draft202012Validator
    except ImportError as error:
        raise RuntimeError(
            "--validate-schema requires jsonschema; default model checks use only the standard library"
        ) from error
    Draft202012Validator.check_schema(schema)
    validator = Draft202012Validator(schema)
    cases = []

    def check(name: str, candidate: dict[str, Any], expected_valid: bool) -> None:
        errors = sorted(validator.iter_errors(candidate), key=lambda item: str(item.path))
        observed_valid = not errors
        cases.append(
            {
                "id": name,
                "passed": observed_valid is expected_valid,
                "expected_valid": expected_valid,
                "actual_valid": observed_valid,
                "error_count": len(errors),
            }
        )

    check("SCH-001-inert-example-valid", policy, True)
    candidate = copy.deepcopy(policy)
    candidate["lifecycle"] = "active"
    check("SCH-002-draft-cannot-activate-by-flag", candidate, False)
    candidate = copy.deepcopy(policy)
    candidate["contract"]["postcondition_weakening_allowed"] = True
    check("SCH-003-no-weakening-switch", candidate, False)
    candidate = copy.deepcopy(policy)
    candidate["producer_override"] = True
    check("SCH-004-unknown-policy-field", candidate, False)
    candidate = copy.deepcopy(policy)
    candidate["publication"]["allow_release_without_independent_receipt"] = True
    check("SCH-005-independent-receipt-mandatory", candidate, False)
    candidate = copy.deepcopy(policy)
    candidate["budget"]["reset_daily_counter_on_requeue"] = True
    check("SCH-006-no-requeue-budget-reset", candidate, False)
    candidate = copy.deepcopy(policy)
    candidate["data"]["discard_user_data_on_regeneration_allowed"] = True
    check("SCH-007-data-not-disposable", candidate, False)
    return {"status": "EXECUTED", "cases": cases, "passed": all(c["passed"] for c in cases)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, help="Optional JSON report path")
    parser.add_argument(
        "--validate-schema", action="store_true", help="Also run optional jsonschema structural checks"
    )
    args = parser.parse_args()

    machine = read_json(ROOT / "state-machine.json")
    acceptance = read_json(ROOT / "acceptance-cases.json")
    policy = read_json(ROOT / "policy.example.json")
    validate_machine(machine)
    results = [run_case(machine["machines"], case) for case in acceptance["cases"]]
    if len({case["id"] for case in results}) != len(results):
        raise ValueError("Duplicate acceptance case IDs")
    policy_results = policy_cross_field_cases(policy)
    schema_result: dict[str, Any] = {"status": "NOT_RUN_OPTIONAL", "passed": None, "cases": []}
    if args.validate_schema:
        schema_result = schema_cases(read_json(ROOT / "policy.schema.json"), policy)
    passed = all(case["passed"] for case in results + policy_results)
    if schema_result["status"] == "EXECUTED":
        passed = passed and schema_result["passed"]
    hashed_files = [
        "architecture.md",
        "policy.schema.json",
        "policy.example.json",
        "state-machine.json",
        "acceptance-cases.json",
        "model_check.py",
    ]
    report = {
        "schema_version": "1.0.0",
        "status": "EXECUTED_PASS" if passed else "EXECUTED_FAIL",
        "execution_scope": "DESIGN_STATE_MODEL_AND_POLICY_STRUCTURE_ONLY",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "python_version": sys.version.split()[0],
        "command": "python autonomy/model_check.py" + (" --validate-schema" if args.validate_schema else ""),
        "input_sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in hashed_files},
        "model_case_count": len(results),
        "model_cases_passed": sum(case["passed"] for case in results),
        "policy_cross_field_case_count": len(policy_results),
        "policy_cross_field_cases_passed": sum(case["passed"] for case in policy_results),
        "schema_checks": schema_result,
        "limitations": [
            "Fixture booleans are assumptions, not authenticated facts.",
            "No Lean compiler or kernel was invoked by this model check.",
            "No signature, sandbox, identity separation, or budget enforcement was actually exercised.",
            "No repository was published and no production environment was changed.",
            "Future stateful runtime cases do not implement or validate real migrations.",
            "Passing schema validation does not grant authority or establish runtime evidence.",
            f"The {len(acceptance['required_real_integration_tests'])} required real integration scenarios remain NOT_EXECUTED by this harness.",
        ],
        "model_cases": results,
        "policy_cross_field_cases": policy_results,
    }
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(
        f"{report['status']}: {report['model_cases_passed']}/{len(results)} design model cases; "
        f"{report['policy_cross_field_cases_passed']}/{len(policy_results)} cross-field policy cases; "
        f"schema checks {schema_result['status']}."
    )
    print("MODEL ONLY: no Lean verification, authorization, publication, or deployment was performed.")
    for case in results + policy_results + schema_result["cases"]:
        if not case["passed"]:
            print(json.dumps(case, ensure_ascii=False), file=sys.stderr)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
