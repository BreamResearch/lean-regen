# Lean Regen

BreamResearchの独立したOSSプロジェクトです。予約枠の実装を変更したとき、成功・拒否の条件と数量の保存をLean証明支援系で再検査できます。登録は不要です。

Lean Regen is an experimental, open-source starting point for regenerating software from durable business contracts. It combines a Lean-based development skill, a reproducible pure-core example, and a concrete specification for autonomous dependency updates and evidence-based releases.

**Current state:** the bundled sequential inventory model has 14 checked Lean theorems. The independent verification service, unattended update controller, runtime bridges and managed service remain implementation milestones. See [STATUS.json](STATUS.json) and the [fresh reproduction record](validation/p0a-20261124T0756Z/summary.json). This is not a claim that an entire production application is bug-free.

No account is required for the local tools, proofs or documentation. The source is available under Apache-2.0; see [LICENSE](LICENSE). Independent verification, export and self-hosting remain part of the free product.

## Try the local example

Requirements: Python 3.11+, an explicitly trusted Lean/Lake **4.19.0** installation for this historical example, and a fresh working directory. It uses Lean/Std without external Lake packages. Get the pinned release from [the official Lean release page](https://github.com/leanprover/lean4/releases/tag/v4.19.0); do not silently substitute a different compiler.

**macOS 27 on Apple Silicon.** Before running the demo, select an installed Xcode toolchain with a working `xcrun --find ld`. In the shell used for the demo and mutation checks, set these two variables. They select Apple's linker for the native executable and target macOS 27.0. This configuration passed on macOS 27.0.1 with Xcode 27.2 (27B52). The official Lean 4.19.0 compiler and Lake distribution were used unchanged. Linux users can proceed directly to the Python commands.

```bash
export CCC_OVERRIDE_OPTIONS='+--ld-path=/usr/bin/ld'
export MACOSX_DEPLOYMENT_TARGET=27.0
```

```bash
python3 scripts/leanregen.py status
python3 scripts/leanregen.py check-upstream
python3 scripts/leanregen.py doctor --tool-bin /absolute/path/to/lean-4.19.0/bin
python3 scripts/leanregen.py demo \
  --tool-bin /absolute/path/to/lean-4.19.0/bin \
  --workdir ../lean-regen-demo-001
```

The last command creates a synthetic project, freezes its candidate contract, runs the historical checker and retains the verification report, per-stage logs and the hashed native demo binary. It does not grant customer acceptance, an independent-verification label, a manual-review waiver, or deployment authority. Read the output report's scope.

To inspect a source release offline, verify the accompanying `SHA256SUMS`, extract the ZIP and run the commands above from its top-level folder. The first two commands need only Python. The demo needs the native compiler and linker for the platform. OpenSSL 3 is used by the optional historical signature tests.

## What the example proves

Positive reservations within availability and releases within reserved quantity have the specified exact effects. Disallowed operations return an unchanged state. Capacity is conserved across every finite sequence in the model. The example checks useful success as well as rejection, so rejecting every request is not an acceptable implementation.

It does not model named reservation owners, authorization, persistence, concurrent requests, retry deduplication, crashes or a complete Web service. The native demo's behavior additionally relies on compiler/runtime/platform assumptions.

## Architecture and next work

- [Product specification](docs/SYSTEM_SPEC_JA.md) and [strategy](docs/PRODUCT_STRATEGY_JA.md)
- [Autonomous lifecycle](autonomy/architecture.md) and [specification evolution](docs/SPEC_EVOLUTION_JA.md)
- [Proof and runtime scope](docs/PROOF_AND_RUNTIME_SCOPE_JA.md)
- [Implementation milestones](EXECUTION_PLAN.json)
- [Public release runbook](docs/GITHUB_RELEASE_RUNBOOK_JA.md)
- [Free use and optional managed operation](docs/GROWTH_AND_MONETIZATION_JA.md)

The generator proposes; an independent verifier checks; an external policy controls permissions and budgets; a publisher ships only the bound artifact. These separations must be enforced by runtime credentials and infrastructure. A prompt cannot enforce them by itself.

## Using the skill

`packages/lean-verified-sdlc/` contains the unmodified v1.0.0 skill and its eight lifecycle modules. `UPSTREAM_PROVENANCE.json` records every file hash. Read its `SKILL.md`, or import the folder with your agent's supported skill installation process. This repository does not automatically install or register a skill.

## Contributing and security

See [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md). Keep contract, proof and runtime claims explicit. Use synthetic data in issues. Do not publish credentials or private customer code. The working project name is provisional; no affiliation with Lean, Anthropic, OpenAI or Theorem is implied.
