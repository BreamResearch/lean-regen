# External acceptance and review-substitution evidence

## Claim and trust boundary

Pure-core proof can replace specified manual implementation checks when accepted
engineering policy permits. Intent, specification adequacy, assumptions, runtime
boundaries and operational fitness remain separate. No shipped file grants an
unconditional system-wide review exemption.

Ordinary kernel audit is useful in a cooperative trusted codebase. For unreviewed
AI-generated proofs, the external path requires independent exact-statement checks
against a protected challenge. Current Lean documentation describes `comparator`
and paranoid mode. The historical 4.19.0 starter does not include that tool.
Validate a compatible pinned environment before using that path; no comparator
success is claimed for this distribution.

## External interface

1. The requirements authority approves the exact contract digest, records real
   acceptance, and protects the baseline and policy.
2. An independent verifier runs compatible exact-statement and kernel checks,
   audits axioms, confirms accepted assumptions and exact artifact binding, and
   retains actual checker logs.
3. That verifier signs a receipt with its authority-controlled Ed25519 key.
   The producer cannot access that key or modify the trusted policy.
4. `evaluate_release.py` authenticates the receipt and compares current contract,
   source, local report, artifact, scope, and required checker results.
5. Success permits only the narrow review substitution under that policy. It does
   not deploy or establish end-to-end correctness.

Use the inert `trusted-policy.example.json` and `verifier-receipt.example.json`
templates. Their draft/null/false fields cannot pass. Signatures authenticate an
issuer; that issuer must actually perform the stated checks. This package does not
provide a fictional verifier service or a signing key.

```bash
python3 PATH_TO_SKILL/scripts/evaluate_release.py \
  --project PROJECT_DIRECTORY --baseline AUTHORITY_BASELINE \
  --report ACTUAL_LOCAL_REPORT --trusted-policy AUTHORITY_POLICY \
  --receipt INDEPENDENT_SIGNED_RECEIPT --artifact EXACT_RETAINED_ARTIFACT \
  --out NEW_DECISION_PATH
```

The policy and public key must be outside the project; real permissions must enforce
this convention. The only implemented waiver scope is `verified_pure_core_logic`.

## Receipt semantics

Sign UTF-8 JSON serialized with sorted keys, compact separators, `ensure_ascii=false`,
and no trailing newline. Bind the following fields:

- schema and project identity;
- accepted contract, current source, report and artifact SHA-256;
- exact-statement matching and independent kernel results;
- allowed axioms and acceptance of stated assumptions;
- `checker_profile=comparator_paranoid` and narrow waiver scope;
- checker log digest and independent verifier identity.

Do not supply a producer-generated key and call it independent. Ephemeral keys in
unit tests validate the interface only and are never production evidence.

## CI guidance

Pin the acceptance job from an authority-controlled source. Mount target and policy
read-only. Separate producer, verifier and deployment identities. Bind exact source
and artifact to the result. Require the external decision in branch/deploy
protection rather than trusting a green field in an agent-editable job. Optional
AI hooks and editable workflows are insufficient as the sole release boundary.

If independent evidence, customer acceptance or boundary evidence is absent, leave
this path `BLOCKED` while retaining all completed work. Name the missing item;
do not request redundant permissions or present a template as actual evidence.
