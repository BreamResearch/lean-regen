# 08 — Accept and explain the delivered assurance

Use this module when presenting a baseline for semantic acceptance, delivering an implementation, or assessing whether manual implementation review can be omitted for a specified component.

## Produce two connected views

Write a concise customer-facing acceptance record using `customer-acceptance.md` and a technical report using `assurance-report.md`. Both must identify the same artifact, requirement baseline, assumptions, and scope.

The customer view should answer:

1. What behavior was agreed, including important positive and negative examples?
2. What has been built, and which operations are included?
3. Which properties were mechanically proved, and about which code or model?
4. Which properties were tested, accepted by observation, assumed, or left unresolved?
5. What changes or environmental failures would invalidate the stated guarantee?

Avoid making the customer read Lean to understand the guarantee. Preserve exact theorem names and evidence locations in the technical view for independent checking.

## Report statuses accurately

| Status | Meaning |
| --- | --- |
| Draft | Meaning or scope is still provisional. |
| Not executed | A required check was not run; explain the actual blocker. |
| Failed | The check ran and did not meet its criterion; distinguish false claim from incomplete proof work. |
| Proved in the stated model | The fixed theorem was checked under the declared trust and axiom policy. |
| Tested | The stated experiment passed for the recorded cases and environment. |
| Assumed | The property is a precondition or trusted environmental contract, not a theorem established by this work. |
| Accepted | A real authorized party or standing policy accepted the identified business meaning or release decision. |

These are explanations, not substitutes for the machine-readable gate statuses defined by the orchestrator. Use the orchestrator's exact status vocabulary in its manifests.

## Review-waiver decision

Formal verification can replace manual inspection for a specific implementation-correctness question when the accepted theorem fully captures that question and applies to the delivered implementation. Establish all of the following before recommending such a waiver:

- The business meaning and boundary are accepted for the exact baseline.
- Required properties are explicitly mapped to successful proof obligations.
- The implementation being delivered is the one to which those obligations apply.
- No unchecked path can bypass the verified transition for the claimed operation.
- The axiom and trusted-code-base policy is satisfied.
- Necessary compilation, adapter, storage, concurrency, and external-service assumptions are stated and supported according to policy.
- The waiver is authorized by the customer's applicable engineering policy or explicit instruction.

Specify what question the waiver covers, which components it covers, and which activities remain. A functional-correctness proof does not by itself discharge usability, performance, side-channel, dependency, deployment, or operational review. Include these only if they are relevant to the requested scope; do not invent unrelated approval gates.

If the conditions are not met, deliver the completed work and a precise remaining gap. Do not call an agent's own favorable assessment a customer approval or an independent proof certificate.

## Evidence integrity

Bind every outcome to the baseline and artifact digests or immutable revisions, exact commands, tool versions, exit status, and retained logs. A prose statement that “Lean passed” is insufficient when no check was run or when a different artifact was checked.

Ensure that every in-scope requirement has an evidence disposition. A coverage percentage is not a correctness probability. Avoid aggregating a mix of proofs, tests, assumptions, and exclusions into a misleading single “verified” score.

Keep the source-to-runtime distinction visible: a theorem about a Lean function, a theorem about a translated model, and differential testing against a reference implementation provide different evidence.

## Delivery language

Use language such as:

> The listed properties have been proved for the identified implementation/model under the stated conditions. The attached report identifies tested integration behavior and remaining environmental assumptions. Manual implementation review for the specified properties may be omitted only under the recorded waiver policy.

For a package that contains only workflow instructions or an unexecuted starter, say so. Installing this skill, generating code, and completing a proof are distinct events.
