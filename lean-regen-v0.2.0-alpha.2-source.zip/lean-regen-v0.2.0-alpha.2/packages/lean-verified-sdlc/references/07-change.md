# 07 — Evolve a verified system without losing its contract

Use this module for requirement changes, refactoring, new parameters, dependency updates, data migration, fixes, and changes to deployment adapters. Reuse established authorization; do not ask again for ordinary implementation work already requested.

## Classify the change

| Change | Required treatment |
| --- | --- |
| Parameter within an already quantified admissible range | Prove or check that the chosen value satisfies the theorem's parameter constraints; rerun applicable gates. |
| Refactoring with unchanged behavior and baseline | Keep the specification fixed; prove the new implementation satisfies it. |
| New business behavior or exception | Revise the requirements and specification deliberately; record acceptance provenance for the new meaning. |
| Dependency or toolchain update | Recheck semantics, axioms, compilation, compatibility, and the evidence tied to the old versions. |
| Persistence, concurrency, authentication, or API change | Reassess model correspondence and environment assumptions, even when the pure core is unchanged. |
| Data or schema migration | Specify a state relation from old to new representation; preserve required invariants and define failure/recovery behavior. |
| Verification or acceptance policy change | Treat as an assurance-policy change with its own authorized decision, not as a way to pass a failing release. |

## Perform impact analysis

1. Record the requested outcome and the source authorizing the change in `change-request.md`.
2. Follow traceability from affected requirements and assumptions to definitions, implementations, theorems, adapters, tests, reports, and customer examples.
3. Determine whether the existing general theorem covers the new case. Do not infer reuse solely from similar syntax or a matching function name.
4. Preserve the old accepted baseline and report as historical evidence. They remain statements about the old artifact, not certificates for the new revision.
5. Implement and prove the candidate against the applicable baseline. Keep failed attempts visible in working logs without presenting them as release evidence.
6. Run the required checks and issue a report bound to the resulting artifact and baseline.

## Handle specification changes explicitly

Do not edit a requirement, expected result, precondition, or assumption to hide an implementation failure. If a requirement is wrong or underspecified, explain the mismatch, propose a correction with examples, and obtain only the semantic decision not already covered by the user's instruction.

Record what guarantee was added, removed, or weakened. If the customer authorizes a weaker guarantee, report it plainly; do not preserve the former assurance label by changing its meaning.

## Handle failures and migrations

For a failure under the claimed conditions, preserve a reproducing input or execution trace and classify it as a specification defect, proof/assurance defect, implementation-model mismatch, broken environmental assumption, or uncovered requirement. Avoid assuming in advance that the proof or customer is at fault.

For migrations, identify legal pre-migration states, the migration function or protocol, the post-migration invariant, information-loss policy, and failure atomicity. A valid new empty state is not evidence that existing production state can be migrated safely.

Only perform external deployment, destructive migration, or rollback under the authorization applicable to the actual action. The existence of a proof is not authorization to alter a live system.

## Completion

Update traceability, environment contracts, customer examples, and the assurance report. Invalidate any release status whose artifact, baseline, toolchain, or environment binding no longer matches. If a required check cannot run, keep the candidate unverified at that gate and identify the concrete remaining work.
