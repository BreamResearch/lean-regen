# Execution runbook

## Requirements

- Python 3.11 or newer, standard library for operational scripts (including TOML parsing).
- A compatible fixed Lean/Lake pair. The example was tested with
  `leanprover/lean4:v4.19.0`, not advertised as the latest version.
- OpenSSL with Ed25519 support for external signed-receipt evaluation only.
- PyYAML/jsonschema are optional authoring validators, not runtime dependencies.

Use the official Lean installation process. Record exact toolchain and dependencies;
never silently substitute a compiler. The runnable profile supports Lean/Std with
no third-party Lake packages. For Mathlib, Aeneas or other backends, create and
validate an appropriately pinned trusted runner and update the baseline. Do not
label those paths tested merely because the small example passes.

## Reproduce the complete example

Resolve `SKILL_DIR` to the directory containing `SKILL.md`. Choose a new project
directory and separate baseline directory. The following variables are examples.

```bash
SKILL_DIR=/absolute/path/to/lean-verified-sdlc
PROJECT_DIR=/absolute/path/to/inventory-project
BASELINE_FILE=/absolute/path/to/authority/inventory-v1.json
LEAN_BIN=/absolute/path/to/lean-4.19.0/bin
python3 "$SKILL_DIR/scripts/new_project.py" --dest "$PROJECT_DIR"
python3 "$SKILL_DIR/scripts/freeze_contract.py" \
  --project "$PROJECT_DIR" --out "$BASELINE_FILE"
python3 "$SKILL_DIR/scripts/verify_project.py" \
  --project "$PROJECT_DIR" --baseline "$BASELINE_FILE" \
  --tool-bin "$LEAN_BIN" --out "$PROJECT_DIR/evidence/core-v1.json"
```

The first command creates a draft example. The second records candidate bytes,
not approval. The third builds a clean source copy, validates exact expected
theorem types, audits transitive axioms, checks concrete Lean examples, and runs
a native smoke demo. It retains the exact demo binary and SHA-256 alongside the
evidence. That smoke result is not a proof of compiler or OS correctness.

## Status vocabulary

| Status | Meaning |
|---|---|
| `DRAFT_PROJECT_CREATED` | Example and editable worksheets exist |
| `CANDIDATE_LOCK_CREATED` | Content hashes exist; acceptance is separate |
| `BLOCKED` | A required tool, condition, proof, or evidence item is unavailable or failed |
| `CORE_KERNEL_CHECKED` | Registered pure-core obligations passed the ordinary Lean checking path |
| `SCOPED_CORE_REVIEW_WAIVER_ELIGIBLE` | An external approved policy and authenticated independent receipt support substituting evidence for manual review of specified pure-core logic only |

`verify_project.py` exits 0 for local kernel-check success, not release readiness.
`evaluate_release.py` exits 0 for scoped eligibility, never deployment authorization.
Failure paths return nonzero. Name these as separate jobs in CI.
Each evidence output is reserved exclusively. Use a new path per invocation; never
overwrite a concurrent run. If a crashed process leaves a `.lock`, inspect the
recorded process and partial logs before an operator removes it, or use a new path.

## Protect the accepted target

`assurance.json` registers contract files, exact challenge and audit files, theorems,
requirement links, and assumptions. The candidate lock hashes those files. The
verifier compares each frozen hash and rejects source changes during its run.

An external path is a structural convention, not an access-control boundary.
An administrator must prevent the producer from changing accepted baselines,
gate scripts, policies, trusted dependencies, and verifier keys. Use a separate
authority-controlled repository or service and a restricted runner identity.
Present concrete requirements, examples and claim before recording acceptance.

## Restrictions and failures

- Missing Lean, wrong version, unknown theorem, missing audit, extra axioms,
  changed challenge, or compilation failure must remain `BLOCKED`.
- Lexical preflight excludes incomplete proofs and selected unsafe/metaprogramming
  features. It is not a complete Lean parser or an adversarial-proof validator.
  A broader profile needs deliberate engineering, not removal of a failing check.
- Integration tests never upgrade an unproved correspondence into a theorem.
- The fresh temporary copy prevents stale `.olean` reuse, not hostile code execution.
- Logs must use synthetic or appropriately redacted data.
- Snapshots exclude `.git`, `.lake`, `evidence`, `reports`, `__pycache__`, and `.venv`.
  Do not place source, specification, or executable policy in those directories.

## Extend the example

Change domain model and independent specification first. Add useful-success and
failure examples, define exact theorem statements, and obtain missing semantic
decisions. Create a new versioned baseline, then implement and prove against it.
Preserve old baselines and evidence for comparison.
