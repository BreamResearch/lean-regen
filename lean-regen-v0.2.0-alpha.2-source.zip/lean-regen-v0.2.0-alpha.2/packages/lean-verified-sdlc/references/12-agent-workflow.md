# Agent orchestration and portable attachment use

## Roles

Use the eight modules as role-specific skills under one orchestrator. Load only
needed modules. Separate contexts improve critique but do not create independent
authority or filesystem isolation.

| Role | Inputs | Outputs | Cannot silently change |
|---|---|---|---|
| Requirements analyst | Customer statements and examples | Terms, exact behavior, ambiguities | Customer intent or acceptance |
| Contract author | Requirements | Formal target, challenge, traceability | Scope without a recorded change |
| Implementation/proof agent | Frozen target and code | Code, proofs, actual logs | Accepted target, assumptions, authority policy |
| Boundary engineer | Model and environment | Adapters, concurrency/failure evidence | Tests into mathematical claims |
| Independent verifier | Protected target and exact source/artifact | Genuine validation and signed receipt | Missing checks into passing assertions |
| Delivery agent | Evidence and decisions | Report and handoff | Unproved boundaries into proof coverage |

Parallelize only after ownership/interfaces are clear. Provide producers immutable
contracts and scoped work areas. Give validation agents raw artifacts and tasks,
not expected conclusions. The customer supplies semantic decisions; routine
authorized engineering proceeds without repeated permission.

## Attachment mode

Attach the structured distribution or complete single-file attachment export.
Tell an agent with file/execution tools to read `SKILL.md`, inventory resources,
use the modules as needed, and reproduce the starter before adapting it. Text
attachment does not install Lean or grant tools. Without execution tools, prepare
requirements and code but explicitly leave proof execution blocked.

For folder-based skill registration, register the complete directory. `SKILL.md`
is the entry point, and relative scripts/references/assets must stay available.
Registering only the root text loses executable resources. Other products have
different tool permissions and packaging rules; do not invent vendor behavior.

For a custom-agent instruction field use `agents/portable-agent-instructions.md`
and attach the full resources. The adapter routes work; it cannot replace a real
compiler or protected verifier.

## Customer interaction

State inferred goal, sources and claim scope. Reuse known information. Ask at most
three consequential questions at a time with concrete examples. Continue drafting
independently decidable pieces; do not ask the customer to design proofs or tactics.

## Context recovery

Persist project path, exact baseline digest, decisions, unresolved semantic issues,
command results and next gate. Resume from these artifacts and current evidence.
An agent's recollection of a previous success is not a certificate.

## Delivery language

State which properties of which version passed which checks under which assumptions.
Call the starter ordinary-kernel checked. Name the properties/component covered by
an authorized review substitution. Explain remaining requirements and boundaries.
Do not promise arbitrary automatic proofs, unconditional absence of bugs, or
universal elimination of manual review.
