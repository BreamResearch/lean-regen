# Architecture: choose a proof boundary that reaches the implementation

## Outputs

Produce an architecture decision, a state/command/error model, an interface contract for every boundary, and a trusted-computing-base inventory. Record these in the project evidence alongside the requirement IDs. The patterns below are design recommendations for this skill, not claims that an arbitrary implementation is already verified.

## Select an implementation route

| Route | Required evidence | Permitted claim |
| --- | --- | --- |
| Lean core executed directly | Theorems about the actual exported core functions; identified build and executable | Source-level functional correctness of that core under recorded assumptions |
| Other-language code translated to Lean | Supported source subset, pinned translator, correspondence assumptions, theorem about the generated model | Correctness relative to the translator and supported semantics |
| Lean reference model plus a separate implementation | Proved model and recorded differential/integration tests | Proved reference model; tested implementation correspondence |

Prefer a small directly executed Lean core when starting a project. A separately rewritten TypeScript, Python, SQL, or Rust version does not inherit the proof merely because it implements similar pseudocode. Never upgrade the third route to an end-to-end formal claim without additional correspondence evidence.

Lean's kernel checks proof terms; compilation subsequently produces executable code. Running verified Lean source therefore retains compiler, runtime, and linked-code assumptions. Record those assumptions explicitly. [S4, S6]

## Model business state before storage

1. Define actors, resources, quantities, identity, units, and permissible state transitions.
2. Define all outcomes, including rejection and retryable failure. Specify which fields may change and which must remain unchanged.
3. Separate input validity, authority, current-state eligibility, and environmental availability. They are different preconditions.
4. Give each successful command an exact postcondition. Invariants alone also admit implementations that reject every request.
5. Define the set of reachable states from a legitimate initial state. Supply at least one concrete initial state and a successful trace.
6. For parametric templates, state the configuration constraints and prove the generic theorem over all admissible configurations.
7. State the scope of time: logical sequence, wall clock, business date, timezone, or trusted external timestamp. Do not silently exchange them.

Use mathematical integers or natural numbers only when their semantics match the implementation. For bounded machine integers, establish bounds, overflow behavior, and conversion correctness. For money, define currency, minor units, rounding location, tie rules, and allocation of remainders.

## Compose contracts

For a call from component A to B, establish that A's output implies B's precondition. Preserve shared invariants and reject unauthorized writers. Account for migrations, imports, administrative APIs, repair jobs, and batch jobs that can change the same state.

Introduce a state relation `R(databaseState, modelState)` for persistent systems. Explain how initialization establishes it and how each committed transaction preserves it. State the atomicity/isolation behavior on which that argument depends. If the adapter is only tested, label this relation as tested or assumed, never proved.

For external actions, represent both the decision and the effect lifecycle. A useful model distinguishes pending intent, attempted delivery, acknowledged result, and reconciled outcome. Choose the actual states from the service contract; do not assume that every provider offers the same guarantees.

## Record the boundary inventory

For each entry, record its exact version or identity, the assumed behavior, evidence, owner, and consequence of violation:

- Lean logic, kernel/checker, compiler, runtime, and dependencies.
- Translator or code generator when used.
- Parsers, serialization, schema validation, and numeric conversions.
- Identity provider, authentication context, authorization enforcement point.
- Database transaction semantics, durable storage, clocks, and scheduler.
- External services and their retry/deduplication contract.
- Build environment, packaging, artifact provenance, and deployment identity.

Do not equate a proof about policy evaluation with enforcement of that policy on every API route. Model or separately verify the route-to-enforcement connection.

## Protect the acceptance target

Maintain the accepted specification, theorem obligations, input domain, dependency policy, and gate policy as an acceptance baseline. Link it to actual customer acceptance evidence; a locally generated hash is not customer acceptance.

Keep that baseline and its verification policy outside the implementation producer's write authority in the real execution environment. Use the organization's existing protected repository, CI identity, or artifact service. A prompt saying "do not edit" and a digest in the same writable folder do not establish this separation.

If the environment cannot enforce separation, continue implementation and proof work but state that the integrity of the baseline remains an assumption. Do not invent an access-control configuration or claim one has been applied.

## Exit evidence

- Every formal claim names an implementation route and a concrete target function or transition system.
- Every production boundary has a correspondence argument, a test plan, or an explicit assumption.
- The initial state and at least one intended success path are realizable.
- Business owners can recognize the behavior in examples without reading Lean.
- Remaining assumptions and excluded behaviors are visible in the assurance report.

Sources: [S4–S6](09-sources.md). The architecture workflow and tables are the pack's proposed engineering method.
