# Integration and release: preserve the proof's meaning in production

## Objective

Connect the proved core to real inputs, persistent state, identities, and external effects. State which links are proved, tested, or assumed. An unproved adapter prevents a whole-system formal-correctness claim even when its unit tests pass.

## Boundary obligations

| Boundary | Questions and required evidence |
| --- | --- |
| Parsing | Does decoding preserve the intended value, reject malformed input, and distinguish missing from zero/empty? |
| Numeric representation | Do units, ranges, signs, rounding, serialization, and machine arithmetic match the formal model? |
| Authentication | What establishes identity? How does authenticated identity reach the authorization check? |
| Authorization | Do all protected entry points enforce the proved decision, including bulk/admin paths? |
| Persistence | What atomicity, isolation, durability, and conflict behavior does the model assume? |
| Retry | What constitutes the same request, and is its identity bound to the same payload? |
| External effects | How are timeout, unknown result, delayed acknowledgement, and reconciliation represented? |
| Time | What clock, timezone, monotonicity, expiry, and ordering assumptions are required? |
| Migration | Does moving existing data establish the new initial-state invariant? |
| Packaging | Which exact source/build/artifact is released, and how is that identity checked? |

Assign a concrete theorem, executed test, contractual assumption, or unresolved status to each applicable row. Do not substitute a generic checklist tick for evidence.

## Concurrency and failure traces

Derive relevant traces from the application's contract. Examples to consider when applicable:

1. Two reservations read the final available unit concurrently.
2. A client retries after the server committed but before the client received a reply.
3. A process crashes between recording an intent and executing an external effect.
4. The external effect succeeds while the response is lost.
5. An identity is revoked or a permission changes between decision and use.
6. Old and new application versions operate during a rolling migration.

For each selected trace, show a model argument and the corresponding implementation mechanism. If a database primitive supplies a needed guarantee, state the precise primitive/configuration and verify its use. Do not assume that serial execution of a pure function establishes serializable database behavior.

An idempotency key alone is not a universal exactly-once guarantee. Specify its uniqueness scope, payload consistency, retention period, atomic recording, and the provider's behavior. If a provider cannot satisfy the needed premise, revise the workflow or reduce the claim explicitly.

## Performance and liveness

A terminating core function does not prove that a distributed workflow finishes. Define fairness, retries, eventual service recovery, and resource bounds before claiming eventual completion. Measure performance requirements when they are not formally established; retain the measurement conditions and limits.

Functionally correct results do not by themselves establish constant-time behavior, absence of information leakage, user-interface usability, resilience under overload, or legal correctness. Include only those concerns relevant to the customer's stated requirements, and give each its own evidence route.

## When a manual implementation review may be waived

The project's owner may choose to replace repetitive manual review of specific functional properties with a verification gate when all of these hold:

- The business specification and excluded behaviors have been accepted with recorded evidence.
- The relevant properties are formalized without vacuous preconditions.
- The actual implementation is bound to the proved statements.
- The agreed proof-integrity profile passed for the exact candidate.
- Runtime correspondence and environmental assumptions are established at the claimed scope.
- The gate and acceptance baseline are controlled independently of the implementation producer.
- Applicable organizational review requirements permit that substitution.

Record the exact properties and component for which the waiver applies. This does not waive acceptance of the business meaning, changes to assumptions, unresolved boundary behavior, or policies the customer is obligated to follow. Reuse an existing authorized review policy; do not manufacture a new permission checkpoint for ordinary implementation work.

If these conditions are not met, state which ones remain open. Do not replace evidence with a human-sounding assurance statement. Keep delivering the verified subset and the remaining work clearly.

## Release and operation

Bind the release artifact to the checked source, baseline, toolchain, dependencies, and report. Ensure the actual deployment uses that artifact and the documented configuration. Deployment authorization follows the user's existing instructions and environment policy.

Monitor the assumptions that can change in operation: schema/configuration version, dependency versions, service contract, clock behavior, and data-invariant violations. A changed assumption can invalidate applicability of an unchanged proof; invoke change control and reverify the affected obligations.

Anthropic describes planning, implementation, CI, deployment, monitoring, and governance as continuing stages, with humans still responsible for key decisions. Use that lifecycle organization without treating it as a formal correctness standard. [S1]

## Exit evidence

The acceptance report names the verified component, exact revision, formal properties, residual assumptions, boundary evidence, unresolved requirements, and any scoped manual-review substitution. Its result must be reproducible by the designated verifier.

Sources: [S1, S4, S7](09-sources.md). Boundary scenarios and waiver criteria are proposed engineering policy, not a certification statement.
