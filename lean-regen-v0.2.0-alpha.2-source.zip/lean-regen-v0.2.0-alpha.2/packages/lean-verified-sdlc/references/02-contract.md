# 02 — Establish and freeze the formal contract

Use this module after discovery and before claiming that implementation work has a fixed target. The output is a versioned agreement about behavior, scope, assumptions, and acceptance evidence.

## Construct a contract with several obligations

For each operation, specify:

1. **Domain and initial state**: admissible values and constructible initial conditions.
2. **Precondition**: what must hold before an operation can succeed.
3. **Postcondition**: the exact relation between input, output, and new state.
4. **Frame condition**: what the operation must leave unchanged.
5. **Rejection behavior**: error result and state/effect behavior on invalid input.
6. **Success obligation**: circumstances in which a valid request is accepted.
7. **Invariant preservation**: the global relation maintained by every allowed transition.
8. **Progress obligation**: termination or eventual completion, if required, with explicit environmental assumptions.
9. **Observable effects**: external calls, persisted events, authorization decisions, and their correspondence to the model.

Avoid proving only a type-level tautology, such as nonnegativity of a natural number, when the intended property is resource conservation or correct acceptance. Do not make success unconditional when the system depends on a service that may be unavailable.

## Keep the specification independent of the implementation

Define the intended behavior before proving the candidate implementation. The specification may be executable, relational, or both. Its purpose is to constrain the implementation.

- A theorem about a reference model does not establish a different implementation unless a correspondence is proved or the narrower assurance class is reported.
- A theorem comparing an implementation with itself is not a functional-correctness argument.
- A theorem about a helper is insufficient when the shipped entry point bypasses that helper.
- A proof of safety alone does not establish successful processing or progress.
- A finite test suite does not discharge a universal theorem.

Record exact declaration names and the statement each theorem is intended to establish. The proof author must not weaken a theorem, redefine its predicates, add an assumption, or substitute a different function merely to obtain a successful build.

## Check satisfiability and meaningful strength

Construct at least one witness for each important input class and initial-state class. Show that the conjunction of assumptions admits intended executions. For infinite or complex systems, record which satisfiability questions remain unresolved rather than claiming complete consistency from a few examples.

Challenge the contract with intentionally incorrect behaviors: always reject, leave everything unchanged, update the wrong resource, duplicate a side effect, or use an incorrect rounding rule. Determine whether the fixed requirements exclude each relevant behavior. A proof attempt failing is not itself proof that the theorem is false; distinguish a counterexample, a compiler error, and incomplete proof automation.

## Freeze semantics, not merely the displayed theorem name

The accepted baseline must bind at least:

- The requirement set and its version.
- Formal specification files and the definitions on which their meaning depends.
- The theorem/obligation registry and assurance boundary.
- Environment assumptions and accepted exclusions.
- Toolchain and dependency versions used to interpret the specification.
- The applicable acceptance and verification policy.

Record digests and exact source revisions using the provided baseline tooling. Do not claim that a digest authenticates who approved an artifact; it only identifies bytes. Record acceptance provenance separately.

Pin dependencies and imports. Changing an imported definition, notation, typeclass instance, or model can change the meaning of an unchanged-looking statement. A changed semantic dependency requires impact analysis and, where meaning changes, a new baseline.

## Obtain only the acceptance that is actually missing

Prepare a concrete summary with examples before asking for a decision. Honor an explicit acceptance already present in the current session or a valid standing policy covering this exact class of changes. Record its source and scope.

The customer should resolve business meaning and accept the stated scope; they need not approve each tactic, lemma, refactoring, or build command. Continue reversible development within existing authorization.

Do not mark acceptance merely because the agent authored a plausible requirement set. If the customer has not accepted the baseline, retain a draft or provisional status and report proof results as being about that draft.

## Separate roles and capabilities

Use a specification custodian to maintain accepted meaning, a builder to propose code and proofs, and a verifier to check the candidate against the frozen baseline. These roles can be performed by one agent in a constrained workflow or by separate agents. Separate prompts alone are not an access-control boundary.

The verification environment must read the accepted baseline from a source the builder cannot silently replace. The authority to alter requirements, verification policy, trusted dependencies, and acceptance records belongs to the project owner or a previously authorized policy. Do not run untrusted build code with credentials that can overwrite that authority.

## Permissible claims

State a claim with its artifact revision, exact properties, quantified domain, model assumptions, proof-checking result, and runtime boundary. A useful form is:

> For artifact revision X, the listed theorems establish properties P over domain D under assumptions A. The report identifies which runtime components and external effects are covered by correspondence arguments, which are tested, and which are trusted.

“No bugs,” “review-free,” “secure,” and “production verified” are not default statuses. The narrower factual statement can be strong without extending beyond the evidence.
