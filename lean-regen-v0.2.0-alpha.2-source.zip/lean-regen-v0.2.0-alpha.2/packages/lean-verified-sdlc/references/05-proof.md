# Proof: check the fixed claim, not merely a green build

## Required evidence

For each formal requirement, bind its stable ID to a specific theorem statement, fully qualified theorem name, actual implementation entry point, input domain, assumptions, source digest, and verification evidence. Keep ordinary tests and manual acceptance evidence in separate fields.

Use the verification profile agreed for the project. The profiles below describe evidence strength; they are not automatic status strings and do not silently change the project's schema.

The bundled starter pins Lean 4.19.0. Its basic gate result `CORE_KERNEL_CHECKED` is evidence about the listed core obligations only. It does not imply end-to-end verification or authorization to waive manual review. The external release path remains `BLOCKED` until its required independent evidence is supplied.

## Baseline profile: trusted development environment

1. Check the accepted baseline against the trusted copy before building.
2. Rebuild the exact claimed target with the pinned toolchain and dependencies.
3. Explicitly reference every required theorem in a generated audit module; missing declarations must fail the run.
4. Run `#print axioms Fully.Qualified.theorem` for every obligation. Capture the actual output and classify all transitive dependencies. Never accept an empty log as an empty axiom set.
5. Require the actual theorem statement to be the accepted obligation about the actual implementation. A matching name alone is insufficient.
6. Record warnings, errors, timeouts, and unavailable checks without turning them into success.

Lean's standard logical axioms include `propext`, `Classical.choice`, and `Quot.sound`. `sorryAx` signals an unfinished or admitted proof. Native-evaluation axioms add a compiler dependency. Custom axioms can invalidate a claimed guarantee. [S5]

The pack's default policy is to reject unfinished proofs and unapproved custom/native axioms for required obligations. A project can explicitly adopt a different logical/TCB policy in its accepted baseline; it must then report that policy and cannot call the result axiom-free.

Prefer explicit hypotheses for environmental assumptions over declaring the desired behavior as a new global axiom. Show that the hypotheses can be jointly satisfied.

## Stronger profile: independent target and rechecking

Lean documents `lean4checker` for replaying stored results and `comparator` for comparing a submitted solution to a trusted challenge, including definitions and allowed axioms. `comparator --paranoid` can involve independent kernels. Use the procedure documented for the installed version; availability is not assumed. [S3]

The current online documentation may describe tools newer than the starter's Lean 4.19.0 environment. This pack does not claim that `comparator` was executed for that starter. To adopt it, select a compatible pinned environment and validate the comparison integration before adding that evidence to the release profile.

For unreviewed agent-generated proof packages, use an independently maintained acceptance challenge and an appropriately isolated verification environment when the assurance claim requires resistance to deliberate manipulation. A local regex scan plus `lake build` is not equivalent to that workflow.

Record the checker command, version, exact challenge, result, and all residual trust assumptions. If the chosen profile requires an unavailable checker, mark the profile unmet. Continue useful work; do not downgrade it silently or claim the missing check ran.

Comparator challenge files intentionally contain statement holes according to its documented format. Keep them in a separately designated trusted challenge location. They are not completed proof artifacts, and they must not be imported as admitted lemmas into the submitted implementation/proof package.

## Defeat vacuous success

Assess each obligation against the intended behavior:

- Are its preconditions satisfiable? Give a witness or a constructive argument.
- Can at least one normal request succeed?
- Does success imply the exact requested resource, amount, party, and state change?
- Does rejection preserve the required state?
- Are malformed inputs and error outcomes covered?
- Can forbidden traces actually be expressed by the model and shown impossible?
- Are all reachable states covered, rather than only a narrow example state?
- Are finite progress, termination, and eventual external completion distinguished?

Do not accept an implication from an impossible precondition or a theorem about an unused specification function as evidence about the deployed function.

## Targeted falsification of the specification

For a meaningful obligation, try one deliberately incorrect implementation in an isolated copy while keeping the accepted specification fixed. Examples include changing the wrong resource, subtracting the wrong quantity, or accepting a duplicate effect. The unchanged proof obligation should not be dischargeable for that implementation.

A failed proof attempt is useful diagnostic evidence, not a formal counterexample by itself. Where possible, exhibit a concrete input on which the mutated implementation violates the contract. Do not broaden testing once the concrete specification risk is resolved.

## Evidence integrity

The release verifier must obtain the accepted baseline and policy from a trust path that the implementation author cannot rewrite. It must independently compute hashes and execute checks; accepting a producer's edited `passed: true` report is insufficient.

This skill's local validation scripts help detect omissions and accidental inconsistency. They are ordinary software and are not claimed to be formally verified, tamperproof, or a complete defense against malicious proof-generating code.

Never confuse these observations:

| Observation | What it establishes |
| --- | --- |
| A source scan finds no forbidden tokens | A limited syntactic check passed |
| Build succeeds | The configured build completed under its toolchain |
| Required theorem checks succeed | Those recorded statements have accepted proofs under their dependencies |
| Fixed challenge and proof independently match | Stronger evidence of target identity and proof integrity |
| Source-to-runtime correspondence is established | The stated runtime boundary is connected to the proof under listed assumptions |

## Exit evidence

Produce a theorem-by-theorem report. Use precise wording: "The listed properties of this implementation were checked under these assumptions." Report missing, failed, and unexecuted obligations explicitly. Do not emit an unrestricted "zero bugs" or "review-free system" statement.

Sources: [S3, S5](09-sources.md). The profile policy, registry design, and falsification workflow are this pack's engineering choices.
