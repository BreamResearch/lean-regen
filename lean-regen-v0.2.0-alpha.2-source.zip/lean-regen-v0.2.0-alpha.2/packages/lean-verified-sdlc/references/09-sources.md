# Primary sources and method provenance

Accessed: 2026-11-24. Web documentation is mutable; use the documentation for the project's pinned tool versions. The pack combines the following public guidance with its own proposed requirements, traceability, assurance, and release workflow. It is not an official Anthropic, Lean, or NIST standard and does not claim compliance certification.

## S1 — Anthropic: AI-native SDLC

- Title: *How Anthropic secures its AI-native software development lifecycle*
- Author/date: Jason Clinton, July 21, 2026.
- URL: https://claude.com/resources/articles/how-anthropic-secures-its-ai-native-software-development-lifecycle
- Relevant point: The article organizes work around plan, code, test, deploy, monitor, and governance. It describes automation together with human ownership of important decisions.
- Application here: Keep requirements, proof, integration, release, and operation connected. Do not describe Anthropic's workflow as review-free or as mathematical proof.

## S2 — Claude Code: enforce outcomes with actual mechanisms

- Title: *Best practices for Claude Code*
- URL: https://code.claude.com/docs/en/best-practices
- Relevant point: Distinguish agent instructions from enforced controls, ask for actual verification evidence, and evaluate changes against the specification. Tool behavior depends on the product/version.
- Application here: Treat the agent's completion message and ordinary hooks as helpful workflow signals. Use an external acceptance gate whose policy and baseline the producer cannot rewrite when that integrity is required.

## S3 — Lean: validating a proof

- Title: *Validating a Lean Proof*
- URL: https://lean-lang.org/doc/reference/latest/ValidatingProofs/
- Relevant point: Validity of a proof and correctness of its intended meaning are separate questions. The documentation distinguishes ordinary checking, dependency inspection, replay, and comparison with a trusted challenge.
- Application here: Match the assurance profile to the trust model, bind proofs to the accepted target, and disclose unavailable checks.

## S4 — Lean: programming and trusted base

- Title: *Frequently Asked Questions*
- URL: https://lean-lang.org/faq/
- Relevant point: Lean supports both programming and verification. Executing compiled code or trusting a translation introduces assumptions beyond a small proof checker.
- Application here: Specify the execution route and keep compiler/runtime/translator assumptions visible.

## S5 — Lean: axioms and dependencies

- Title: *Axioms*
- URL: https://lean-lang.org/doc/reference/latest/Axioms/
- Relevant point: Proofs depend on their axioms; Lean exposes that dependency. Unfinished proofs and native evaluation must not be mistaken for ordinary kernel-only evidence.
- Application here: Audit every required theorem's transitive axiom dependencies under an explicit project policy.

## S6 — Lean: kernel and compiler are separate steps

- Title: *Elaboration and Compilation*
- URL: https://lean-lang.org/doc/reference/latest/Elaboration-and-Compilation/
- Relevant point: Lean elaborates source, checks proof terms, and compiles executable code through distinct mechanisms.
- Application here: Record both logical evidence and the exact executable/build provenance; do not infer one solely from the other.

## S7 — NIST: security practices across the lifecycle

- Title: *Secure Software Development Framework (SSDF) Version 1.1*
- Publication: NIST SP 800-218, final, February 2022.
- URL: https://csrc.nist.gov/pubs/sp/800/218/final
- Relevant point: SSDF supplies high-level secure development practices that can be integrated into an SDLC and supports a common vocabulary between producers and purchasers.
- Application here: Record responsibilities, protect development artifacts, produce evidence, and handle discovered weaknesses through maintenance. This is an inspiration/mapping, not a complete SSDF assessment.

## Original synthesis supplied by this pack

The following are proposed practices for this artifact, not quotations or claims that a source mandates them:

- Customer intent and examples are traced to formal obligations or explicit alternative evidence.
- An accepted baseline includes definitions, scope, assumptions, and release policy.
- A protected acceptance target is separate from producer-writable implementation/proofs.
- Evidence is tied to exact versions and cannot be replaced by self-declared success.
- Completed proofs authorize only their specified claims, under their stated assumptions.
- Review substitution is scoped to properties with adequate evidence.
- Changed requirements, interfaces, or environmental assumptions reopen affected obligations.

No document in this pack asserts that a prompt can guarantee arbitrary program correctness, that formal verification is always automatic, or that an unexecuted proof script has already been accepted by Lean.
