# Implementation: preserve the accepted target while constructing code

## Inputs and outputs

Read the accepted or explicitly provisional requirement/specification baseline, architecture, traceability map, and assurance profile. Produce implementation, proof candidates, relevant boundary tests, reproducible build instructions, and honest evidence of commands actually run.

A provisional baseline permits exploration. It does not permit reporting customer acceptance or a release-ready verified result.

## Work in small proof obligations

1. Select one requirement and its already stated obligation.
2. Implement the smallest core operation that realizes the required outcomes.
3. Prove the operation's contract and its effect on the shared invariant.
4. Connect it to the exposed entry point and record that binding.
5. Exercise only the tests needed for requirements not established by the proof or to validate an external correspondence.
6. Integrate after the obligation has been checked; preserve evidence for the exact source revision.

Use a separate proof-author role where useful. Give that role the fixed specification and candidate implementation. It may add lemmas or change proofs; it must not weaken the accepted obligation to make a build pass. The same agent may hold multiple roles in a small project, but must preserve the artifact boundaries and disclose that there was no independent author.

When a requirement is inconsistent, underspecified, or outside the automation's ability, report the smallest concrete issue. Continue unrelated authorized work. Escalate the semantic choice to the customer only when existing instructions and examples do not resolve it.

## Code structure

Use a structure that separates specification from implementation without duplicating their semantics unnecessarily:

- Specification: domain types, valid inputs, observable outcomes, and contract predicates.
- Implementation: concrete exported operations.
- Proofs: statements about those exact operations and reusable lemmas.
- Audit: explicit checks of required theorem names and their dependencies.
- Boundary: parsing, storage, transport, authentication, and effect execution.

Do not define a correctness predicate by simply equating an implementation with itself. Define observable business behavior independently. Reuse definitions deliberately and explain which ones define meaning and which ones implement an algorithm.

## Proof-aware implementation rules

- Keep invalid inputs represented as explicit errors or prove that the accepted input path excludes them.
- Handle empty collections, zero quantities, maximum values, duplicates, and identity collisions according to the contract.
- Preserve request identity and payload binding when implementing idempotence.
- Do not silently turn unexpected states into success or substitute a default that violates the business contract.
- Do not use unaudited `extern`, `implemented_by`, foreign code, or runtime overrides to give the executed function different behavior from its logical definition.
- Treat source generation and schema migration as implementation changes. Carry the proof or correspondence argument through them.
- Keep proof search timeouts distinct from counterexamples: failure to find a proof does not establish a defect, and it does not justify acceptance.

## Reproducibility

Pin an installed, real Lean toolchain version and immutable dependency revisions. Record the compiler version observed during execution. Use the project's lockfile when dependencies exist; do not replace pinned inputs with a moving `latest` reference during verification.

Separate build products from source. Ensure the final verification rebuilds the claimed target with the selected source and dependencies. Do not infer a new proof result from stale cached artifacts or a log copied from another revision.

Record the source digest, specification/baseline digest, toolchain identity, command, exit status, and evidence location together. A digest identifies bytes; it does not itself show correctness or authenticity.

## Agent workflow integration

Use an agent plan and short implementation iterations. Request evidence from commands and artifacts, then let a deterministic external release gate determine whether the configured acceptance conditions hold. Claude's guidance distinguishes instructions from enforced checks; its conversational or hook-based completion signal must not be the sole release authority. [S2]

Use isolated tasks for independent modules and integration work for shared invariants. Parallelize only when responsibilities and files are separate. Resolve cross-module contracts before claiming composition.

## Exit evidence

- Actual target operations exist and are named in the obligation registry.
- Changes to accepted requirements/specifications are either absent or tracked as a new baseline.
- Reproducible commands have been run, or their execution is explicitly marked unavailable.
- Boundary code is classified separately from proved core code.
- No status asserts that attaching this skill, writing Lean, or passing ordinary compilation alone proves all required business behavior.

Sources: [S2, S6](09-sources.md). The implementation discipline above is a proposed workflow, not an Anthropic certification.
