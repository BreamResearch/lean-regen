---
name: lean-verified-sdlc
description: Develop business software from customer requirements through explicit formal contracts, Lean implementations, machine-checked proofs, integration evidence, and scoped acceptance. Use for proof-carrying business templates, requirements-to-code agents, Lean verification, fixed-specification correctness, or requests to reduce manual code review. Includes eight SDLC modules, editable requirements artifacts, a runnable Lean starter, and evidence gates. Never infer whole-system bug freedom or review waiver from a prompt, successful build, tests, or self-reported evidence.
---

# Lean Verified SDLC

Execute a requirements-to-evidence lifecycle. Make the acceptance claim precise:
**the identified implementation satisfies the identified formal properties under
the recorded assumptions, as established by the recorded verification run.**
Speak the customer's language; keep identifiers and engineering artifacts stable.

## Operating contract

1. Preserve accepted customer meaning, scope, and proof target. Never weaken a
   postcondition, strengthen a precondition, omit an error path, assume the desired
   result, or change a definition to make a failing proof pass.
2. Distinguish draft, formalized, kernel-checked, independently checked, integrated,
   and accepted. A file or agent assertion cannot grant itself a stronger status.
3. Treat customer requirements as candidate semantics until actual acceptance is
   evidenced. Reuse decisions and authorizations already present in the session.
   Ask only for missing business choices that materially change behavior; continue
   all authorized implementation and proof work that can proceed meanwhile.
4. Prove useful success behavior, rejection/frame behavior, invariants, and applicable
   progress properties. Check satisfiable preconditions and positive witnesses.
   Reject an always-reject or vacuous proof of useful functionality.
5. Bind each claim to exact requirements, specification, implementation, theorem
   statements, dependencies, toolchain, and build artifact. Recheck affected claims
   after changes. Record proof gaps honestly; incomplete work is not a release.
6. Separate proof production from acceptance authority. Protect the accepted
   challenge, verifier, baseline, policy, and signing authority outside producer
   write permissions in the actual platform. Instructions and hashes alone do not
   enforce this boundary.
7. Interpret local script success narrowly. The bundled verifier checks an ordinary
   Lean kernel path in a clean copy, not a hostile-code sandbox or independent
   checker. It does not issue customer approval or a release.
8. Never claim no bugs whatsoever or universal review-free development. Substitute
   proof for manual inspection only for specified implementation properties under
   an accepted policy and genuine independent evidence.
9. Do not deploy, send customer communications, or obtain signatures unless the task
   authorizes them. Preparing reviewable artifacts needs no extra permission.
   Do not invent approval requirements for routine edits.

## Eight modules

Read the relevant modules when entering each phase. Use existing artifacts rather
than restarting discovery after a context change.

| Phase | Module | Produce | Exit condition |
|---|---|---|---|
| 1. Discover | [01-discover](references/01-discover.md) | Intake, glossary, requirements, examples | Material ambiguities and assumptions explicit |
| 2. Contract | [02-contract](references/02-contract.md) | Formal statements, challenge, traceability, baseline | Concrete acceptance methods; actual acceptance when available |
| 3. Architect | [03-architecture](references/03-architecture.md) | State model, interfaces, trust boundaries | Every claim has an execution model |
| 4. Implement | [04-implementation](references/04-implementation.md) | Executable core, proofs, adapters | Code targets frozen semantics |
| 5. Prove | [05-proof](references/05-proof.md) | Named proofs, exact-type challenge, axiom and independent-check evidence | Formal obligations pass the required profile |
| 6. Integrate | [06-boundary](references/06-boundary.md) | DB/API/concurrency/crash evidence, artifact binding | Boundaries closed or explicitly assumed/excluded |
| 7. Change | [07-change](references/07-change.md) | Impact map, refreshed evidence | No stale claim survives a material change |
| 8. Accept | [08-customer-acceptance](references/08-customer-acceptance.md) | Assurance report, scoped decision | Evidence supports the exact claim and authority decision |

Read [10-runbook](references/10-runbook.md) before running scripts,
[11-release-evidence](references/11-release-evidence.md) before considering a review
waiver, and [12-agent-workflow](references/12-agent-workflow.md) for delegation and
attachment use. Read [09-sources](references/09-sources.md) when explaining Anthropic
SDLC and NIST SSDF; this original synthesis claims no certification by either.

## Start a concrete project

Use `scripts/new_project.py --dest ABSOLUTE_NEW_DIRECTORY --project-id PROJECT_ID`
to create the runnable example and draft worksheets. It refuses to overwrite
existing work. For another domain, replace example semantics deliberately before
freezing the customer's candidate contract.

Fill `assets/templates/` worksheets. Register exact formal requirements and theorem
names in `assurance.json`; see `assets/schemas/assurance.schema.json`. Do not treat
illustrative text as a customer decision. Keep examples and acceptance challenges
independent of the implementation-producing task.

```bash
python3 PATH_TO_SKILL/scripts/freeze_contract.py \
  --project PROJECT_DIRECTORY --out EXTERNAL_BASELINE_PATH
python3 PATH_TO_SKILL/scripts/verify_project.py \
  --project PROJECT_DIRECTORY --baseline EXTERNAL_BASELINE_PATH \
  --out PROJECT_DIRECTORY/evidence/core-check.json \
  --tool-bin PINNED_LEAN_BIN_DIRECTORY
```

Use fresh output filenames. Capture actual commands, exits, logs, hashes, and
omissions. If Lean is unavailable, report `BLOCKED`; do not infer proof success
from source text. Do not execute untrusted Lean on a sensitive host: compilation
can execute code.

## What the example establishes

`assets/lean-starter/` contains a single-resource sequential aggregate reservation
model. Lean 4.19.0 is an intentionally fixed, actually tested historical pin.
Fourteen named theorems establish exact reserve/release behavior, rejection without
state changes, capacity conservation, and conservation across every finite command
list. Seven concrete examples and three rejected semantic mutations accompany it.
Use stored validation evidence only for its stored source version.

The example has no named reservation ownership, retry deduplication, authorization,
DB, concurrent execution, crashes, or external API semantics. Do not claim these
properties or adapt aggregate release into named cancellation without adding the
corresponding model, specification, implementation, and proofs. The agent procedure
is reusable; the example's theorems are domain-specific.

## Completion and delivery

Deliver implementation, formal specification, named proofs, locked challenge,
traceability, reproducible commands, actual evidence, trust assumptions, remaining
boundary work, and a readable assurance report. Distinguish code complete, proof
complete, customer accepted, and production ready.

Use `CORE_KERNEL_CHECKED` only after actual checks pass. Keep
`manual_code_review_waiver=false` until an independent authority provides required
signed evidence and policy. `evaluate_release.py` only evaluates scoped eligibility;
it never deploys or grants end-to-end bug freedom. If that profile is unavailable,
finish other authorized work and name the remaining check. Never invent evidence
or weaken the target.
