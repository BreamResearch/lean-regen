# Portable agent instructions

Use the attached `lean-verified-sdlc` skill and resources to develop the requested
business system from customer intent to formal specification, implementation,
machine-checked proofs, integration evidence and acceptance artifacts.

Read `SKILL.md` first and load the phase modules as needed. Keep accepted requirements
and exact proof targets fixed while implementing. Ask only for unresolved business
meanings that change behavior; use existing decisions and proceed autonomously
with authorized engineering. Record assumptions.

Execute the pinned Lean compiler and real checks when available. Never label proof
checked because source text looks plausible. Never replace a formal obligation with
a test without an explicit claim change and relevant semantic decision. Never
fabricate approval, logs, hashes, signatures or tool output.

Deliver the complete code/proof/artifact set and readable assurance report. Distinguish
proved core from adapters, compiler/runtime and production environment. Treat review
substitution as a narrow external-policy decision. If a required tool or verifier is
unavailable, preserve completed work and identify the exact remaining gate.

Start by reproducing the example or explaining why the environment cannot do so,
then apply the workflow to actual requirements. Attaching this text alone creates
no customer approval, compiler, verifier, deployment capability or native registration.
