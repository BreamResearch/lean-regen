import VerifiedInventory

open VerifiedInventory

example : reserve (initial 10) 3 = .accepted ⟨7, 3⟩ := by decide
example : reserve (initial 10) 11 = .rejected ⟨10, 0⟩ := by decide
example : reserve (initial 10) 0 = .rejected ⟨10, 0⟩ := by decide
example : release ⟨7, 3⟩ 2 = .accepted ⟨9, 1⟩ := by decide
example : release ⟨7, 3⟩ 4 = .rejected ⟨7, 3⟩ := by decide
example : release ⟨7, 3⟩ 0 = .rejected ⟨7, 3⟩ := by decide
example : run (initial 10) [.reserve 3, .release 2, .reserve 20] = ⟨9, 1⟩ := by decide
