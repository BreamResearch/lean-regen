import VerifiedInventory

open VerifiedInventory

def main : IO Unit := do
  let s := initial 10
  let r1 := reserve s 3
  let r2 := release r1.state 2
  let r3 := reserve r2.state 20
  IO.println s!"initial: {repr s}"
  IO.println s!"reserve 3: {repr r1}"
  IO.println s!"release 2: {repr r2}"
  IO.println s!"reserve 20: {repr r3}"
