import VerifiedInventory.Proofs

#print axioms VerifiedInventory.initial_exact
#print axioms VerifiedInventory.initial_wellFormed
#print axioms VerifiedInventory.reserve_refines
#print axioms VerifiedInventory.release_refines
#print axioms VerifiedInventory.reserve_succeeds
#print axioms VerifiedInventory.release_succeeds
#print axioms VerifiedInventory.reserve_rejects_unchanged
#print axioms VerifiedInventory.release_rejects_unchanged
#print axioms VerifiedInventory.reserve_preserves
#print axioms VerifiedInventory.release_preserves
#print axioms VerifiedInventory.step_refines
#print axioms VerifiedInventory.step_preserves
#print axioms VerifiedInventory.run_preserves
#print axioms VerifiedInventory.all_runs_preserve
