# Verified inventory starter

## Scope

This is a runnable Lean 4.19.0 example of a single-resource inventory pool.
State contains aggregate available and reserved natural-number quantities.
The operations reserve and release reject zero and unavailable quantities.
Capacity is an external theorem parameter, not a mutable field in the state.

The formal contract requires exact quantity updates, justified rejection,
unchanged state on rejection, success for permitted requests, and capacity
conservation after every finite sequence of commands. An implementation that
rejects every request cannot meet the complete contract.

There are no reservation identifiers, users, authorization, retries, database
transactions, concurrency, shipments, expiry, inbound stock, or network effects.
In particular, repeated release requests can release more stock if permitted;
this example does not promise idempotency or per-reservation cancellation.

## Files and trust boundary

- `VerifiedInventory/Specification.lean`: business types and relational contract.
- `Contract.lean`: exact expected theorem statements, checked against submitted proofs.
- `VerifiedInventory/Implementation.lean`: executable pure functions.
- `VerifiedInventory/Proofs.lean`: proofs about those exact functions.
- `Audit.lean`: transitive axiom report for all required named theorems.
- `Examples.lean`: concrete executable specifications checked with kernel `decide`.
- `Main.lean`: a small demonstration executable; output formatting is not covered.
- `evidence/validation-summary.json`: observed results and source hashes for this snapshot.

Freeze the specification and contract with the approved requirements before
giving the implementation producer write access. Pin their hashes outside the
producer's writable workspace. A hash stored beside mutable code is not an
authorization boundary. Pin the audit registry as well. The sample uses ordinary
kernel checking, not an independent checker or a hostile-code sandbox.

## Run

Install the official toolchain named in `lean-toolchain`, then run these commands
from this directory. No third-party Lean package is required.

The release is pinned to Lean 4.19.0 to make this example reproducible against
the exact toolchain exercised during preparation. This is a tested historical
pin, not a claim that 4.19.0 is the latest or preferred production release.
An upgrade requires a new build, contract check, axiom audit, and evidence record.
The example specification is illustrative and has no customer acceptance record.

```sh
lake build
lake env lean Contract.lean
lake env lean Audit.lean
lake env lean Examples.lean
lake exe inventory_demo
```

Successful execution establishes only the stated pure-core properties, relative
to the reported standard axioms and the Lean checker. Running the compiled
executable additionally trusts the compiler, runtime, and host environment.
This sample is not a customer acceptance decision, whole-system release,
proof of arbitrary future modifications, or claim that code review is unnecessary.

## Extend

For another capacity, instantiate the existing generic theorems. For reservation
IDs, expiry, authorization, retries, persistence, or concurrency, add explicit
requirements, model states and failure semantics, freeze a revised contract,
and prove the added behavior. Do not extend the claim by renaming this example.
