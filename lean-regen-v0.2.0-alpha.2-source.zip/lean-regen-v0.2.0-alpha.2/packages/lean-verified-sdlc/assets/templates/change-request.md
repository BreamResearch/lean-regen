# Change request / 変更要求

Status: DRAFT

- Request ID: [unassigned]
- Request source and existing authorization: [exact reference]
- Current accepted baseline and artifact: [unassigned]
- Requested outcome: [not specified]
- Business reason and concrete examples: [not specified]

## Classification / 変更種別

[Select: parameter within existing contract; implementation refactoring; semantic change; dependency/toolchain change; integration change; migration; verification-policy change.]

## Impact / 影響

| Affected requirement or assumption | Definition, code, theorem, or adapter | Required work | Evidence |
| --- | --- | --- | --- |
| [unassessed] | | | |

- Existing general theorem covers the change: [not assessed; explain conditions]
- Added guarantee: [not assessed]
- Removed or weakened guarantee: [not assessed]
- Data compatibility and migration: [not assessed]
- Deployment/recovery action and applicable authorization: [not assessed]

## Meaning decision / 意味の決定

- Does the change alter accepted business meaning? [not assessed]
- Prior acceptance or standing policy that covers it: [none recorded]
- Remaining customer decision, if any: [state only a material missing decision]
- Actual acceptance evidence: [none recorded; never generated on the customer's behalf]

## Completion evidence / 完了の根拠

- New baseline and artifact identifiers: [not created]
- Checks run, result, and evidence references: [not executed]
- Updated traceability and examples: [not completed]
- Previous report retained as historical evidence: [not checked]
- Remaining gaps: [not assessed]
