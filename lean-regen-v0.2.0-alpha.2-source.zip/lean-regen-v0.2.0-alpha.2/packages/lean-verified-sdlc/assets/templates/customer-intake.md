# Customer intent / 顧客の意図

Status: DRAFT — this file is not an acceptance record.

## Purpose / 達成したいこと

- Project and customer: [未記入 / not provided]
- Business outcome and observable success: [未確定 / undecided]
- Current problem and representative real examples: [未記入]
- Source materials and prior decisions: [exact references, not invented quotations]

## Actors and authority / 利用者と権限

| Actor | Permitted decisions and operations | Trusted identity source |
| --- | --- | --- |
| [未定] | [未定] | [未定] |

## Boundary / 対象範囲

- Included operations and observations: [未定]
- Included state, external services, and adapters: [未定]
- Explicit exclusions and their rationale: [未定]
- Required deployment/runtime environment: [未定]
- Existing authorization covering implementation and release: [reference or none]

## Behavior / 動作の定義

| Operation | Valid request and expected success | Rejection and unchanged state | Effects and recovery |
| --- | --- | --- | --- |
| [未定] | [未定] | [未定] | [未定] |

## Precision / 曖昧さをなくす項目

- Units, currencies, ranges, rounding, and overflow: [未定]
- Identifiers, revisions, duplicate requests, and payload mismatch: [未定]
- Time, ordering, expiry, and boundary inclusivity: [未定]
- Concurrency, atomicity, and stale-state behavior: [未定]
- Partial failure, restart, retry, and external success without response: [未定]
- Required termination, progress, and resource limits: [未定]

## Assurance target / 保証の対象

- Properties to prove: [未定]
- Integration behavior to test: [未定]
- Environmental assumptions to substantiate: [未定]
- Customer observations needed for acceptance: [未定]
- Requested manual-review waiver and its exact scope: [none unless requested/authorized]

## Open business decisions / 顧客の判断が必要な事項

List only decisions that change desired behavior or authorized scope. Resolve routine implementation choices autonomously and reuse decisions already supplied.

| Decision | Options and consequences | Existing evidence | Proposed next action |
| --- | --- | --- | --- |
| [none recorded yet] | | | |
