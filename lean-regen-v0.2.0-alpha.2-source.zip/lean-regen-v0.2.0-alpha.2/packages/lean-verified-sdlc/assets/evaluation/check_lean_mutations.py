#!/usr/bin/env python3
"""Check three specific semantic mutations against the unchanged starter proofs.

This is targeted regression evidence, not exhaustive defect detection.
"""
import argparse
import concurrent.futures
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--tool-bin", type=Path, required=True)
    p.add_argument("--out-dir", type=Path, required=True)
    args = p.parse_args()
    skill = Path(__file__).resolve().parents[2]
    source = skill / "assets/lean-starter"
    out = args.out_dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    env = {k:v for k,v in os.environ.items() if not k.startswith(("LEAN", "LAKE", "ELAN"))}
    env["PATH"] = str(args.tool_bin.resolve()) + os.pathsep + env.get("PATH", "")
    cases = [
        ("wrong_reserved_delta", "reserved := s.reserved + q", "reserved := s.reserved + q + 1"),
        ("reject_all_reservations", "if ReserveAllowed s q then", "if False then"),
        ("remove_reservation_guard", "if ReserveAllowed s q then", "if True then")]
    def check(case):
        name, old, new = case
        with tempfile.TemporaryDirectory(prefix="lean-semantic-mutation-") as tmp:
            project = Path(tmp) / "project"
            shutil.copytree(source, project, ignore=shutil.ignore_patterns(".lake", ".git", "evidence"))
            target = project / "VerifiedInventory/Implementation.lean"
            before = target.read_text()
            if before.count(old) != 1:
                raise RuntimeError(f"Mutation target is not unique: {name}")
            target.write_text(before.replace(old, new, 1))
            cmd = [str(args.tool_bin.resolve()/"lake"), "build"]
            run = subprocess.run(cmd, cwd=project, env=env, capture_output=True, text=True, timeout=300)
            log = run.stdout + "\n" + run.stderr
            path = out / (name + ".log"); path.write_text(log)
            failed_proof = run.returncode != 0 and "VerifiedInventory/Proofs.lean" in log and (
                "unsolved goals" in log or "failed" in log or "type mismatch" in log)
            return {"case":name,"replacement":{"from":old,"to":new},"exit_code":run.returncode,
                    "rejected_by_unchanged_proofs":failed_proof,
                    "log_file":path.name,"log_sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(check,cases))
    summary = {"scope":"Three specified semantic mutations only; no exhaustive defect-detection claim.",
               "specification_and_proofs_unchanged":True,"results":results,
               "all_expected_rejections_observed":all(x["rejected_by_unchanged_proofs"] for x in results)}
    (out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    print(json.dumps(summary,indent=2))
    return 0 if summary["all_expected_rejections_observed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
