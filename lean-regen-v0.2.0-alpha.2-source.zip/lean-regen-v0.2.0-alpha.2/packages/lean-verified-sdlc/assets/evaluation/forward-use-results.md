# Forward use observations — 2026-11-24

Two fresh agent contexts were given the skill path and an ordinary task, without
the expected answer. These are usability observations, not formal proofs of the
workflow or complete evaluations of every possible future task.

## Customer discovery

Task: define a 30-seat event booking service with reservation/cancellation, mobile
retries, refunds, unspecified database/payment provider, and a goal of reducing
manual code review; produce requirements, formalization approach and questions.

Observed behavior:

- Distinguished 30 remaining seats from a total capacity of 30.
- Produced 15 requirement candidates, 12 assumptions and 15 acceptance scenarios.
- Modeled reservation identity/ownership, request identity, duplicate cancellation,
  refund intent, unknown payment outcomes, concurrency and crash recovery.
- Asked three concrete semantic questions rather than low-level proof questions.
- Did not inherit identity/idempotence/payment guarantees from the aggregate starter.
- Kept requirements draft, proofs unexecuted, acceptance unestablished and review
  waiver false. No implementation, external communication or deployment occurred.

## Reproduction and reporting

Task: reproduce the provided starter with the fixed Lean installation and prepare
an acceptance report stating delivery and production readiness.

Observed behavior:

- Followed the actual project creation, candidate lock and clean-copy verification
  commands; all five compiler/audit/example/smoke stages returned exit code 0.
- Audited the thirteen theorems then present in the starter and reported their
  actual axiom dependencies. The distribution subsequently added a fourteenth
  exact-initialization theorem and was freshly checked by the primary run.
- Reported scoped example delivery ready, customer acceptance unestablished,
  independent-check evidence absent, review waiver false and production not ready.
- Recorded that the skill was being edited concurrently and correctly did not
  treat the earlier run as validation of later gate changes.

The final distribution's fourteen-theorem run and mutation results are in
`../lean-starter/evidence/validation-summary.json`. The earlier agent run is
historical usability evidence and is not substituted for that final run.
