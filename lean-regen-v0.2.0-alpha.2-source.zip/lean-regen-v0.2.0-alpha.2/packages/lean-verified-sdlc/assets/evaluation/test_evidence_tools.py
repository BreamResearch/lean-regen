"""Regression tests for evidence plumbing; no test is a production approval.

The signed-receipt success fixture is deliberately synthetic. It validates
authentication/binding behavior, NOT an independent Lean/comparator execution.
"""
import base64
import contextlib
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

SKILL = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(SKILL / "scripts"))
from assurance_lib import (GateError, canonical, contract_hashes, digest, file_sha,
                           lexical_issues, parse_axioms, project_file, read_json,
                           reserve_output, snapshot, validate_baseline, validate_build_profile, validate_config,
                           write_json, write_json_exclusive)
import evaluate_release
import freeze_contract
import verify_project


def invoke(module, argv):
    old = sys.argv
    stdout, stderr = io.StringIO(), io.StringIO()
    try:
        sys.argv = [module.__name__] + [str(x) for x in argv]
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = module.main()
        return code, stdout.getvalue(), stderr.getvalue()
    finally:
        sys.argv = old


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="lean-gate-unit-")
        self.work = Path(self.tmp.name)
        self.project = self.work / "project"
        shutil.copytree(SKILL / "assets/lean-starter", self.project,
                        ignore=shutil.ignore_patterns(".lake", "evidence", "__pycache__"))
        self.cfg = validate_config(self.project)
        files = contract_hashes(self.project, self.cfg)
        self.baseline = self.work / "authority/baseline.json"
        write_json(self.baseline, {"schema_version": 1, "kind": "candidate_contract_lock",
                                  "project_id": self.cfg["project_id"],
                                  "files": files, "contract_digest": digest(files)})

    def tearDown(self):
        self.tmp.cleanup()

    def update_config(self, **changes):
        cfg = read_json(self.project / "assurance.json")
        cfg.update(changes)
        write_json(self.project / "assurance.json", cfg)

    def test_valid_config_and_baseline(self):
        validate_baseline(self.project, self.cfg, read_json(self.baseline))
        self.assertEqual(len(self.cfg["theorems"]), 14)

    def test_output_reservation_is_exclusive(self):
        target = self.work / "shared-output.json"
        lock = reserve_output(target)
        try:
            with self.assertRaises(GateError): reserve_output(target)
            write_json_exclusive(target, {"owner": "first"})
        finally:
            lock.unlink()
        self.assertEqual(read_json(target), {"owner": "first"})

    def test_evidence_write_never_reuses_other_output(self):
        target = self.work / "existing-output.json"
        write_json(target, {"owner": "other"})
        with self.assertRaises(FileExistsError): write_json_exclusive(target, {"owner": "this"})
        self.assertEqual(read_json(target), {"owner": "other"})

    def test_missing_formal_coverage_fails(self):
        self.update_config(requirements=self.cfg["requirements"] + [{"id": "REQ-MISSING", "statement": "A useful condition", "method": "formal"}])
        with self.assertRaises(GateError): validate_config(self.project)

    def test_duplicate_theorems_fail(self):
        self.update_config(theorems=self.cfg["theorems"] + [self.cfg["theorems"][0]])
        with self.assertRaises(GateError): validate_config(self.project)

    def test_dependency_requires_are_rejected_even_with_empty_lock(self):
        p = self.project / "lakefile.toml"
        p.write_text(p.read_text() + '\n[[require]]\nname = "external"\npath = "/tmp/external"\n')
        with self.assertRaises(GateError): validate_build_profile(self.project)

    def test_missing_lock_is_rejected(self):
        (self.project / "lake-manifest.json").unlink()
        with self.assertRaises(GateError): validate_config(self.project)

    def test_unsafe_lake_options_rejected(self):
        p = self.project / "lakefile.toml"
        p.write_text(p.read_text() + '\nmoreLeanArgs = ["-Ddebug.skipKernelTC=true"]\n')
        with self.assertRaises(GateError): validate_build_profile(self.project)

    def test_changed_contract_fails(self):
        p = self.project / "Contract.lean"
        p.write_text(p.read_text() + "\n-- changed target\n")
        with self.assertRaises(GateError): validate_baseline(self.project, self.cfg, read_json(self.baseline))

    def test_baseline_digest_tamper_fails(self):
        baseline = read_json(self.baseline); baseline["contract_digest"] = "0" * 64
        with self.assertRaises(GateError): validate_baseline(self.project, self.cfg, baseline)

    def test_no_missing_audit_allowed(self):
        with self.assertRaises(GateError): parse_axioms("", ["P.ok"], [])

    def test_incomplete_custom_native_axioms_fail(self):
        for ax in ["sorryAx", "Trust.me", "P._native.native_decide.ax_1"]:
            with self.subTest(ax=ax), self.assertRaises(GateError):
                parse_axioms(f"'P.ok' depends on axioms: [{ax}]", ["P.ok"], ["propext"])

    def test_standard_axioms_and_empty_pass(self):
        r = parse_axioms("'P.a' depends on axioms: [propext,\n Quot.sound]\n'P.b' does not depend on any axioms", ["P.a", "P.b"], ["propext", "Quot.sound"])
        self.assertEqual(r["P.b"], [])

    def test_duplicate_audit_entry_fails(self):
        with self.assertRaises(GateError):
            parse_axioms("'P.a' does not depend on any axioms\n'P.a' does not depend on any axioms", ["P.a"], [])

    def test_comments_are_not_incomplete_proofs(self):
        p = self.project / "Comment.lean"
        p.write_text('/- sorry /- admit -/ axiom -/\n-- unsafe\ndef msg := "sorry"\n')
        self.assertEqual(lexical_issues(self.project), [])
        p.write_text("theorem falseClaim : False := by sorry\n")
        self.assertTrue(lexical_issues(self.project))

    def test_path_escape_and_symlink_fail(self):
        with self.assertRaises(GateError): project_file(self.project, "../outside")
        link = self.project / "link.lean"; link.symlink_to(self.project / "Contract.lean")
        with self.assertRaises(GateError): project_file(self.project, "link.lean")

    def test_freeze_will_not_overwrite_or_claim_acceptance(self):
        code, _, _ = invoke(freeze_contract, ["--project", self.project, "--out", self.baseline])
        self.assertNotEqual(code, 0)
        new = self.work / "authority/new.json"
        code, _, _ = invoke(freeze_contract, ["--project", self.project, "--out", new])
        self.assertEqual(code, 0)
        self.assertEqual(read_json(new)["customer_acceptance"], "not_established_by_this_tool")

    def test_freeze_refuses_project_local_authority(self):
        target = self.project / "baseline.json"
        code, _, _ = invoke(freeze_contract, ["--project", self.project, "--out", target])
        self.assertNotEqual(code, 0); self.assertFalse(target.exists())

    def test_invalid_report_location_does_not_write_source(self):
        target = self.project / "accidental-source.json"
        code, _, _ = invoke(verify_project, ["--project", self.project, "--baseline", self.baseline, "--out", target])
        self.assertNotEqual(code, 0); self.assertFalse(target.exists())

    def test_report_cannot_be_project_directory(self):
        code, _, _ = invoke(verify_project, ["--project", self.project, "--baseline", self.baseline, "--out", self.project])
        self.assertNotEqual(code, 0)

    def test_contract_change_during_version_query_is_rejected(self):
        tool = self.work / "fake-tool-bin"; tool.mkdir()
        for name in ["lean", "lake"]:
            executable = tool / name
            executable.write_text("#!/bin/sh\nexit 99\n"); executable.chmod(0o700)
        def version_only(argv, **kwargs):
            self.assertIn("--version", argv, "No build may run after a changed contract")
            (self.project / "Contract.lean").write_text("import VerifiedInventory.Proofs\n")
            return subprocess.CompletedProcess(argv, 0, "Lean (version 4.19.0, test fixture)\n", "")
        out = self.work / "changed-during-snapshot.json"
        with patch.object(verify_project.subprocess, "run", side_effect=version_only):
            code, _, _ = invoke(verify_project, ["--project", self.project, "--baseline", self.baseline,
                                               "--out", out, "--tool-bin", tool])
        self.assertNotEqual(code, 0)
        self.assertIn("Frozen contract changed", " ".join(read_json(out)["errors"]))

    def test_inherited_lean_overrides_are_removed(self):
        tool = self.work / "fake-tool-bin"; tool.mkdir()
        for name in ["lean", "lake"]:
            executable = tool / name
            executable.write_text("#!/bin/sh\nexit 99\n"); executable.chmod(0o700)
        def check_env(argv, **kwargs):
            self.assertNotIn("LEAN_PATH", kwargs["env"])
            self.assertNotIn("LEAN_SYSROOT", kwargs["env"])
            self.assertNotIn("ELAN_TOOLCHAIN", kwargs["env"])
            return subprocess.CompletedProcess(argv, 1, "", "intentional test stop")
        with patch.dict(os.environ, {"LEAN_PATH": "/untrusted", "LEAN_SYSROOT": "/untrusted", "ELAN_TOOLCHAIN": "other"}), patch.object(verify_project.subprocess, "run", side_effect=check_env):
            code, _, _ = invoke(verify_project, ["--project", self.project, "--baseline", self.baseline,
                                               "--out", self.work / "env.json", "--tool-bin", tool])
        self.assertNotEqual(code, 0)

    def test_missing_tool_fails_closed(self):
        out = self.work / "missing-tool.json"
        previous = os.environ.get("PATH")
        os.environ["PATH"] = str(self.work / "no-binaries")
        try:
            code, _, _ = invoke(verify_project, ["--project", self.project, "--baseline", self.baseline, "--out", out])
        finally:
            if previous is None: os.environ.pop("PATH", None)
            else: os.environ["PATH"] = previous
        self.assertNotEqual(code, 0)
        report = read_json(out)
        self.assertFalse(report["formal_check_passed"])
        self.assertFalse(report["manual_code_review_waiver"])


@unittest.skipUnless(shutil.which("openssl"), "OpenSSL is required for synthetic signature transport tests")
class ReceiptTests(unittest.TestCase):
    def setUp(self):
        EvidenceTests.setUp(self)
        self.key = self.work / "authority/TEST_ONLY_private.pem"
        self.pub = self.work / "authority/TEST_ONLY_public.pem"
        subprocess.run(["openssl", "genpkey", "-algorithm", "ED25519", "-out", str(self.key)], check=True, capture_output=True)
        subprocess.run(["openssl", "pkey", "-in", str(self.key), "-pubout", "-out", str(self.pub)], check=True, capture_output=True)
        self.artifact = self.work / "SYNTHETIC_ARTIFACT.bin"; self.artifact.write_bytes(b"synthetic interface fixture, not a Lean artifact")
        baseline = read_json(self.baseline)
        self.report = self.work / "SYNTHETIC_REPORT.json"
        write_json(self.report, {"status": "CORE_KERNEL_CHECKED", "formal_check_passed": True,
                                "source_digest": digest(snapshot(self.project)),
                                "contract_digest": baseline["contract_digest"],
                                "build_artifact_sha256": file_sha(self.artifact)})
        self.policy = self.work / "authority/SYNTHETIC_POLICY.json"
        write_json(self.policy, {"schema_version": 1, "status": "approved",
                                "approved_contract_digest": baseline["contract_digest"],
                                "acceptance_record": "SYNTHETIC_INTERFACE_TEST_NOT_CUSTOMER_APPROVAL",
                                "waiver_scope": "verified_pure_core_logic", "checker_profile": "comparator_paranoid",
                                "verifier_public_key": str(self.pub)})
        self.payload = {"schema_version": 1, "project_id": self.cfg["project_id"],
                        "contract_digest": baseline["contract_digest"], "source_digest": digest(snapshot(self.project)),
                        "local_report_sha256": file_sha(self.report), "build_artifact_sha256": file_sha(self.artifact),
                        "checker_profile": "comparator_paranoid", "exact_statement_match": True,
                        "independent_kernel_checks_passed": True, "allowed_axioms_only": True,
                        "assumptions_accepted": True, "waiver_scope": "verified_pure_core_logic",
                        "checker_log_sha256": "1" * 64, "verifier_identity": "SYNTHETIC_INTERFACE_TEST_ONLY"}
        self.receipt = self.work / "SYNTHETIC_RECEIPT.json"
        self.sign()

    def tearDown(self):
        EvidenceTests.tearDown(self)

    def sign(self):
        data, signature = self.work / "payload.json", self.work / "sig.bin"
        data.write_bytes(canonical(self.payload))
        subprocess.run(["openssl", "pkeyutl", "-sign", "-inkey", str(self.key), "-rawin", "-in", str(data), "-out", str(signature)], check=True, capture_output=True)
        write_json(self.receipt, {"payload": self.payload, "signature_base64": base64.b64encode(signature.read_bytes()).decode()})

    def evaluate(self):
        target = self.work / "decision.json"
        code, _, _ = invoke(evaluate_release, ["--project", self.project, "--baseline", self.baseline,
            "--report", self.report, "--trusted-policy", self.policy, "--receipt", self.receipt,
            "--artifact", self.artifact, "--out", target])
        return code, read_json(target)

    def test_synthetic_signature_transport_success_only(self):
        code, r = self.evaluate()
        self.assertEqual(code, 0); self.assertTrue(r["eligible"])
        self.assertFalse(r["end_to_end_verified"]); self.assertFalse(r["deployment_authorized"])

    def test_unsigned_edit_rejected(self):
        env = read_json(self.receipt); env["payload"]["source_digest"] = "0" * 64; write_json(self.receipt, env)
        code, r = self.evaluate(); self.assertNotEqual(code, 0); self.assertFalse(r["eligible"])

    def test_artifact_substitution_rejected(self):
        self.artifact.write_bytes(b"different artifact")
        code, _ = self.evaluate(); self.assertNotEqual(code, 0)

    def test_stale_source_rejected(self):
        (self.project / "NewFile.lean").write_text("def changed := 1\n")
        code, _ = self.evaluate(); self.assertNotEqual(code, 0)

    def test_signed_missing_independent_check_rejected(self):
        self.payload["independent_kernel_checks_passed"] = False; self.sign()
        code, _ = self.evaluate(); self.assertNotEqual(code, 0)

    def test_draft_policy_rejected(self):
        p = read_json(self.policy); p["status"] = "draft"; write_json(self.policy, p)
        code, _ = self.evaluate(); self.assertNotEqual(code, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
