#!/usr/bin/env python3
"""Evaluate eligibility for a narrowly scoped review waiver from external evidence.

This does not run comparator, sign evidence, approve requirements, deploy, or
claim end-to-end verification. The independent verifier holds the signing key.
The public-key policy and accepted baseline must be controlled outside the
implementation-producing agent's permissions. A filesystem path alone does
not establish that separation.
"""
from __future__ import annotations
import argparse
import base64
import binascii
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from assurance_lib import (GateError, canonical, digest, file_sha, read_json,
                           reserve_output, snapshot, validate_baseline, validate_config, write_json_exclusive)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project", type=Path, required=True)
    p.add_argument("--baseline", type=Path, required=True)
    p.add_argument("--report", type=Path, required=True)
    p.add_argument("--trusted-policy", type=Path, required=True)
    p.add_argument("--receipt", type=Path, required=True)
    p.add_argument("--artifact", type=Path, required=True, help="Exact artifact evaluated by the independent verifier")
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    result = {"schema_version": 1, "status": "BLOCKED", "eligible": False,
              "waiver_scope": "none", "end_to_end_verified": False,
              "deployment_authorized": False, "errors": []}
    can_write = False
    output_lock = None
    try:
        root = args.project.resolve(strict=True)
        out = args.out.resolve()
        if out.exists():
            raise GateError("Refusing to overwrite an existing decision")
        if out.is_relative_to(root) and out.relative_to(root).parts[0] not in {"evidence", "reports"}:
            raise GateError("Write decisions outside the project or under evidence/ or reports/")
        output_lock = reserve_output(out)
        can_write = True
        cfg = validate_config(root)
        baseline_path = args.baseline.resolve(strict=True)
        policy_path = args.trusted_policy.resolve(strict=True)
        if baseline_path.is_relative_to(root) or policy_path.is_relative_to(root):
            raise GateError("Accepted baseline and verifier policy must be outside the producer project")
        baseline = read_json(baseline_path)
        validate_baseline(root, cfg, baseline)
        report = read_json(args.report)
        policy = read_json(policy_path)
        envelope = read_json(args.receipt)
        if policy.get("schema_version") != 1 or policy.get("status") != "approved":
            raise GateError("External engineering policy is not approved")
        if policy.get("waiver_scope") != "verified_pure_core_logic":
            raise GateError("Only a verified_pure_core_logic waiver is implemented")
        if not policy.get("acceptance_record"):
            raise GateError("A real customer/specification acceptance reference is required")
        if policy.get("approved_contract_digest") != baseline["contract_digest"]:
            raise GateError("Policy does not approve this exact contract")
        if policy.get("checker_profile") != "comparator_paranoid":
            raise GateError("This waiver policy requires independent exact-statement validation")
        key_text = policy.get("verifier_public_key")
        if not isinstance(key_text, str) or not Path(key_text).is_absolute():
            raise GateError("Provide an absolute authority-controlled public key path")
        key = Path(key_text).resolve(strict=True)
        if key.is_relative_to(root):
            raise GateError("Verifier public key must be outside the producer project")
        payload = envelope.get("payload")
        if not isinstance(payload, dict):
            raise GateError("Missing signed verifier payload")
        signature = base64.b64decode(envelope.get("signature_base64", ""), validate=True)
        if len(signature) != 64:
            raise GateError("Expected a 64-byte Ed25519 signature")
        openssl = shutil.which("openssl")
        if not openssl:
            raise GateError("OpenSSL unavailable; external receipt was not authenticated")
        with tempfile.TemporaryDirectory(prefix="lean-receipt-") as tmp:
            data = Path(tmp) / "payload.json"
            sig = Path(tmp) / "signature.bin"
            data.write_bytes(canonical(payload))
            sig.write_bytes(signature)
            keyinfo = subprocess.run([openssl, "pkey", "-pubin", "-in", str(key), "-text", "-noout"],
                                     capture_output=True, text=True, timeout=30)
            if keyinfo.returncode or "ED25519" not in keyinfo.stdout.upper():
                raise GateError("Authority key is not a valid Ed25519 public key")
            verified = subprocess.run([openssl, "pkeyutl", "-verify", "-pubin", "-inkey", str(key),
                                       "-rawin", "-in", str(data), "-sigfile", str(sig)],
                                      capture_output=True, text=True, timeout=30)
            if verified.returncode:
                raise GateError("Independent verifier signature is invalid")
        if report.get("status") != "CORE_KERNEL_CHECKED" or report.get("formal_check_passed") is not True:
            raise GateError("Local kernel checks did not pass")
        actual_source_digest = digest(snapshot(root))
        artifact_digest = file_sha(args.artifact)
        expected = {
            "schema_version": 1,
            "project_id": cfg["project_id"],
            "contract_digest": baseline["contract_digest"],
            "source_digest": actual_source_digest,
            "local_report_sha256": file_sha(args.report),
            "build_artifact_sha256": artifact_digest,
            "checker_profile": "comparator_paranoid",
            "exact_statement_match": True,
            "independent_kernel_checks_passed": True,
            "allowed_axioms_only": True,
            "assumptions_accepted": True,
            "waiver_scope": "verified_pure_core_logic"
        }
        for field, value in expected.items():
            if payload.get(field) != value:
                raise GateError(f"Signed verifier receipt mismatch: {field}")
        if report.get("source_digest") != actual_source_digest or report.get("contract_digest") != baseline["contract_digest"]:
            raise GateError("Local report does not bind the current source and contract")
        if report.get("build_artifact_sha256") != artifact_digest:
            raise GateError("Selected artifact differs from the kernel-build report")
        if not payload.get("checker_log_sha256") or not payload.get("verifier_identity"):
            raise GateError("Independent checker provenance is missing")
        result.update(status="SCOPED_CORE_REVIEW_WAIVER_ELIGIBLE", eligible=True,
                      waiver_scope="verified_pure_core_logic",
                      project_id=cfg["project_id"], contract_digest=baseline["contract_digest"],
                      source_digest=actual_source_digest, build_artifact_sha256=artifact_digest,
                      acceptance_record=policy["acceptance_record"],
                      remaining_reviews=["Correct and complete customer intent and specification",
                                         "Trusted verifier, compiler/runtime and accepted assumptions",
                                         "All adapters, operational behavior and excluded requirements"],
                      trust_notice="Eligibility relies on the trusted authority actually performing the signed checks. Signatures authenticate evidence; they do not prove a theorem.")
    except (GateError, OSError, ValueError, TypeError, binascii.Error, subprocess.TimeoutExpired) as exc:
        result["errors"].append(str(exc))
    if can_write:
        try:
            write_json_exclusive(args.out, result)
        except OSError as exc:
            result["status"] = "BLOCKED"
            result["eligible"] = False
            result["waiver_scope"] = "none"
            result["errors"].append(f"This invocation could not persist its own decision: {exc}")
        finally:
            if output_lock is not None:
                output_lock.unlink(missing_ok=True)
    print(result["status"])
    for error in result["errors"]:
        print(error, file=sys.stderr)
    return 0 if result["eligible"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
