#!/usr/bin/env python3
"""Create a candidate content lock. This command does not obtain acceptance."""
import argparse
import sys
from pathlib import Path
from assurance_lib import GateError, contract_hashes, digest, validate_build_profile, validate_config, write_json_exclusive


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True, help="Use an external, authority-controlled location for an accepted baseline")
    args = p.parse_args()
    try:
        root = args.project.resolve(strict=True)
        cfg = validate_config(root)
        validate_build_profile(root)
        target = args.out.resolve()
        if target.exists():
            raise GateError("Will not overwrite an existing baseline; use a new versioned path")
        if target.is_relative_to(root):
            raise GateError("Put the baseline outside the producer's project tree")
        files = contract_hashes(root, cfg)
        value = {
            "schema_version": 1,
            "kind": "candidate_contract_lock",
            "project_id": cfg["project_id"],
            "contract_digest": digest(files),
            "files": files,
            "customer_acceptance": "not_established_by_this_tool",
            "trust_notice": "A digest records content, not truth, completeness, approval, or protected custody."
        }
        target.parent.mkdir(parents=True, exist_ok=True)
        write_json_exclusive(target, value)
        print(f"CANDIDATE_LOCK_CREATED {value['contract_digest']}")
        print("Customer acceptance remains separate; do not change the locked target to make a proof pass.")
        return 0
    except (GateError, OSError) as exc:
        print(f"BLOCKED: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
