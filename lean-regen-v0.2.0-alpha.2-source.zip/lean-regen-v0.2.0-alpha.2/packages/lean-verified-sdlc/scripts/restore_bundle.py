#!/usr/bin/env python3
"""Reconstruct the structured JSON skill export without executing its code."""
import argparse
import hashlib
import json
import sys
from pathlib import Path
from assurance_lib import GateError, digest, read_json


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--dest", type=Path, required=True)
    args = p.parse_args()
    try:
        bundle = read_json(args.input)
        if bundle.get("format") != "lean-verified-sdlc-bundle-v1" or bundle.get("entrypoint") != "SKILL.md":
            raise GateError("Unsupported bundle format")
        files = bundle.get("files")
        if not isinstance(files, list) or not 1 <= len(files) <= 1000 or bundle.get("file_count") != len(files):
            raise GateError("Invalid file collection")
        checked, index, total = [], {}, 0
        for item in files:
            if not isinstance(item, dict):
                raise GateError("Malformed file entry")
            name, text = item.get("path"), item.get("content")
            if not isinstance(name, str) or not name or "\\" in name or not isinstance(text, str):
                raise GateError("Malformed path/content")
            rel = Path(name)
            if rel.is_absolute() or not rel.parts or any(x in {"..", ".", ".git", ".lake", "__pycache__"} for x in rel.parts):
                raise GateError("Unsafe relative path")
            if rel.as_posix() != name or name in index:
                raise GateError("Noncanonical or duplicate path")
            if rel.parts[0] not in {"SKILL.md", ".gitignore", "agents", "assets", "references", "scripts"}:
                raise GateError("Unexpected skill layout")
            data = text.encode("utf-8")
            actual = hashlib.sha256(data).hexdigest()
            if item.get("encoding") != "utf-8" or item.get("size_bytes") != len(data) or item.get("sha256") != actual:
                raise GateError(f"File integrity mismatch: {name}")
            total += len(data)
            if total > 20 * 1024 * 1024:
                raise GateError("Bundle exceeds the source-only size limit")
            index[name] = actual; checked.append((rel, data))
        if "SKILL.md" not in index or bundle.get("file_index_digest") != digest(index):
            raise GateError("File index mismatch")
        dest = args.dest.resolve()
        if dest.exists():
            raise GateError("Destination exists; no existing work will be overwritten")
        dest.mkdir(parents=True, exist_ok=False)
        for rel, data in checked:
            target = dest / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(data)
        print(f"RESTORED {len(files)} files to {dest}")
        print("No code was executed or native skill registered. Content hashes are not a trust signature.")
        return 0
    except (GateError, OSError, ValueError, TypeError) as exc:
        print(f"BLOCKED: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
