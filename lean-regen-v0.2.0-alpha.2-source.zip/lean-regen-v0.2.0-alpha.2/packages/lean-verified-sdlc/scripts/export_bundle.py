#!/usr/bin/env python3
"""Export the complete skill as structured JSON and an attachable Markdown file.

The index digest detects accidental byte changes; it is not an authenticity
signature. Generated files are portable source distributions, not proof evidence.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path
from assurance_lib import GateError, digest, write_json_exclusive


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out-dir", type=Path, required=True)
    args = p.parse_args()
    skill = Path(__file__).resolve().parent.parent
    out = args.out_dir.resolve()
    if out.is_relative_to(skill):
        raise GateError("Export outside the installed skill tree")
    out.mkdir(parents=True, exist_ok=True)
    excluded = {".git", ".lake", "__pycache__", ".venv"}
    files = []
    for path in sorted(skill.rglob("*")):
        rel = path.relative_to(skill)
        if any(x in excluded for x in rel.parts):
            continue
        if path.is_symlink():
            raise GateError(f"Cannot export a symlink: {rel}")
        if not path.is_file():
            continue
        data = path.read_bytes()
        text = data.decode("utf-8")
        files.append({"path": rel.as_posix(), "sha256": hashlib.sha256(data).hexdigest(),
                      "size_bytes": len(data), "encoding": "utf-8", "content": text})
    index = {f["path"]: f["sha256"] for f in files}
    bundle = {"format": "lean-verified-sdlc-bundle-v1", "version": "1.0.0",
              "entrypoint": "SKILL.md", "file_count": len(files),
              "file_index_digest": digest(index),
              "trust_notice": "Hashes identify content, not approval or proof. Read the included scope and actual evidence.",
              "files": files}
    json_path = out / "Lean_Verified_SDLC_v1_0_0.json"
    md_path = out / "Lean_Verified_SDLC_Attachment.md"
    if json_path.exists() or md_path.exists():
        raise GateError("Export destinations already exist; choose a new output directory")
    write_json_exclusive(json_path, bundle)
    header = ["# Lean Verified SDLC — complete attachment / 完全添付版", "",
              "This file contains every source/resource file of the skill, with relative paths and SHA-256 identifiers.",
              "添付先のエージェントは最初に SKILL.md を読み、必要な工程モジュールを順に参照してください。",
              "実行可能な環境では JSON 配布版の files[].path/content を復元する方法が最も確実です。",
              "スキル指示だけで証明済みにはなりません。実際の Lean 検査結果と保証範囲を確認してください。", "",
              f"- Version: 1.0.0", f"- Files: {len(files)}", f"- File-index digest: `{bundle['file_index_digest']}`", "",
              "## Contents", "", "| Path | Bytes | SHA-256 |", "|---|---:|---|"]
    header += [f"| `{f['path']}` | {f['size_bytes']} | `{f['sha256']}` |" for f in files]
    content = ["\n".join(header)]
    extensions = {".py":"python", ".lean":"lean", ".json":"json", ".toml":"toml", ".yaml":"yaml", ".md":"markdown", ".csv":"csv"}
    order = sorted(files, key=lambda f: (f["path"] != "SKILL.md", f["path"]))
    for f in order:
        runs = re.findall(r"`+", f["content"])
        fence = "`" * max(4, 1 + max((len(x) for x in runs), default=0))
        language = extensions.get(Path(f["path"]).suffix, "text")
        content.append(f"\n\n## File: {f['path']}\n\nSHA-256: `{f['sha256']}`\n\n{fence}{language}\n{f['content']}" + ("" if f["content"].endswith("\n") else "\n") + fence)
    with md_path.open("x", encoding="utf-8") as stream:
        stream.write("\n".join(content) + "\n")
    print(json.dumps({"files": len(files), "json": str(json_path), "attachment": str(md_path),
                      "file_index_digest": bundle["file_index_digest"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
