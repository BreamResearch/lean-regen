#!/usr/bin/env python3
"""Build a clean Lean snapshot and check a fixed challenge plus axiom audit.

Exit 0 means the listed kernel checks passed, not that a product is bug-free or
release-authorized. For arbitrary untrusted proof producers use an independently
controlled, compatible comparator/checker path as described in references/05-proof.md.
"""
from __future__ import annotations
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from assurance_lib import (GateError, canonical, digest, file_sha, lexical_issues,
                           parse_axioms, project_file, read_json, reserve_output, snapshot,
                           validate_baseline, validate_build_profile, validate_config, write_json_exclusive)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project", type=Path, required=True)
    p.add_argument("--baseline", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--tool-bin", type=Path, help="Directory containing the pinned lean and lake executables")
    p.add_argument("--timeout", type=int, default=300, help="Timeout per compiler/check step")
    args = p.parse_args()
    report = {"schema_version": 1, "status": "BLOCKED", "formal_check_passed": False,
              "customer_acceptance": "not_established", "manual_code_review_waiver": False,
              "end_to_end_verified": False, "checker_profile": "ordinary_lean_kernel",
              "errors": [], "steps": [], "started_unix": int(time.time())}
    can_write_report = False
    output_lock = None
    try:
        if args.timeout < 1:
            raise GateError("Timeout must be positive")
        root = args.project.resolve(strict=True)
        out = args.out.resolve()
        if out.is_relative_to(root):
            relative_out = out.relative_to(root)
            if not relative_out.parts or relative_out.parts[0] not in {"evidence", "reports"}:
                raise GateError("Write reports outside the project or under evidence/ or reports/")
        if out.exists():
            raise GateError("Refusing to overwrite evidence; choose a new report path")
        output_lock = reserve_output(out)
        can_write_report = True
        baseline_path = args.baseline.resolve(strict=True)
        if baseline_path.is_relative_to(root):
            raise GateError("The baseline must be outside the producer project")
        cfg = validate_config(root)
        validate_build_profile(root)
        verifier_inputs = [Path(__file__).resolve(), Path(__file__).resolve().with_name("assurance_lib.py")]
        verifier_hashes = {x.name: file_sha(x) for x in verifier_inputs}
        report["verifier_source_sha256"] = verifier_hashes
        baseline = read_json(baseline_path)
        validate_baseline(root, cfg, baseline)
        issues = lexical_issues(root)
        if issues:
            raise GateError("Restricted-profile lexical preflight failed: " + str(issues))
        env = {k: v for k, v in os.environ.items()
               if not k.startswith(("LEAN", "LAKE", "ELAN", "LD_PRELOAD", "DYLD_"))}
        if args.tool_bin:
            tool_dir = args.tool_bin.resolve(strict=True)
            env["PATH"] = str(tool_dir) + os.pathsep + env.get("PATH", "")
        lake = shutil.which("lake", path=env.get("PATH"))
        lean = shutil.which("lean", path=env.get("PATH"))
        if not lake or not lean:
            raise GateError("Lean/Lake unavailable; no proof was executed")
        pin = (root / "lean-toolchain").read_text().strip()
        match = re.fullmatch(r"leanprover/lean4:v(\d+\.\d+\.\d+)", pin)
        if not match:
            raise GateError("Pin a concrete stable Lean version in lean-toolchain")
        version_run = subprocess.run([lean, "--version"], cwd=root, env=env, text=True,
                                     capture_output=True, timeout=args.timeout)
        actual_version = version_run.stdout.strip()
        if version_run.returncode or not re.search(r"version " + re.escape(match.group(1)) + r"(?:\s|,|\))", actual_version):
            raise GateError(f"Toolchain mismatch: pin={pin}, actual={actual_version}")
        source_files = snapshot(root)
        report.update(project_id=cfg["project_id"], scope=cfg["scope"],
                      contract_digest=baseline["contract_digest"],
                      source_digest=digest(source_files), source_files=source_files,
                      lean_version=actual_version, toolchain_pin=pin,
                      lean_executable_sha256=file_sha(lean), lake_executable_sha256=file_sha(lake),
                      assumptions=cfg["assumptions"], requirements=cfg["requirements"])
        logs_dir = out.parent / (out.stem + "_logs")
        if logs_dir.exists():
            raise GateError("Evidence log directory already exists")
        logs_dir.mkdir(parents=True)
        with tempfile.TemporaryDirectory(prefix="lean-sdlc-check-") as tmp:
            clean = Path(tmp) / "project"
            clean.mkdir()
            for rel in source_files:
                target = clean / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(root / rel, target)
            if snapshot(clean) != source_files:
                raise GateError("Source changed while creating the verification snapshot")
            # Validate the bytes actually compiled, not only a pre-copy source view.
            # This also detects contract changes during version lookup or copying.
            clean_cfg = validate_config(clean)
            validate_baseline(clean, clean_cfg, baseline)
            validate_build_profile(clean)
            if lexical_issues(clean):
                raise GateError("Clean snapshot failed the restricted lexical profile")
            if clean_cfg != cfg:
                raise GateError("Assurance configuration changed before snapshot validation")

            def run(label, argv):
                proc = subprocess.run(argv, cwd=clean, env=env, text=True,
                                      capture_output=True, timeout=args.timeout)
                text = proc.stdout + "\n" + proc.stderr
                log = logs_dir / (label + ".log")
                log.write_text(text, encoding="utf-8")
                report["steps"].append({"name": label, "exit_code": proc.returncode,
                                        "log": str(log), "log_sha256": file_sha(log)})
                if proc.returncode:
                    raise GateError(f"{label} failed; inspect {log}")
                return text

            run("build", [lake, "build"])
            validate_build_profile(clean)
            validate_baseline(clean, clean_cfg, baseline)
            run("fixed_challenge", [lake, "env", lean, "-DwarningAsError=true", cfg["challenge_file"]])
            audit = run("axioms", [lake, "env", lean, "-DwarningAsError=true", cfg["audit_file"]])
            required = [x["name"] for x in cfg["theorems"]]
            report["theorem_axioms"] = parse_axioms(audit, required, cfg["allowed_axioms"])
            if cfg.get("example_file"):
                run("kernel_examples", [lake, "env", lean, "-DwarningAsError=true", cfg["example_file"]])
            if cfg.get("example_executable"):
                exe = clean / ".lake/build/bin" / cfg["example_executable"]
                if not exe.is_file():
                    raise GateError("Expected compiled example executable was not produced")
                report["build_artifact_sha256"] = file_sha(exe)
                run("runtime_smoke", [str(exe)])
                artifacts = out.parent / (out.stem + "_artifacts")
                if artifacts.exists():
                    raise GateError("Artifact evidence directory already exists")
                artifacts.mkdir()
                retained_exe = artifacts / cfg["example_executable"]
                shutil.copy2(exe, retained_exe)
                report["artifact_path"] = str(retained_exe)
            if snapshot(root) != source_files:
                raise GateError("Source changed during verification; results do not certify the current tree")
            if {x.name: file_sha(x) for x in verifier_inputs} != verifier_hashes:
                raise GateError("Verifier source changed during this run; repeat with a fixed verifier")
        report.update(status="CORE_KERNEL_CHECKED", formal_check_passed=True,
                      traceability="structurally_complete_for_registered_formal_requirements",
                      theorem_count=len(cfg["theorems"]),
                      limitations=["The accepted meaning and completeness of requirements are not established by this tool.",
                                   "The baseline and verifier must be protected externally; hashes alone are not an authority boundary.",
                                   "Ordinary kernel/audit checks are not the independent adversarial-proof validation profile.",
                                   "Compilation, runtime, I/O, concurrency and excluded behavior remain outside the pure-core theorem scope.",
                                   "No customer approval, production release, or manual-review waiver is issued here."])
    except (GateError, OSError, ValueError, subprocess.TimeoutExpired) as exc:
        report["errors"].append(str(exc))
    report["finished_unix"] = int(time.time())
    # Preserve previous evidence even on an output-path error.
    if can_write_report:
        try:
            write_json_exclusive(args.out, report)
        except OSError as exc:
            report["status"] = "BLOCKED"
            report["formal_check_passed"] = False
            report["errors"].append(f"This invocation could not persist its own evidence: {exc}")
        finally:
            if output_lock is not None:
                output_lock.unlink(missing_ok=True)
    print(report["status"])
    for error in report["errors"]:
        print(error, file=sys.stderr)
    return 0 if report["formal_check_passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
