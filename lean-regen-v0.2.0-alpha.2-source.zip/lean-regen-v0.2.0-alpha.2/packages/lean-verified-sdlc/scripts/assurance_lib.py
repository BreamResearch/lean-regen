"""Shared, standard-library-only helpers for the Lean SDLC evidence tools.

These helpers validate bookkeeping. They are not a proof kernel, a sandbox,
or a substitute for a verifier controlled independently of the producer.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import tomllib
from pathlib import Path


class GateError(ValueError):
    pass


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise GateError(f"Cannot read JSON {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise GateError(f"Expected a JSON object: {path}")
    return value


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def reserve_output(path):
    """Acquire an exclusive per-output reservation; never steal a stale lock."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise GateError("Evidence output already exists")
    lock = path.with_name(path.name + ".lock")
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise GateError("Evidence output is reserved by another invocation; use a new path") from exc
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        stream.write(str(os.getpid()) + "\n")
    if path.exists():
        lock.unlink()
        raise GateError("Evidence output appeared while acquiring its reservation")
    return lock


def write_json_exclusive(path, value):
    """Never report success by reusing or overwriting another run's evidence."""
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def project_file(root, relative):
    if not isinstance(relative, str) or not relative or "\\" in relative:
        raise GateError(f"Invalid relative path: {relative!r}")
    p = Path(relative)
    if p.is_absolute() or any(x in ("..", ".") for x in p.parts):
        raise GateError(f"Path must stay in the project: {relative}")
    current = Path(root)
    for part in p.parts:
        current = current / part
        if current.is_symlink():
            raise GateError(f"Symlink is not a reproducible source input: {relative}")
    if not current.is_file():
        raise GateError(f"Required file is missing: {relative}")
    return current


def require_text(value, label):
    if not isinstance(value, str) or not value.strip() or value.startswith("REPLACE_"):
        raise GateError(f"Missing concrete {label}")
    return value


def validate_config(root):
    cfg = read_json(project_file(root, "assurance.json"))
    allowed_fields = {"schema_version", "project_id", "backend", "scope", "contract_files",
                      "challenge_file", "audit_file", "example_file", "example_executable",
                      "allowed_axioms", "requirements", "theorems", "assumptions", "customer_acceptance"}
    if set(cfg) - allowed_fields:
        raise GateError("Unknown assurance fields: " + str(sorted(set(cfg) - allowed_fields)))
    if cfg.get("schema_version") != 1:
        raise GateError("Unsupported assurance.json schema_version")
    require_text(cfg.get("project_id"), "project_id")
    if cfg.get("backend") != "lean-stdlib":
        raise GateError("This runnable verifier supports lean-stdlib only; extend a trusted runner for other backends")
    scope = cfg.get("scope", {})
    if not isinstance(scope, dict) or scope.get("kind") != "pure_core":
        raise GateError("This starter verifier only establishes a pure_core claim")
    require_text(scope.get("description"), "scope description")
    if not isinstance(scope.get("excluded"), list) or not scope["excluded"]:
        raise GateError("List the runtime/environment boundaries excluded from the core proof")
    frozen = cfg.get("contract_files")
    if not isinstance(frozen, list) or not frozen or any(not isinstance(x, str) for x in frozen) or len(set(frozen)) != len(frozen):
        raise GateError("contract_files must be a nonempty list of distinct paths")
    for name in ("assurance.json", "lean-toolchain", "lakefile.toml", "lake-manifest.json", cfg.get("challenge_file"), cfg.get("audit_file")):
        if name not in frozen:
            raise GateError(f"Required frozen contract file is not registered: {name}")
    for name in frozen:
        project_file(root, name)
        if any(part in EXCLUDED_DIRS for part in Path(name).parts):
            raise GateError(f"A frozen input cannot be in an excluded output directory: {name}")
    if (Path(root) / "lakefile.lean").exists():
        raise GateError("Executable lakefile.lean is outside this restricted starter profile")
    theorem_entries = cfg.get("theorems")
    if not isinstance(theorem_entries, list) or not theorem_entries:
        raise GateError("Register required named theorems")
    theorem_names = []
    for entry in theorem_entries:
        if not isinstance(entry, dict):
            raise GateError("Every theorem entry must be an object")
        name = entry.get("name")
        if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.]*", name):
            raise GateError(f"Invalid named theorem: {name!r}")
        theorem_names.append(name)
        if not isinstance(entry.get("requirement_ids"), list) or not entry["requirement_ids"] or any(not isinstance(x, str) for x in entry["requirement_ids"]):
            raise GateError(f"Theorem must trace to a requirement: {name}")
    if len(theorem_names) != len(set(theorem_names)):
        raise GateError("Duplicate theorem names")
    requirements = cfg.get("requirements")
    if not isinstance(requirements, list) or not requirements:
        raise GateError("Register requirements independently of theorem evidence")
    req_ids = []
    methods = {"formal", "test", "human_acceptance", "excluded"}
    for req in requirements:
        if not isinstance(req, dict):
            raise GateError("Every requirement must be an object")
        req_ids.append(require_text(req.get("id"), "requirement ID"))
        require_text(req.get("statement"), "requirement statement")
        if req.get("method") not in methods:
            raise GateError(f"Invalid verification method for {req['id']}")
    if len(req_ids) != len(set(req_ids)):
        raise GateError("Duplicate requirement IDs")
    for entry in theorem_entries:
        if any(x not in req_ids for x in entry["requirement_ids"]):
            raise GateError(f"Unknown requirement reference in {entry['name']}")
    covered = {x for t in theorem_entries for x in t["requirement_ids"]}
    for req in requirements:
        if req["method"] == "formal" and req["id"] not in covered:
            raise GateError(f"Formal requirement has no named theorem: {req['id']}")
    assumptions = cfg.get("assumptions")
    if not isinstance(assumptions, list) or not assumptions:
        raise GateError("Declare mathematical and execution assumptions explicitly")
    for item in assumptions:
        if not isinstance(item, dict):
            raise GateError("Every assumption must be an object")
        require_text(item.get("id"), "assumption ID")
        require_text(item.get("statement"), "assumption statement")
    allowed = cfg.get("allowed_axioms")
    if not isinstance(allowed, list) or any(not isinstance(x, str) for x in allowed) or not set(allowed) <= {"propext", "Quot.sound", "Classical.choice"}:
        raise GateError("This profile permits only an explicit subset of Lean's standard logical axioms")
    for field in ("example_file",):
        if cfg.get(field):
            project_file(root, cfg[field])
    if cfg.get("example_executable") and not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]*", cfg["example_executable"]):
        raise GateError("Invalid executable name")
    return cfg


def validate_build_profile(root):
    """Accept only the small dependency-free declarative Lake profile shipped here."""
    try:
        config = tomllib.loads(project_file(root, "lakefile.toml").read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeError) as exc:
        raise GateError(f"Invalid Lake TOML: {exc}") from exc
    allowed_top = {"name", "version", "defaultTargets", "lean_lib", "lean_exe"}
    if set(config) - allowed_top:
        raise GateError("Lake configuration exceeds the restricted dependency-free profile: " + str(sorted(set(config) - allowed_top)))
    targets = set()
    for kind, allowed in (("lean_lib", {"name", "root"}), ("lean_exe", {"name", "root"})):
        entries = config.get(kind, [])
        if not isinstance(entries, list):
            raise GateError(f"Expected an array of {kind} tables")
        for entry in entries:
            if not isinstance(entry, dict) or set(entry) - allowed:
                raise GateError(f"Unsupported {kind} options in the restricted build profile")
            for field, value in entry.items():
                if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.]*", value):
                    raise GateError(f"Invalid {kind} {field}")
            if "name" not in entry:
                raise GateError(f"Missing {kind} name")
            targets.add(entry["name"])
    defaults = config.get("defaultTargets")
    if not isinstance(defaults, list) or not defaults or any(not isinstance(x, str) or x not in targets for x in defaults):
        raise GateError("defaultTargets must name registered libraries/executables")
    manifest = read_json(project_file(root, "lake-manifest.json"))
    if manifest.get("packages") != []:
        raise GateError("The restricted profile requires an explicit empty dependency lock")


EXCLUDED_DIRS = {".git", ".lake", "__pycache__", "evidence", "reports", ".venv"}
EXCLUDED_FILES = {".DS_Store"}


def snapshot(root):
    root = Path(root)
    files = {}
    for p in sorted(root.rglob("*")):
        rel = p.relative_to(root)
        if any(x in EXCLUDED_DIRS for x in rel.parts) or p.name in EXCLUDED_FILES:
            continue
        if p.is_symlink():
            raise GateError(f"Symlink in source tree: {rel}")
        if p.is_file():
            files[rel.as_posix()] = file_sha(p)
    return files


def contract_hashes(root, cfg):
    return {name: file_sha(project_file(root, name)) for name in sorted(cfg["contract_files"])}


def validate_baseline(root, cfg, baseline):
    if baseline.get("schema_version") != 1 or baseline.get("kind") != "candidate_contract_lock":
        raise GateError("Unsupported baseline format")
    actual = contract_hashes(root, cfg)
    if baseline.get("files") != actual:
        expected = baseline.get("files", {})
        changed = sorted(x for x in set(actual) | set(expected) if actual.get(x) != expected.get(x))
        raise GateError("Frozen contract changed: " + ", ".join(changed))
    if baseline.get("contract_digest") != digest(actual):
        raise GateError("Baseline digest does not match its file map")
    if baseline.get("project_id") != cfg["project_id"]:
        raise GateError("Baseline project ID mismatch")


def strip_lean_comments_and_strings(text):
    """Conservative lexical preflight only; never advertised as proof validation."""
    out, i, depth, string = [], 0, 0, False
    while i < len(text):
        two = text[i:i+2]
        if depth:
            if two == "/-":
                depth += 1; i += 2
            elif two == "-/":
                depth -= 1; i += 2
            else:
                out.append("\n" if text[i] == "\n" else " "); i += 1
        elif string:
            if text[i] == "\\":
                i += 2
            elif text[i] == '"':
                string = False; i += 1
            else:
                i += 1
        elif two == "/-":
            depth = 1; out.append(" "); i += 2
        elif two == "--":
            end = text.find("\n", i)
            i = len(text) if end < 0 else end
        elif text[i] == '"':
            string = True; out.append(" "); i += 1
        else:
            out.append(text[i]); i += 1
    return "".join(out)


def lexical_issues(root):
    # Restrictive starter profile. More expressive trusted code needs a separately
    # reviewed profile; a regex scan alone does not stop adversarial metaprograms.
    pattern = re.compile(r"\b(sorry|admit|axiom|unsafe|partial|native_decide|extern|implemented_by|run_tac|elab|macro)\b|debug\.skipKernelTC|decide\s*\+native")
    issues = []
    for rel in snapshot(root):
        if rel.endswith(".lean"):
            text = strip_lean_comments_and_strings(project_file(root, rel).read_text(encoding="utf-8"))
            for match in pattern.finditer(text):
                issues.append({"file": rel, "token": match.group(0), "line": text[:match.start()].count("\n") + 1})
    return issues


def parse_axioms(output, required_names, allowed):
    parsed = {}
    for match in re.finditer(r"'([^']+)'\s+does not depend on any axioms", output):
        if match.group(1) in parsed:
            raise GateError("Duplicate axiom audit entry")
        parsed[match.group(1)] = []
    for match in re.finditer(r"'([^']+)'\s+depends on axioms:\s*\[([^\]]*)\]", output, re.S):
        name = match.group(1)
        if name in parsed:
            raise GateError("Duplicate axiom audit entry")
        parsed[name] = [x.strip() for x in match.group(2).split(",") if x.strip()]
    result = {}
    for name in required_names:
        if name not in parsed:
            raise GateError(f"Missing actual axiom audit for {name}")
        extra = set(parsed[name]) - set(allowed)
        if extra:
            raise GateError(f"Disallowed transitive axioms for {name}: {sorted(extra)}")
        result[name] = parsed[name]
    return result
