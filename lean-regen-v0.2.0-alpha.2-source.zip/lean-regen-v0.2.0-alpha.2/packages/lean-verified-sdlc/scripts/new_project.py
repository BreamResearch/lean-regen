#!/usr/bin/env python3
"""Copy the runnable Lean example and editable requirements worksheets."""
import argparse
import json
import shutil
import sys
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dest", type=Path, required=True)
    p.add_argument("--project-id", default="verified-inventory-example")
    args = p.parse_args()
    skill = Path(__file__).resolve().parent.parent
    target = args.dest.resolve()
    if target.exists():
        print("BLOCKED: destination already exists; existing work was not changed", file=sys.stderr)
        return 2
    try:
        shutil.copytree(skill / "assets/lean-starter", target,
                        ignore=shutil.ignore_patterns(".lake", ".git", "__pycache__", "evidence"))
        shutil.copytree(skill / "assets/templates", target / "worksheets")
        config = target / "assurance.json"
        value = json.loads(config.read_text(encoding="utf-8"))
        value["project_id"] = args.project_id
        config.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"DRAFT_PROJECT_CREATED {target}")
        print("This is an example, not accepted customer requirements. Read SCOPE.md and fill the worksheets.")
        return 0
    except (OSError, ValueError) as exc:
        print(f"BLOCKED: {exc}; inspect the partially created destination before retrying", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
