"""Exercise the operator's publication gates without a remote or release credentials."""
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import publish_source_alpha as pub


class PublisherTests(unittest.TestCase):
    def test_prepared_bytes_are_bound_to_the_canonical_release(self):
        with tempfile.TemporaryDirectory() as td:
            directory = Path(td)
            expected = {name: name.encode() for name in pub.ASSETS}
            for name, data in expected.items():
                (directory / name).write_bytes(data)
            with patch.object(pub.builder, "committed_sources", return_value=("commit", {}, {})), \
                 patch.object(pub.builder, "release_assets", return_value=expected):
                self.assertEqual(pub.inputs(directory)[0], "commit")
                (directory / "manifest.json").write_text('{"theorem_count": 1}')
                digest = hashlib.sha256((directory / "manifest.json").read_bytes()).hexdigest()
                (directory / "SHA256SUMS").write_text(digest + "  manifest.json\n")
                with self.assertRaisesRegex(ValueError, "canonical tagged build"):
                    pub.inputs(directory)

    def test_local_and_peeled_remote_objects_are_required(self):
        ref = "refs/tags/" + pub.TAG
        for listing, ok in (("object\t" + ref + "\ncommit\t" + ref + "^{}", True),
                            ("object\t" + ref + "\nother\t" + ref + "^{}", False),
                            ("other\t" + ref + "\ncommit\t" + ref + "^{}", False),
                            ("object\t" + ref, False)):
            with self.subTest(listing=listing), patch.object(pub, "run", return_value=listing):
                if ok:
                    pub.check_remote_tag(["git"], "remote", ref, "object", "commit")
                else:
                    with self.assertRaisesRegex(ValueError, "peeled commit"):
                        pub.check_remote_tag(["git"], "remote", ref, "object", "commit")

    def test_exact_tag_ruleset_is_created_and_existing_bypasses_refused(self):
        created = {}
        def server(gh, path, *args, payload=None):
            if "?" in path:
                return []
            if args == ("-X", "POST"):
                created.update(payload)
                return {"id": 12}
            return {**created, "source": "owner/project", "source_type": "Repository"}
        with patch.object(pub, "api", side_effect=server):
            pub.protect_tag("gh", "owner/project", allow_create=True)
        self.assertEqual(created["conditions"], {"ref_name": {"include": ["refs/tags/" + pub.TAG], "exclude": []}})
        self.assertEqual(created["bypass_actors"], [])
        self.assertEqual(created["rules"], [{"type": "update"}, {"type": "deletion"}])
        rule = dict(created, source="owner/project", source_type="Repository", bypass_actors=[{"actor_type": "Team"}])
        with patch.object(pub, "api", side_effect=[[dict(name=created["name"], id=12)], rule]) as api:
            with self.assertRaisesRegex(ValueError, "ruleset differs"):
                pub.protect_tag("gh", "owner/project", allow_create=True)
            self.assertEqual(api.call_count, 2)
        with patch.object(pub, "api", return_value=[]) as api:
            with self.assertRaisesRegex(ValueError, "no matching protection"):
                pub.protect_tag("gh", "owner/project", allow_create=False)
            self.assertEqual(api.call_count, 1)

    def test_run_success_requires_completed_core_job_and_steps_from_same_attempt(self):
        run = {"id": 3, "run_attempt": 2, "head_sha": "c"}
        steps = ["Read source without persisting credentials", "Check immutable upstream bytes",
                 "Exercise CLI, packaging and state model", "Exercise historical evidence tooling",
                 "Fetch and check the pinned historical toolchain", "Rebuild and check the sequential inventory model",
                 "Rebuild source assets from the tested commit"]
        job = {"name": "source-checks", "status": "completed", "conclusion": "success", "head_sha": "c",
               "steps": [dict(name=name, status="completed", conclusion="success") for name in steps]}
        with patch.object(pub, "api", return_value={"jobs": [job]}) as api:
            pub.check_ci_job("gh", "owner/project", run)
            self.assertIn("/runs/3/attempts/2/jobs", api.call_args.args[1])
        for item in (dict(job, conclusion="skipped"), dict(job, head_sha="other"),
                     dict(job, steps=job["steps"][:-1]), dict(job, steps=[dict(s, conclusion="skipped") for s in job["steps"]])):
            with self.subTest(job=item), patch.object(pub, "api", return_value={"jobs": [item]}):
                with self.assertRaises(ValueError):
                    pub.check_ci_job("gh", "owner/project", run)

    def test_resume_enforces_canonical_notes_and_checks_ref_around_publication(self):
        with tempfile.TemporaryDirectory() as td:
            directory = Path(td)
            data = {name: (name + "\n").encode() for name in pub.ASSETS}
            for name, value in data.items():
                (directory / name).write_bytes(value)
            hashes = {k: hashlib.sha256(v).hexdigest() for k,v in data.items()}
            repo = "owner/project"
            url = "https://github.com/" + repo
            release = {"id": 1, "tag_name": pub.TAG, "draft": True, "prerelease": True, "immutable": False,
                       "name": "old", "body": "old", "html_url": url + "/releases/tag/" + pub.TAG,
                       "assets": [{"name": n, "digest": "sha256:" + h, "browser_download_url": "https://example.test/" + n}
                                  for n,h in hashes.items()]}
            events = []
            def api(gh, path, *args, **kwargs):
                if path == "user":
                    return {"login": "owner"}
                if path == "repos/" + repo:
                    return dict(full_name=repo, private=False, fork=False, archived=False, permissions={"admin": True})
                if "/releases/" in path:
                    return release.copy()
                return {"enabled": True}
            def command(*args):
                if "get-url" in args:
                    return url + ".git"
                if "ls-remote" in args:
                    return "c\trefs/heads/main\nt\trefs/tags/" + pub.TAG
                if "rev-parse" in args:
                    return "t"
                if "edit" in args:
                    events.append("publish")
                    release.update(name=args[args.index("--title")+1], body=args[args.index("--notes")+1],
                                   draft=False, immutable=True)
                return ""
            with patch.object(pub, "api", side_effect=api), patch.object(pub,"run",side_effect=command), \
                 patch.object(pub,"protect_tag"), patch.object(pub, "wait_for_ci", return_value="ci"), \
                 patch.object(pub,"check_remote_tag",side_effect=lambda *a:events.append("tag")), \
                 patch.object(pub, "urlopen", side_effect=lambda u, timeout:io.BytesIO(data[u.rsplit("/",1)[1]])):
                result = pub.publish("gh", repo, directory, "c", hashes)
                self.assertEqual(events, ["tag", "tag", "publish", "tag"])
                self.assertTrue(result["immutable"])
                self.assertEqual(release["body"], data["RELEASE-NOTES.md"].decode())
                release["body"] = "signed by an independent service"
                events.clear()
                with self.assertRaisesRegex(ValueError, "Published release metadata"):
                    pub.publish("gh", repo, directory, "c", hashes)
                self.assertEqual(events, [])


if __name__ == "__main__":
    unittest.main()
