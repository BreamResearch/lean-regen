"""Small boundary tests for the distribution CLI; these are not Lean proofs."""
import contextlib
import importlib.util
import io
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("leanregen", ROOT / "scripts/leanregen.py")
cli = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cli)


class DistributionTests(unittest.TestCase):
    def test_original_distribution_matches(self):
        self.assertEqual(cli.check_upstream()["file_count"], 68)

    def test_missing_runtime_blocks(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaisesRegex(ValueError, "Missing trusted runtime"):
                cli.doctor(Path(td))

    def test_tampered_snapshot_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "packages/lean-verified-sdlc"
            shutil.copytree(cli.UPSTREAM, source)
            shutil.copyfile(ROOT / "UPSTREAM_PROVENANCE.json", root / "UPSTREAM_PROVENANCE.json")
            (source / "SKILL.md").write_text("changed")
            with self.assertRaisesRegex(ValueError, "SKILL.md: digest differs"):
                cli.check_upstream(root)

    def test_upstream_index_cannot_escape(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            record = {"files": {"../outside": "0" * 64}}
            (root / "UPSTREAM_PROVENANCE.json").write_text(json.dumps(record))
            with self.assertRaisesRegex(ValueError, "provenance digest differs"):
                cli.check_upstream(root)

    def test_reduced_snapshot_and_rewritten_manifest_are_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "packages/lean-verified-sdlc"
            source.mkdir(parents=True)
            shutil.copyfile(cli.UPSTREAM / "SKILL.md", source / "SKILL.md")
            record = cli.read_object(ROOT / "UPSTREAM_PROVENANCE.json")
            record["files"] = {"SKILL.md": record["files"]["SKILL.md"]}
            (root / "UPSTREAM_PROVENANCE.json").write_text(json.dumps(record))
            with self.assertRaisesRegex(ValueError, "provenance digest differs"):
                cli.check_upstream(root)

    def test_doctor_rejects_prerelease_or_mismatched_lake(self):
        stable = "Lean (version 4.19.0, aarch64-apple-darwin, commit 6caaee842e94, Release)"
        lake = "Lake version 5.0.0-6caaee8 (Lean version 4.19.0)"
        with tempfile.TemporaryDirectory() as td:
            directory = Path(td)
            for name in ("lean", "lake"):
                (directory / name).touch()
            for lean_text, lake_text in ((stable.replace("4.19.0", "4.19.0-rc1"), lake),
                                         (stable, lake.replace("4.19.0", "4.20.0"))):
                with self.subTest(lean=lean_text, lake=lake_text):
                    versions = [subprocess.CompletedProcess([], 0, value, "") for value in (lean_text, lake_text)]
                    with patch.object(cli.subprocess, "run", side_effect=versions):
                        with self.assertRaisesRegex(ValueError, "stable Lean 4.19.0"):
                            cli.doctor(directory)

    def test_main_controlled_failure(self):
        with patch("sys.argv", ["leanregen.py", "doctor", "--tool-bin", "/nonexistent/runtime"]):
            with contextlib.redirect_stderr(io.StringIO()) as out:
                self.assertEqual(cli.main(), 2)
            self.assertIn("BLOCKED", out.getvalue())


if __name__ == "__main__":
    unittest.main()
