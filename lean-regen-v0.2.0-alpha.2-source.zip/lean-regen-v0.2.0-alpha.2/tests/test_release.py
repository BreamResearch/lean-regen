import json
import sys
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import build_source_alpha as release


class ReleaseBoundaries(unittest.TestCase):
    def test_private_files_and_binary_are_rejected(self):
        for name, data in [(".env.production", b"a"), ("docs/.git/config", b"a"),
                           ("logs/historical.log", b"prefix /Users/" + b"somebody/repo"),
                           ("config/remote.json", b"https://user:" + b"password@example.org"),
                           ("lib/old", b"abc\x00def"), ("safe/../files", b"x")]:
            with self.subTest(path=name), self.assertRaises(ValueError):
                release.check_file(name, data)

    def test_archiver_uses_only_committed_bytes_and_rejects_tracked_local_files(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(release, "ROOT", Path(tmp).resolve()):
            root = Path(tmp)
            def run(*args):
                subprocess.run(["git", "-c", "user.name=Fixture", "-c", "user.email=fixture@example.test",
                                "-c", "commit.gpgSign=false", *args], cwd=root, check=True, capture_output=True)
            run("init", "-q")
            (root / "README.md").write_bytes(b"public")
            run("add", "README.md")
            run("commit", "-qm", "fixture")
            (root / "README.md").write_bytes(b"working copy")
            (root / ".env.production").write_bytes(b"synthetic fixture")
            _, files, modes = release.committed_sources("HEAD")
            self.assertEqual(files, {"README.md": b"public"})
            self.assertEqual(modes["README.md"], 0o100644)
            run("add", "-f", ".env.production")
            run("commit", "-qm", "private filename fixture")
            with self.assertRaisesRegex(ValueError, "Non-distributable"):
                release.committed_sources("HEAD")

    def test_historical_index_pins_exact_content(self):
        current = json.loads((ROOT / "UPSTREAM_PROVENANCE.json").read_bytes())["files"]
        self.assertEqual(release.index_digest(current), release.UPSTREAM_INDEX)
        changed = dict(current)
        changed["SKILL.md"] = "0" * 64
        self.assertNotEqual(release.index_digest(changed), release.UPSTREAM_INDEX)

    def test_source_alpha_rejects_historical_evidence_substituted_for_fresh_run(self):
        pkg = ROOT / "packages/lean-verified-sdlc"
        files = {**{p.relative_to(ROOT).as_posix(): p.read_bytes() for p in pkg.rglob("*")
                     if p.is_file() and "__pycache__" not in p.parts},
                 "UPSTREAM_PROVENANCE.json": (ROOT / "UPSTREAM_PROVENANCE.json").read_bytes(),
                 "STATUS.json": b'{"evidence":{"p0a_core_report":"validation/cli_core_check.json"}}'}
        with self.assertRaisesRegex(ValueError, "fresh P0A"):
            release.check_evidence(files)
