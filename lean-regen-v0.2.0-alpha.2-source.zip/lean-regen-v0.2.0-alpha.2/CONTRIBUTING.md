# Contributing

Contributions intentionally submitted for inclusion use the project's Apache-2.0 terms unless separately identified and accepted with compatible provenance. Keep third-party copyright and license notices. Do not add copied proprietary material, private customer requirements or secrets.

Changes should state the problem, the behavior being changed and the evidence. For contract changes, record the requirements affected, accepted authority and semantic migration. Do not silently weaken a theorem or change an expected result to fit the generated implementation.

The historical `packages/lean-verified-sdlc` distribution is immutable. Put new runtimes/adapters in a separate package and retain the old reproduction. Proof/checker/policy changes belong to the trust-control path; ordinary implementation proposals must not grant themselves authority.

Use meaningful tests for failure cases and trust boundaries. A pull request may be accepted by a standing automated policy where its scope and authority allow it. Until that controller is implemented, documentation describing it is not an active permission mechanism.
