# ライセンスと再利用 · License and reuse

[許諾条件 / License](../LICENSE) · [帰属 / Attribution](../NOTICE) · [この配布物の第三者表記 / Notices for this distribution](../THIRD_PARTY_NOTICES.md)
