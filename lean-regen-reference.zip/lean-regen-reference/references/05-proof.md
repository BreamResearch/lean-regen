# Verification profile

The supplied verifier runs ordinary kernel and axiom checks on trusted local sources. The original proof validation guidance is in the [full source alpha](https://github.com/BreamResearch/lean-regen/releases/tag/v0.2.0-alpha.2-dist.1), under `packages/lean-verified-sdlc/references/05-proof.md`.
