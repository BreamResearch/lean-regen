# Verification profile · 検査範囲

The three builds use the same [contract lock](../contract-lock.json) and the [original verifier](../verification/verify_project.py). Run the comparison to create fresh reports for your own toolchain. The [historical summary](../project/evidence/validation-summary.json) records the starter run and the hashes of its original logs.

3つの実装は同じ契約と検査器で比較します。展開したディレクトリで `compare.py` を実行すると、指定した出力先に今回の結果が保存されます。[使い方](../README.md)
