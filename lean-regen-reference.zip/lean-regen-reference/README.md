# Lean Regen — 仕様を保ったまま実装を替える / Replacing an implementation under a fixed contract

在庫の予約・解放を例に、同じ業務仕様を三つの実装で検査します。成功・拒否の条件、増減する数量、拒否時に残高を変えないことを先に固定します。実装を変更するときは、その仕様に対して証明を書きます。別の業務で再利用できるのは、この設計と検査の手順です。

This example checks three implementations of one business contract in the Lean proof assistant. The contract specifies when an operation succeeds, the exact quantity moved, and which state survives rejection. You can change the implementation and its proof while keeping those obligations fixed.

## 実行 / Run

Python 3.11+ と [Lean/Lake 4.19.0](https://github.com/leanprover/lean4/releases/tag/v4.19.0) を用意します。ZIP を展開したフォルダーで実行し、ツールの場所を実際のパスに置き換えてください。検査は無料で、ダウンロード後は登録・通信なしで実行できます。

Install Python 3.11+ and the toolchain linked above. From the extracted directory, replace the tool path with your own. Choose a new output directory each time. On Apple Silicon with macOS 27, first set `export CCC_OVERRIDE_OPTIONS='+--ld-path=/usr/bin/ld'` and `export MACOSX_DEPLOYMENT_TARGET=27.0` in the shell. Apple Silicon の macOS 27 ではこの2つの環境変数を先に設定してください。

```sh
python3 compare.py --tool-bin /absolute/path/to/lean-4.19.0/bin --out ../comparison
```

| 実装 / Implementation | 変更 / Change | 結果 / Expected result |
| --- | --- | --- |
| `original` | 元の実装 / Original functions | 14/14 CORE_KERNEL_CHECKED |
| `equivalent` | 予約済み数量の加算の順を入れ替え、可換性で証明 / Reverse the addition operands and prove the result by commutativity | 14/14 CORE_KERNEL_CHECKED |
| `boundary-error` | 全残数の予約も拒否 / Reject a request for exactly the remaining quantity | BLOCKED |

空き8・予約済み2の状態で8個を予約すると、仕様は「成功、空き0・予約済み10」を要求します。最後の実装は拒否します。合計が10でも、成功の条件を満たさないため証明が通りません。3件が表どおりの結果なら比較コマンドは終了コード0を返します。各フォルダーの `result.json` と `result_logs/` に実際の検査結果が残ります。

With eight free and two reserved, a request for eight must succeed and leave zero free and ten reserved. The last implementation refuses it. Its total still balances, but its proof fails on a required successful operation. The comparison exits zero only if it observes all three expected outcomes. Inspect each case’s `result.json` and `result_logs/` to see the evidence.

## 自分の実装を試す / Check your own variant

`project/` をコピーし、その中の `VerifiedInventory/Implementation.lean` と `VerifiedInventory/Proofs.lean` を編集します。下のコマンドは配布時の同じ仕様で検査します。検査出力には新しいファイル名を指定してください。

Copy `project/` to a separate directory and edit its implementation and proofs. Invoke the verifier directly to check that candidate. Give each run a fresh report path.

```sh
cp -R project ../my-variant
python3 verification/verify_project.py --project ../my-variant \
  --baseline contract-lock.json --tool-bin /absolute/path/to/lean-4.19.0/bin \
  --out ../my-variant-report.json
```

- `project/VerifiedInventory/Specification.lean` defines the domain and observable behavior. 状態・操作・期待する結果を定義します。
- `project/Contract.lean` requires the exact 14 theorem statements. `project/Audit.lean` checks their axioms. 受け入れる定理の型と許容する公理を固定します。
- `contract-lock.json` identifies nine fixed inputs. Both the original and rewritten implementations use the same lock. 仕様を固定するファイルは実装の作業領域の外に置きます。
- `equivalent/` and `boundary-error/` contain only the files replaced in each run. 2つの例で何を編集したか、元のファイルと直接比較できます。

別の業務に移すときは、その業務の状態・操作・成功条件・失敗時の状態を定義し、新しい契約・証明・検査基準を用意します。在庫例の14定理が扱うのは単一資源の逐次的な数量操作です。データベース、権限、並行処理には個別の仕様と検証が必要です。

For another domain, define its state, operations, success and rejection rules, then write and pin that domain’s own obligations. The inventory theorems apply to sequential operations on one resource. Database behavior, authorization and concurrent execution each need their own verification.

[プロジェクトガイド / Project guide](https://breamresearch.github.io/lean-regen/) · [LICENSE](LICENSE) · [NOTICE](NOTICE) · [Third-party notices](THIRD_PARTY_NOTICES.md)
