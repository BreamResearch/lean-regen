# ライセンスと再利用 · Licenses and reuse

この設計例のソース・証明・文書には Apache License 2.0 が適用されます。再配布時にはライセンスと帰属表示を保持し、変更したファイルには変更を明記してください。設計例の比較用の変更は `equivalent/` と `boundary-error/` にまとめています。

The original project sources, proofs and documentation are distributed under Apache License 2.0. Preserve the license and applicable notices and identify modifications when redistributing. The files in `equivalent/` and `boundary-error/` are modified examples derived from the original inventory sources. The original Lean Verified SDLC 1.0.0 starter and verifier files are identified by their SHA-256 digests in the bundled provenance index. [License](LICENSE) · [Attribution](NOTICE) · [Provenance](UPSTREAM_PROVENANCE.json)

Python と Lean/Lake 4.19.0 は利用者が用意します。各実行環境のライセンスは、その配布物を参照してください。

Python and Lean/Lake 4.19.0 are supplied by the user. The official Lean toolchain includes additional component terms. Redistribution of a locally built binary must account for the components actually linked. [Lean 4.19.0 license](https://github.com/leanprover/lean4/blob/v4.19.0/LICENSE) · [Toolchain component notices](https://github.com/leanprover/lean4/blob/v4.19.0/LICENSES) · [Python license](https://docs.python.org/3/license.html)
