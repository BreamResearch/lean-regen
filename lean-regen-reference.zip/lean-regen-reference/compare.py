#!/usr/bin/env python3
"""Check three implementations against one fixed contract using the packaged verifier."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CONTRACT = 'e46de304f616836721c5aad46a64ef21b4e912ca83a8934eef1ae07dbb084c6f'
LOCK_SHA256 = '79146a27eb34bc56602e6de42944358f4dd3455b5fa8f85724d612a006de1631'
VARIANTS = {'original': (), 'equivalent': ('Implementation.lean', 'Proofs.lean'),
            'boundary-error': ('Implementation.lean',)}


def compare(tool_bin, output):
    if output == ROOT or output.is_relative_to(ROOT / 'project'):
        raise ValueError('Choose a fresh output directory outside the sample project.')
    lock = ROOT / 'contract-lock.json'
    if sha256(lock.read_bytes()).hexdigest() != LOCK_SHA256:
        raise ValueError('The supplied reference contract lock has changed.')
    output.mkdir(parents=True, exist_ok=False)
    for name, changes in VARIANTS.items():
        case = output / name
        project = case / 'project'
        shutil.copytree(ROOT / 'project', project)
        for filename in changes:
            shutil.copyfile(ROOT / name / filename, project / 'VerifiedInventory' / filename)
        report_path = case / 'result.json'
        run = subprocess.run([sys.executable, '-B', str(ROOT / 'verification/verify_project.py'),
                              '--project', str(project), '--baseline', str(lock),
                              '--tool-bin', str(tool_bin), '--out', str(report_path)],
                             capture_output=True, text=True)
        if not report_path.is_file():
            raise ValueError(run.stderr or f'{name}: verifier produced no report')
        report = json.loads(report_path.read_text())
        if report.get('contract_digest') != CONTRACT:
            raise ValueError(f'{name}: original contract was not checked; see {report_path}')
        if name == 'boundary-error':
            log = case / 'result_logs/build.log'
            if not (run.returncode == 2 and report['status'] == 'BLOCKED'
                    and report['steps'] and report['steps'][-1]['name'] == 'build'
                    and report['steps'][-1]['exit_code'] != 0 and log.is_file()):
                raise ValueError(f'{name}: expected a rejected proof; see {report_path}')
            diagnostics = log.read_text()
            if not any('error:' in line and 'Proofs.lean:' in line and 'unsolved goals' in line
                       for line in diagnostics.splitlines()):
                raise ValueError(f'{name}: expected an unsolved inventory proof; see {log}')
            print(f'{name}: BLOCKED (inventory proof rejected)', flush=True)
        else:
            if not (run.returncode == 0 and report['status'] == 'CORE_KERNEL_CHECKED'
                    and report.get('theorem_count') == len(report.get('theorem_axioms', {})) == 14):
                raise ValueError(f'{name}: expected 14 checked obligations; see {report_path}')
            print(f'{name}: 14/14 CORE_KERNEL_CHECKED', flush=True)
    print(f'Reports: {output}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tool-bin', required=True, type=Path, help='Lean/Lake 4.19.0 bin directory')
    parser.add_argument('--out', required=True, type=Path, help='a new directory for the three builds and reports')
    options = parser.parse_args()
    try:
        compare(options.tool_bin.resolve(strict=True), options.out.resolve())
    except (OSError, ValueError) as error:
        sys.exit(str(error))
